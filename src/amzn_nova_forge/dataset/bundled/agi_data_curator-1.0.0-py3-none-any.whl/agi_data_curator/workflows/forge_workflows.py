"""Factory for constructing and executing curation pipelines by identifier.

Provides a registry-based factory pattern where each workflow identifier
(e.g. ``"default_text_filter"``, ``"topic_classification"``) maps to a builder
function that assembles a :class:`CurationPipeline` with the appropriate
stages and configuration.

Usage::

    from agi_data_curator.workflows.forge_workflows import ForgeWorkflows

    forge = ForgeWorkflows(
        input_path="s3://bucket/raw/",
        output_path="s3://bucket/curated/",
    )

    # Build and execute a single workflow
    result = forge.execute("default_text_filter", text_field="text", max_url_to_text_ratio=0.3)

"""

from __future__ import annotations

import logging
import time
from typing import Any, Callable

from agi_data_curator.pipeline.curation_pipeline import CurationPipeline
from agi_data_curator.pipeline.curation_stage import CurationStage

logger = logging.getLogger(__name__)


def _detect_format(path: str) -> str:
    """Detect data format from file path or directory contents.

    Resolution order:

    1. If ``path`` ends with ``.jsonl`` or ``.json`` → ``"jsonl"``.
    2. If ``path`` ends with ``.parquet`` → ``"parquet"``.
    3. If ``path`` looks like a directory (ends with ``/`` or has no
       file extension), list files inside and pick the format from the
       first data file found (``*.jsonl``, ``*.json``, ``*.parquet``).
    4. Falls back to ``"parquet"`` if nothing else matches.
    """
    clean = path.rstrip("/")
    lower = clean.lower()

    # Direct file extension match
    if lower.endswith((".jsonl", ".json")):
        return "jsonl"
    if lower.endswith(".parquet"):
        return "parquet"

    # Looks like a directory — peek at contents
    if path.endswith("/") or "." not in clean.rsplit("/", 1)[-1]:
        try:
            import fsspec

            fs, fs_path = fsspec.url_to_fs(path)
            files = fs.ls(fs_path, detail=False)
            for f in files:
                fl = f.lower()
                if fl.endswith((".jsonl", ".json")):
                    logger.info("_detect_format: found JSONL file in %s → jsonl", path)
                    return "jsonl"
                if fl.endswith(".parquet"):
                    logger.info("_detect_format: found Parquet file in %s → parquet", path)
                    return "parquet"
        except Exception:
            logger.debug("_detect_format: could not list %s, defaulting to parquet", path)

    return "parquet"

# Type alias for builder functions
_BuilderFn = Callable[..., list[CurationStage]]
# Standalone workflows handle their own read/write (e.g. global dedup)
_StandaloneFn = Callable[..., dict]


class ForgeWorkflows:
    """Factory for constructing and executing curation pipelines.

    Each workflow identifier maps to a builder that returns a list of
    :class:`CurationStage` instances.  The factory wraps these in a
    :class:`CurationPipeline` with shared I/O and execution settings.

    Standalone workflows (registered via :meth:`register_standalone`)
    handle their own I/O and are invoked directly by :meth:`execute`.
    Use these for operations that need global dataset visibility, such
    as exact deduplication.

    Args:
        input_path: Path to input data (local or S3).
        output_path: Path for output data (local or S3).
        input_format: Input file format (``"parquet"`` or ``"jsonl"``).
            If ``None`` (default), auto-detected from ``input_path``
            extension (``.jsonl``/``.json`` → ``"jsonl"``, else ``"parquet"``).
        output_format: Output file format (``"parquet"`` or ``"jsonl"``).
            If ``None`` (default), auto-detected from ``output_path`` extension.
        ray_batch_size: Batch size for Ray Data ``map_batches``.
        concurrency: Number of Ray actors per pipeline stage.
        verbose: Print progress information.
    """

    # Class-level registry: identifier -> builder function
    _registry: dict[str, _BuilderFn] = {}
    # Standalone workflows that manage their own read/write
    _standalone_registry: dict[str, _StandaloneFn] = {}

    def __init__(
        self,
        input_path: str,
        output_path: str,
        input_format: str | None = None,
        output_format: str | None = None,
        ray_batch_size: int = 1024,
        concurrency: int = 1,
        verbose: bool = True,
    ):
        self.input_path = input_path
        self.output_path = output_path
        self.input_format = input_format if input_format is not None else _detect_format(input_path)
        self.output_format = output_format if output_format is not None else _detect_format(output_path)
        self.ray_batch_size = ray_batch_size
        self.concurrency = concurrency
        self.verbose = verbose
        logger.info(
            "ForgeWorkflows: detected input_format=%r, output_format=%r",
            self.input_format, self.output_format,
        )

    # ── Registry API ─────────────────────────────────────────────────

    @classmethod
    def register(cls, identifier: str) -> Callable[[_BuilderFn], _BuilderFn]:
        """Decorator to register a workflow builder function.

        The builder receives arbitrary ``**kwargs`` and must return a
        ``list[CurationStage]``.

        Example::

            @ForgeWorkflows.register("my_filter")
            def _build_my_filter(**kwargs) -> list[CurationStage]:
                return [MyFilterStage(**kwargs)]
        """
        def decorator(fn: _BuilderFn) -> _BuilderFn:
            cls._registry[identifier] = fn
            return fn
        return decorator

    @classmethod
    def register_standalone(cls, identifier: str) -> Callable[[_StandaloneFn], _StandaloneFn]:
        """Decorator to register a standalone workflow function.

        Standalone workflows handle their own I/O and receive
        ``input_path``, ``output_path``, ``input_format``,
        ``output_format`` plus any extra ``**kwargs``.

        Example::

            @ForgeWorkflows.register_standalone("exact_dedup")
            def _run_exact_dedup(**kwargs) -> dict:
                from agi_data_curator.dedup.exact_dedup import run_exact_dedup
                return run_exact_dedup(**kwargs)
        """
        def decorator(fn: _StandaloneFn) -> _StandaloneFn:
            cls._standalone_registry[identifier] = fn
            return fn
        return decorator

    @classmethod
    def available_workflows(cls) -> list[str]:
        """Return sorted list of registered workflow identifiers."""
        return sorted(set(cls._registry) | set(cls._standalone_registry))

    # ── Build & Execute ──────────────────────────────────────────────

    def build(self, identifier: str, **kwargs: Any) -> CurationPipeline:
        """Build a pipeline for the given workflow identifier.

        Args:
            identifier: Registered workflow name (e.g. ``"default_text_filter"``).
            **kwargs: Passed to the workflow's builder function.

        Returns:
            A configured :class:`CurationPipeline` ready to run.

        Raises:
            ValueError: If the identifier is not registered.
        """
        if identifier not in self._registry:
            raise ValueError(
                f"Unknown workflow {identifier!r}. "
                f"Available: {self.available_workflows()}"
            )

        builder = self._registry[identifier]
        stages = builder(**kwargs)

        return CurationPipeline(
            stages=stages,
            input_path=self.input_path,
            output_path=self.output_path,
            input_format=self.input_format,
            output_format=self.output_format,
            ray_batch_size=self.ray_batch_size,
            concurrency=self.concurrency,
            verbose=self.verbose,
        )

    def execute(self, identifier: str, **kwargs: Any) -> dict[str, Any]:
        """Build and run a pipeline, returning results with metrics.

        For stage-based workflows, builds a :class:`CurationPipeline`
        and runs it. For standalone workflows, invokes the function
        directly with I/O paths and kwargs.

        Args:
            identifier: Registered workflow name.
            **kwargs: Passed to the workflow's builder function.

        Returns:
            Dict with keys:

            - ``identifier``: The workflow name.
            - ``stages``: List of stage class names (empty for standalone).
            - ``input_path``: Input path used.
            - ``output_path``: Output path used.
            - ``elapsed_seconds``: Wall-clock time in seconds.
            - ``elapsed_minutes``: Wall-clock time in minutes.
            - ``status``: ``"success"`` or ``"error"``.
            - ``error``: Error message if status is ``"error"``, else ``None``.
            - ``result``: The raw pipeline result on success.
        """
        is_standalone = identifier in self._standalone_registry
        is_stage = identifier in self._registry

        if not is_standalone and not is_stage:
            raise ValueError(
                f"Unknown workflow {identifier!r}. "
                f"Available: {self.available_workflows()}"
            )

        start = time.time()
        status = "success"
        error = None
        result = None
        stage_names: list[str] = []

        try:
            if is_standalone:
                fn = self._standalone_registry[identifier]
                logger.info(
                    "ForgeWorkflows: executing standalone %r\n"
                    "  input:  %s\n"
                    "  output: %s",
                    identifier, self.input_path, self.output_path,
                )
                result = fn(
                    input_path=self.input_path,
                    output_path=self.output_path,
                    input_format=self.input_format,
                    output_format=self.output_format,
                    **kwargs,
                )
            else:
                pipeline = self.build(identifier, **kwargs)
                stage_names = [s.__class__.__name__ for s in pipeline.stages]
                logger.info(
                    "ForgeWorkflows: executing %r (%d stages: %s)\n"
                    "  input:  %s\n"
                    "  output: %s",
                    identifier, len(stage_names), stage_names,
                    self.input_path, self.output_path,
                )
                result = pipeline.run()
        except Exception as exc:
            status = "error"
            error = str(exc)
            logger.error("ForgeWorkflows: %r failed: %s", identifier, exc)

        elapsed = time.time() - start

        metrics = {
            "identifier": identifier,
            "stages": stage_names,
            "input_path": self.input_path,
            "output_path": self.output_path,
            "elapsed_seconds": round(elapsed, 2),
            "elapsed_minutes": round(elapsed / 60, 2),
            "status": status,
            "error": error,
            "result": result,
        }

        if self.verbose:
            logger.info(
                "ForgeWorkflows: %r completed [%s] in %.1fs (%.1f min)",
                identifier, status, elapsed, elapsed / 60,
            )

        return metrics


# ── Built-in workflow builders ───────────────────────────────────────


@ForgeWorkflows.register("default_text_filter")
def _build_default_text_filter(**kwargs: Any) -> list[CurationStage]:
    """Basic text filtering pipeline.

    Applies seven stages sequentially:
    1. UrlsFilter — removes documents with excessive URL content.
    2. AlphanumericFilter — removes documents with too many non-alphanumeric chars.
    3. WordRepetitionFilter — removes documents with excessive repeated word n-grams.
    4. CharRepetitionFilter — removes documents with excessive repeated char n-grams.
    5. MojibakeFilter — removes documents with encoding corruption.
    6. CharacterLengthFilter — removes documents outside a character count range.
    7. AverageLineLengthFilter — removes documents with abnormal average line lengths.

    Kwargs are routed to each stage by prefix. Unprefixed kwargs (e.g.
    ``text_field``) are shared across all stages. Stage-specific kwargs
    use the prefixes ``url_``, ``alphanumeric_``, ``word_rep_``,
    ``char_rep_``, ``mojibake_``, ``length_``, and ``avg_line_``
    (prefix is stripped before passing).

    Examples::

        # Shared text_field, default thresholds
        forge.execute("default_text_filter", text_field="text")

        # Override specific thresholds
        forge.execute(
            "default_text_filter",
            text_field="text",
            url_max_url_to_text_ratio=0.3,
            alphanumeric_min_alnum_ratio=0.5,
            word_rep_max_word_repetition_ratio=0.3,
            word_rep_n=3,
            char_rep_max_char_repetition_ratio=0.3,
            mojibake_max_badness=2,
            length_min_length=100,
            avg_line_min_avg_line_length=15,
        )
    """
    from agi_data_curator.filtering.text_filters import (
        AlphanumericFilter,
        AverageLineLengthFilter,
        CharacterLengthFilter,
        CharRepetitionFilter,
        MojibakeFilter,
        WordRepetitionFilter,
    )
    from agi_data_curator.filtering.url_filters import UrlsFilter

    # Split kwargs by prefix; unprefixed kwargs are shared across all stages
    shared: dict[str, Any] = {}
    url_kw: dict[str, Any] = {}
    alnum_kw: dict[str, Any] = {}
    word_kw: dict[str, Any] = {}
    char_kw: dict[str, Any] = {}
    mojibake_kw: dict[str, Any] = {}
    length_kw: dict[str, Any] = {}
    avg_line_kw: dict[str, Any] = {}

    for key, val in kwargs.items():
        if key.startswith("url_"):
            url_kw[key[4:]] = val
        elif key.startswith("alphanumeric_"):
            alnum_kw[key[13:]] = val
        elif key.startswith("word_rep_"):
            word_kw[key[9:]] = val
        elif key.startswith("char_rep_"):
            char_kw[key[9:]] = val
        elif key.startswith("mojibake_"):
            mojibake_kw[key[9:]] = val
        elif key.startswith("length_"):
            length_kw[key[7:]] = val
        elif key.startswith("avg_line_"):
            avg_line_kw[key[9:]] = val
        else:
            shared[key] = val

    return [
        UrlsFilter(**shared, **url_kw),
        AlphanumericFilter(**shared, **alnum_kw),
        WordRepetitionFilter(**shared, **word_kw),
        CharRepetitionFilter(**shared, **char_kw),
        MojibakeFilter(**shared, **mojibake_kw),
        CharacterLengthFilter(**shared, **length_kw),
        AverageLineLengthFilter(**shared, **avg_line_kw),
    ]


@ForgeWorkflows.register_standalone("exact_dedup_filter")
def _run_exact_dedup_workflow(**kwargs: Any) -> dict:
    """Global exact deduplication via MD5 hash of text field."""
    from agi_data_curator.dedup.exact_dedup import run_exact_dedup

    return run_exact_dedup(**kwargs)


@ForgeWorkflows.register_standalone("fuzzy_dedup_cpu")
def _run_fuzzy_dedup_cpu(**kwargs: Any) -> dict:
    """CPU-only fuzzy deduplication via MinHash LSH (no GPU required)."""
    import inspect

    from agi_data_curator.dedup.fuzzy_dedup_cpu import run_fuzzy_dedup

    # Filter to only params accepted by run_fuzzy_dedup to avoid
    # TypeError from extra kwargs injected by ForgeWorkflows.execute()
    # (e.g. output_format, which standalone dedup doesn't use).
    valid_params = set(inspect.signature(run_fuzzy_dedup).parameters)
    filtered = {k: v for k, v in kwargs.items() if k in valid_params}
    return run_fuzzy_dedup(**filtered)


@ForgeWorkflows.register("language_detection")
def _build_language_detection(**kwargs: Any) -> list[CurationStage]:
    """Language detection and optional filtering using FastText."""
    import inspect

    from agi_data_curator.filtering.language_detection import LanguageDetectionStage

    valid_params = set(inspect.signature(LanguageDetectionStage).parameters)
    filtered = {k: v for k, v in kwargs.items() if k in valid_params}
    return [LanguageDetectionStage(**filtered)]


@ForgeWorkflows.register("incomplete_conversation_filter")
def _build_incomplete_conversation_filter(**kwargs: Any) -> list[CurationStage]:
    """Drop rows whose last message is from the user (incomplete conversations).

    Always runs in filter mode — ``annotate_only`` is not exposed via
    ForgeWorkflows.  Use the class directly for annotate mode.
    """
    import inspect

    from agi_data_curator.filtering.incomplete_conversation_filter import (
        IncompleteConversationFilter,
    )

    valid_params = set(inspect.signature(IncompleteConversationFilter).parameters)
    filtered = {k: v for k, v in kwargs.items() if k in valid_params}
    filtered.pop("annotate_only", None)
    return [IncompleteConversationFilter(**filtered)]


@ForgeWorkflows.register("turn_separator_in_text_filter")
def _build_turn_separator_in_text_filter(**kwargs: Any) -> list[CurationStage]:
    """Drop rows where turn separator tokens appear inside message text.

    Always runs in filter mode — ``annotate_only`` is not exposed via
    ForgeWorkflows.  Use the class directly for annotate mode.
    """
    import inspect

    from agi_data_curator.filtering.turn_separator_in_text_filter import (
        TurnSeparatorInTextFilter,
    )

    valid_params = set(inspect.signature(TurnSeparatorInTextFilter).parameters)
    filtered = {k: v for k, v in kwargs.items() if k in valid_params}
    filtered.pop("annotate_only", None)
    return [TurnSeparatorInTextFilter(**filtered)]


@ForgeWorkflows.register("text_pattern_filter")
def _build_text_pattern_filter(**kwargs: Any) -> list[CurationStage]:
    """Filter conversations containing problematic regex patterns."""
    import inspect

    from agi_data_curator.filtering.text_pattern_filter import TextPatternFilter

    valid_params = set(inspect.signature(TextPatternFilter).parameters)
    filtered = {k: v for k, v in kwargs.items() if k in valid_params}
    return [TextPatternFilter(**filtered)]


@ForgeWorkflows.register("special_char_ratio_filter")
def _build_special_char_ratio_filter(**kwargs: Any) -> list[CurationStage]:
    """Filter conversations by special character ratio in text content."""
    import inspect

    from agi_data_curator.filtering.special_char_ratio_filter import SpecialCharRatioFilter

    valid_params = set(inspect.signature(SpecialCharRatioFilter).parameters)
    filtered = {k: v for k, v in kwargs.items() if k in valid_params}
    return [SpecialCharRatioFilter(**filtered)]
