"""FinePDFs curation workflows.

Requires ``nemo-curator`` (``pip install agi-data-curator[gpu]``).
"""

try:
    from agi_data_curator.workflows.finepdfs.finepdfs import (
        FinePDFsCurationWorkflow,
    )
    from agi_data_curator.workflows.finepdfs.finepdfs_eng import (
        FinePDFsEngWorkflow,
    )

    __all__ = [
        "FinePDFsCurationWorkflow",
        "FinePDFsEngWorkflow",
    ]
except ImportError:
    __all__ = []
