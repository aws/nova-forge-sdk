"""FinePDFs eng_Latn curation workflow.

Reads pre-split parquet files, applies filtering (token count, truncation,
duplicates), quality bucketing (DCLM scores), and writes per-bucket output.

Designed for pre-split 128 MB parquet files from the split utility.
Uses standard ParquetReader — no custom reader needed.

Usage::

    python -m agi_data_curator.config.run \
        --config-path $(pwd)/config/templates \
        --config-name finepdfs_eng \
        "input_path=s3://bucket/split-128mb/eng_Latn/" \
        "output_path=s3://bucket/curated/eng_Latn/"
"""

from __future__ import annotations

import logging
import time
from typing import Any

import pandas as pd

from nemo_curator.pipeline import Pipeline
from nemo_curator.stages.base import ProcessingStage
from nemo_curator.tasks import DocumentBatch

from agi_data_curator.filtering.column_filters import (
    DuplicateCountFilter,
    TokenCountFilter,
    TruncationFilter,
)
from agi_data_curator.filtering.quality_bucketer import (
    QualityScoreBucketer,
    get_default_quantiles,
    make_bucket_names,
)
from agi_data_curator.tracking.stats_collector import StatsCollector
from agi_data_curator.writers.multi_bucket_writer import MultiBucketParquetWriter

logger = logging.getLogger(__name__)


class _EngSchemaConverter(ProcessingStage):
    """Project FinePDFs eng columns to output schema with bucket routing."""

    name = "eng_schema_converter"

    def inputs(self) -> tuple[list[str], list[str]]:
        return ["data"], ["text", "url", "id", "language", "token_count"]

    def outputs(self) -> tuple[list[str], list[str]]:
        return ["data"], [
            "text", "url", "docId", "lang", "token_count",
            "quality_bucket_id", "quality_bucket_name",
        ]

    def process(self, batch: DocumentBatch) -> DocumentBatch:
        df = batch.to_pandas()
        out = pd.DataFrame({
            "text": df.get("text", ""),
            "url": df["url"].fillna("empty") if "url" in df.columns else "empty",
            "docId": df["id"].fillna("") if "id" in df.columns else "",
            "lang": df["language"].fillna("en") if "language" in df.columns else "en",
            "token_count": df.get("token_count", 0),
            "quality_bucket_id": df["quality_bucket_id"],
            "quality_bucket_name": df["quality_bucket_name"],
        })
        return DocumentBatch(task_id=batch.task_id, dataset_name=batch.dataset_name, data=out)


class FinePDFsEngWorkflow:
    """FinePDFs eng_Latn curation with filtering and quality bucketing.

    Pipeline: Read → TokenCountFilter → TruncationFilter →
    DuplicateCountFilter → QualityScoreBucketer → SchemaConvert → Write

    Args:
        input_path: S3 path to pre-split parquet files.
        output_path: S3 path for bucketed output.
        min_tokens: Minimum token count. Default 128.
        max_tokens: Maximum token count. Default 100000.
        filter_truncated: Drop truncated PDFs. Default True.
        max_duplicates: Max duplicate count. Default 10.
        n_buckets: Quality buckets. Default 10.
        min_quality_bucket: Lowest bucket to write. Default 0.
        max_quality_bucket: Highest bucket to write. Default 9.
        apply_normalization: Apply text cleanup. Default False.
        verbose: Print progress. Default True.
        max_files: Limit files for testing. Default None.
    """

    def __init__(
        self,
        output_path: str,
        input_path: str | None = None,
        pipeline_name: str = "finepdfs_eng_latn",
        min_tokens: int = 128,
        max_tokens: int = 100000,
        filter_truncated: bool = True,
        max_duplicates: int = 10,
        n_buckets: int = 10,
        min_quality_bucket: int = 0,
        max_quality_bucket: int = 9,
        apply_normalization: bool = False,
        verbose: bool = True,
        max_files: int | None = None,
    ):
        self.input_path = input_path
        self.output_path = output_path
        self.pipeline_name = pipeline_name
        self.min_tokens = min_tokens
        self.max_tokens = max_tokens
        self.filter_truncated = filter_truncated
        self.max_duplicates = max_duplicates
        self.n_buckets = n_buckets
        self.min_quality_bucket = min_quality_bucket
        self.max_quality_bucket = max_quality_bucket
        self.apply_normalization = apply_normalization
        self.verbose = verbose
        self.max_files = max_files

        self.score_type = "dclm"
        self.score_field = "dclm_scores"
        self.quantiles = get_default_quantiles(n_buckets, self.score_type)
        self.bucket_names = make_bucket_names(n_buckets, self.score_type)

    def run(self, executor: Any | None = None) -> Any:
        if self.verbose:
            active = self.bucket_names[self.min_quality_bucket:self.max_quality_bucket + 1]
            print(f"\nFinePDFs eng_Latn [dclm, {self.n_buckets} buckets] → {active}")
            print(f"  Filters: tokens=[{self.min_tokens}, {self.max_tokens}], "
                  f"truncated={'drop' if self.filter_truncated else 'keep'}, "
                  f"max_duplicates={self.max_duplicates}")
            if self.max_files:
                print(f"  Processing max {self.max_files} files")

        start = time.time()
        result = self._build_pipeline().run(executor=executor)
        elapsed = time.time() - start

        if self.verbose:
            print(f"\nDone in {elapsed:.1f}s ({elapsed / 60:.1f} min) → {self.output_path}")
        return result

    def _resolve_file_paths(self) -> list[str] | str:
        """Resolve input file paths, applying max_files limit if set.

        When max_files is None, returns the raw input_path string so
        FilePartitioningStage handles listing on a Ray worker.
        When max_files is set, pre-resolves the file list on the driver
        and slices to the exact count.
        """
        path = self.input_path or ""
        if not self.max_files:
            return path

        if path.startswith("s3://"):
            import s3fs
            fs = s3fs.S3FileSystem()
            prefix = path.replace("s3://", "").rstrip("/")
            all_files = sorted(f"s3://{f}" for f in fs.ls(prefix) if f.endswith(".parquet"))
        else:
            from pathlib import Path
            all_files = sorted(str(f) for f in Path(path).glob("*.parquet"))

        all_files = all_files[:self.max_files]
        logger.info("Resolved %d parquet files (max_files=%d) from %s", len(all_files), self.max_files, path)
        return all_files

    def _build_pipeline(self) -> Pipeline:
        from nemo_curator.stages.text.io.reader.parquet import ParquetReader

        pipeline = Pipeline(name=self.pipeline_name)

        # Resolve file list (applies max_files limit)
        file_paths = self._resolve_file_paths()

        # Read pre-split parquet files (128 MB each, standard reader)
        pipeline.add_stage(ParquetReader(
            file_paths=file_paths,
            files_per_partition=1,
            fields=[
                "text", "id", "url", "language", "token_count",
                "dclm_scores", "is_truncated", "duplicate_count",
            ],
        ))

        # Filter: token count range (wrapped for stats)
        pipeline.add_stage(StatsCollector(TokenCountFilter(
            min_tokens=self.min_tokens,
            max_tokens=self.max_tokens,
        )))

        # Filter: drop truncated PDFs
        if self.filter_truncated:
            pipeline.add_stage(StatsCollector(TruncationFilter(keep_truncated=False)))

        # Filter: drop heavily duplicated documents
        pipeline.add_stage(StatsCollector(DuplicateCountFilter(
            max_duplicates=self.max_duplicates,
        )))

        # Quality bucketing by DCLM scores
        pipeline.add_stage(QualityScoreBucketer(
            score_field=self.score_field,
            score_type=self.score_type,
            n_buckets=self.n_buckets,
            quantiles=self.quantiles,
            bucket_names=self.bucket_names,
        ))

        # Text normalization (optional)
        if self.apply_normalization:
            from nemo_curator.stages.text.modules.modifier import Modify
            from agi_data_curator.utils.dataset_normalizer import TextCleaner
            pipeline.add_stage(Modify(
                modifier_fn=TextCleaner(fix_encoding=True, normalize_whitespace=True, remove_invisible=True),
                input_fields="text",
            ))

        # Schema conversion + bucket routing + write
        pipeline.add_stage(_EngSchemaConverter())
        pipeline.add_stage(MultiBucketParquetWriter(
            output_path=self.output_path,
            min_bucket=self.min_quality_bucket,
            max_bucket=self.max_quality_bucket,
        ))

        return pipeline
