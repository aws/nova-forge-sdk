"""FinePDFs curation workflow with single-pass quality bucketing."""

from __future__ import annotations

import logging
import time
from typing import Any

import pandas as pd

from nemo_curator.pipeline import Pipeline
from nemo_curator.stages.base import ProcessingStage
from nemo_curator.tasks import DocumentBatch

from agi_data_curator.filtering.quality_bucketer import (
    get_default_quantiles,
    make_bucket_names,
    QualityScoreBucketer,
)

logger = logging.getLogger(__name__)


class _SchemaPlusRoutingConverter(ProcessingStage):
    """Project FinePDFs columns to output schema while preserving bucket routing columns."""

    name = "schema_plus_routing_converter"

    def inputs(self) -> tuple[list[str], list[str]]:
        return ["data"], ["text", "url", "id", "language"]

    def outputs(self) -> tuple[list[str], list[str]]:
        return ["data"], ["text", "url", "docId", "lang", "quality_bucket_id", "quality_bucket_name"]

    def process(self, batch: DocumentBatch) -> DocumentBatch:
        df = batch.to_pandas()
        out = pd.DataFrame({
            "text": df.get("text", ""),
            "url": df["url"].fillna("empty") if "url" in df.columns else "empty",
            "docId": df["id"].fillna("") if "id" in df.columns else "",
            "lang": df["language"].fillna("en") if "language" in df.columns else "en",
            "quality_bucket_id": df["quality_bucket_id"],
            "quality_bucket_name": df["quality_bucket_name"],
        })
        return DocumentBatch(task_id=batch.task_id, dataset_name=batch.dataset_name, data=out)


# Re-export for backward compatibility — canonical location is writers.multi_bucket_writer
from agi_data_curator.writers.multi_bucket_writer import MultiBucketParquetWriter  # noqa: F811,E402


class FinePDFsCurationWorkflow:
    """Curate FinePDFs dataset with quality bucketing in a single pipeline pass.

    Reads input parquet files once, assigns quality bucket IDs, converts schema,
    and routes documents to per-bucket output folders.

    Args:
        input_path: S3 or local path to input parquet files.
        output_path: Base output path. Each bucket writes to ``{output_path}/{bucket_name}/``.
        language: Language code (e.g. ``"jpn_Jpan"``).
        score_type: ``"dclm"`` for English, ``"fw_edu"`` for others.
        n_buckets: Number of quality buckets. Default 10.
        min_quality_bucket: Lowest bucket ID to write. Default 0.
        max_quality_bucket: Highest bucket ID to write. Default 9.
        save_all_buckets: Unused; kept for API compatibility.
        apply_normalization: Apply text encoding/whitespace normalization.
        verbose: Print progress to stdout.
    """

    def __init__(
        self,
        output_path: str,
        input_path: str | None = None,
        language: str = "eng_Latn",
        score_type: str = "dclm",
        n_buckets: int = 10,
        min_quality_bucket: int = 0,
        max_quality_bucket: int = 9,
        save_all_buckets: bool = True,
        apply_normalization: bool = False,
        verbose: bool = True,
        files_per_partition: int = 1,
        split_row_groups: bool | str = "auto",
        target_batch_size_mb: int = 512,
        max_files: int | None = None,
        memory_per_worker_gb: float = 4.0,
    ):
        self.input_path = input_path
        self.output_path = output_path
        self.language = language
        self.score_type = score_type
        self.n_buckets = n_buckets
        self.min_quality_bucket = min_quality_bucket
        self.max_quality_bucket = max_quality_bucket
        self.save_all_buckets = save_all_buckets
        self.apply_normalization = apply_normalization
        self.verbose = verbose
        self.files_per_partition = files_per_partition
        self.split_row_groups = split_row_groups
        self.target_batch_size_mb = target_batch_size_mb
        self.max_files = max_files
        self.memory_per_worker_gb = memory_per_worker_gb

        self.score_field = "dclm_scores" if score_type == "dclm" else "fw_edu_scores"
        self.quantiles = get_default_quantiles(n_buckets, score_type, language)
        self.bucket_names = make_bucket_names(n_buckets, score_type)

        # Only load columns the pipeline actually needs
        self._reader_fields = ["text", "id", "url", "language", self.score_field]

    def run(self, executor: Any | None = None) -> Any:
        if self.verbose:
            active = self.bucket_names[self.min_quality_bucket:self.max_quality_bucket + 1]
            print(f"\nFinePDFs [{self.score_type}, {self.n_buckets} buckets] → {active}")
            if self.max_files:
                print(f"Processing max {self.max_files} files")

        start = time.time()
        result = self._build_pipeline().run(executor=executor)
        elapsed = time.time() - start

        if self.verbose:
            mins = elapsed / 60
            print(f"\nDone in {elapsed:.1f}s ({mins:.1f} min) → {self.output_path}")
        return result

    def _build_pipeline(self) -> Pipeline:
        from agi_data_curator.loaders.parquet_reader import SmartParquetReader

        pipeline = Pipeline(name="finepdfs")
        pipeline.add_stage(SmartParquetReader(
            file_paths=self.input_path or "",
            files_per_partition=self.files_per_partition,
            fields=self._reader_fields,
            split_row_groups=self.split_row_groups,
            target_batch_size_mb=self.target_batch_size_mb,
            max_files=self.max_files,
            memory_per_worker_gb=self.memory_per_worker_gb,
        ))
        pipeline.add_stage(
            QualityScoreBucketer(
                score_field=self.score_field,
                score_type=self.score_type,
                n_buckets=self.n_buckets,
                quantiles=self.quantiles,
                bucket_names=self.bucket_names,
            )
        )

        if self.apply_normalization:
            from nemo_curator.stages.text.modules.modifier import Modify
            from agi_data_curator.utils.dataset_normalizer import TextCleaner
            pipeline.add_stage(Modify(
                modifier_fn=TextCleaner(fix_encoding=True, normalize_whitespace=True, remove_invisible=True),
                input_fields="text",
            ))

        pipeline.add_stage(_SchemaPlusRoutingConverter())
        pipeline.add_stage(MultiBucketParquetWriter(
            output_path=self.output_path,
            min_bucket=self.min_quality_bucket,
            max_bucket=self.max_quality_bucket,
        ))
        return pipeline