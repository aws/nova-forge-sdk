"""Arrow IPC read/write workflow."""
