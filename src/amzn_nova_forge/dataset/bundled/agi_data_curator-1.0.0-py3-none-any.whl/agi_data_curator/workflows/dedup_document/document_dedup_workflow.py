"""Document deduplication workflow (text + perceptual image hash).

Architecture:
    DocumentDedupWorkflow — single-pass dedup using MD5(text) + pHash(image).
        Hashes are computed distributed via Ray map_batches, duplicates are
        identified on the driver, and filtering happens distributed.

No GPU required — runs on CPU workers only.

Use DocumentDedupOrchestrator to construct a WorkflowOrchestrator that
wraps the workflow with checkpoint support.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from loguru import logger

from agi_data_curator.dedup.document_dedup import run_document_dedup
from agi_data_curator.pipeline.workflow import (
    WorkflowBase,
    WorkflowOrchestrator,
    WorkflowRunResult,
    WorkflowStep,
)


# ---------------------------------------------------------------------------
# Standalone Workflow
# ---------------------------------------------------------------------------


@dataclass
class DocumentDedupWorkflow(WorkflowBase):
    """Deduplicate multimodal documents by hashing text + perceptual image hash.

    Computes ``md5(text) + pHash(image)`` for each row, identifies duplicates
    on the driver (only the hash column is collected), and filters distributed.

    No GPU required.
    """

    input_path: str = ""
    output_path: str = ""
    text_field: str = "text"
    image_field: str = "image"
    input_format: Literal["parquet", "jsonl"] = "parquet"
    output_format: Literal["parquet", "jsonl"] = "parquet"
    output_num_files: int | None = None
    workflow_name: str = "document-deduplication"

    def run(self) -> WorkflowRunResult:
        logger.info(
            f"Starting document deduplication: input={self.input_path}, "
            f"text_field={self.text_field}, image_field={self.image_field}"
        )

        stats = run_document_dedup(
            input_path=self.input_path,
            output_path=self.output_path,
            text_field=self.text_field,
            image_field=self.image_field,
            input_format=self.input_format,
            output_format=self.output_format,
            output_num_files=self.output_num_files,
        )

        logger.info(
            f"Document dedup complete: {stats['input_count']} → {stats['output_count']} rows "
            f"({stats['duplicates_removed']} duplicates removed)"
        )
        return WorkflowRunResult(
            workflow_name=self.workflow_name,
            metadata={
                "output_path": self.output_path,
                **stats,
            },
        )


# ---------------------------------------------------------------------------
# Document Dedup Orchestrator
# ---------------------------------------------------------------------------


@dataclass
class DocumentDedupOrchestrator(WorkflowOrchestrator):
    """Orchestrator for document deduplication.

    Single-step DAG:
        document_dedup (no deps)

    Wraps DocumentDedupWorkflow with checkpoint support via
    _AGI_CURATOR_SUCCESS markers so re-runs skip completed steps.
    """

    input_path: str = ""
    output_path: str = ""
    text_field: str = "text"
    image_field: str = "image"
    input_format: Literal["parquet", "jsonl"] = "parquet"
    output_format: Literal["parquet", "jsonl"] = "parquet"
    output_num_files: int | None = None
    workflow_name: str = "document-deduplication"

    def __post_init__(self) -> None:
        if not self.input_path:
            raise ValueError("input_path is required")
        if not self.output_path:
            raise ValueError("output_path is required")

        self.steps = self._build_steps()

    def _build_steps(self) -> list[WorkflowStep]:
        steps: list[WorkflowStep] = []

        steps.append(WorkflowStep(
            name="document_dedup",
            workflow=DocumentDedupWorkflow(
                input_path=self.input_path,
                output_path=self.output_path,
                text_field=self.text_field,
                image_field=self.image_field,
                input_format=self.input_format,
                output_format=self.output_format,
                output_num_files=self.output_num_files,
            ),
            depends_on=[],
            output_path=self.output_path,
        ))

        return steps
