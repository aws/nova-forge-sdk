"""Topic classification workflow.

Reads data from a local/S3 directory **or** downloads from HuggingFace Hub,
classifies documents by topic using a vLLM-served model, and writes output
as Parquet with a ``topic`` column.

Supports two execution modes via the ``use_nemo_curator`` flag:

- ``use_nemo_curator: false`` (default) — Pure Ray Data pipeline. No NemoCurator
  or RAPIDS dependency. Can run on CPU-only platforms like AWS Glue for Ray.
- ``use_nemo_curator: true`` — NemoCurator Pipeline + xenna executor.

Usage::

    # Pure Ray (CPU) — default:
    python -m agi_data_curator.config.run \\
        --config-path $(pwd)/src/agi_data_curator/workflows/topic_classification \\
        --config-name topic_classification \\
        input_path=s3://bucket/data/ \\
        output_path=/tmp/curated/topic-classified

    # NemoCurator + xenna (GPU):
    python -m agi_data_curator.config.run \\
        --config-path $(pwd)/src/agi_data_curator/workflows/topic_classification \\
        --config-name topic_classification \\
        input_path=s3://bucket/data/ \\
        output_path=/tmp/curated/topic-classified \\
        use_nemo_curator=true
"""

from __future__ import annotations

import logging
import time
from typing import Any

from agi_data_curator.filtering.topic_classifier import TopicClassifier
from agi_data_curator.pipeline.curation_pipeline import CurationPipeline

logger = logging.getLogger(__name__)


class TopicClassificationWorkflow:
    """Classify documents by topic via a vLLM-served model.

    Data source (mutually exclusive — ``input_path`` takes precedence):
    - ``input_path``: Read parquet files from a local or S3 directory.
    - ``download_dir`` + ``repo_id``: Download from HuggingFace Hub first.

    Pipeline: [Read Parquet] -> TopicClassifier -> [Write Parquet]

    Args:
        output_path: Output path for classified Parquet files.
        input_path: Local or S3 path to existing parquet data.
        download_dir: Local or S3 path for HuggingFace downloads.
        use_nemo_curator: If True, run via NemoCurator + xenna. Default False (pure Ray).
        pipeline_name: Name for reporting.
        repo_id: HuggingFace dataset repo.
        subset: Dataset subset.
        text_field: Text column name.
        files_per_partition: Parquet files per reader partition (input_path mode).
        vllm_base_url: Base URL of the running vLLM server.
        model_name: Model name for the vLLM API request.
        system_prompt: System prompt for the classifier.
        allowed_topics: If set, only keep documents with these topics.
        max_tokens: Max generation tokens for classification.
        temperature: Sampling temperature.
        batch_size: Documents per API call.
        request_timeout: HTTP timeout per request.
        include_all_dimensions: Emit all 10 taxonomy columns.
        max_concurrent: Concurrent HTTP requests to vLLM per actor.
        concurrency: Number of Ray actors. Total vLLM load is
            concurrency × max_concurrent. Default 1.
        verbose: Print progress.
    """

    def __init__(
        self,
        output_path: str,
        input_path: str | None = None,
        download_dir: str | None = None,
        use_nemo_curator: bool = False,
        pipeline_name: str = "topic_classification",
        repo_id: str = "nvidia/Nemotron-Pretraining-Dataset-sample",
        subset: str = "Nemotron-CC-High-Quality",
        text_field: str = "text",
        files_per_partition: int = 1,
        vllm_base_url: str | list[str] = "http://localhost:8000",
        model_name: str = "EssentialAI/eai-distill-0.5b",
        system_prompt: str | None = None,
        allowed_topics: list[str] | None = None,
        max_tokens: int = 100,
        temperature: float = 0.0,
        batch_size: int = 32,
        request_timeout: int = 120,
        verbose: bool = True,
        max_concurrent: int = 32,
        include_all_dimensions: bool = False,
        concurrency: int = 1,
    ):
        self.output_path = output_path
        self.input_path = input_path
        self.download_dir = download_dir
        self.use_nemo_curator = use_nemo_curator
        self.pipeline_name = pipeline_name
        self.repo_id = repo_id
        self.subset = subset
        self.text_field = text_field
        self.files_per_partition = files_per_partition
        self.vllm_base_url = vllm_base_url
        self.model_name = model_name
        self.system_prompt = system_prompt
        self.allowed_topics = allowed_topics
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.batch_size = batch_size
        self.request_timeout = request_timeout
        self.verbose = verbose
        self.max_concurrent = max_concurrent
        self.include_all_dimensions = include_all_dimensions
        self.concurrency = concurrency

        if not input_path and not download_dir:
            raise ValueError("Either input_path or download_dir must be provided")

    def run(self, executor: Any | None = None) -> Any:
        if self.verbose:
            source = self.input_path if self.input_path else f"{self.repo_id}/{self.subset}"
            mode = "NemoCurator (xenna)" if self.use_nemo_curator else "Pure Ray Data"
            print(f"\nTopic Classification [{source}] — {mode}")
            print(f"  vLLM: {self.vllm_base_url} (model: {self.model_name})")
            print(f"  Output: {self.output_path}")

        start = time.time()

        # Build the classifier stage
        classifier_kwargs: dict = {
            "vllm_base_url": self.vllm_base_url,
            "model_name": self.model_name,
            "text_field": self.text_field,
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
            "batch_size": self.batch_size,
            "request_timeout": self.request_timeout,
            "max_concurrent": self.max_concurrent,
            "include_all_dimensions": self.include_all_dimensions,
        }
        if self.system_prompt is not None:
            classifier_kwargs["system_prompt"] = self.system_prompt
        if self.allowed_topics is not None:
            classifier_kwargs["allowed_topics"] = self.allowed_topics

        classifier = TopicClassifier(**classifier_kwargs)

        # Handle HuggingFace download if no input_path
        input_path = self.input_path
        if not input_path:
            input_path = self._download_from_hf()

        # Run via CurationPipeline (auto-selects Ray Data or xenna)
        pipeline = CurationPipeline(
            stages=[classifier],
            input_path=input_path,
            output_path=self.output_path,
            use_nemo_curator=self.use_nemo_curator,
            concurrency=self.concurrency,
            verbose=self.verbose,
        )
        result = pipeline.run(executor=executor)

        elapsed = time.time() - start
        if self.verbose:
            print(f"\nDone in {elapsed:.1f}s ({elapsed / 60:.1f} min) -> {self.output_path}")
        return result

    def _download_from_hf(self) -> str:
        """Download dataset from HuggingFace and return the local path."""
        from agi_data_curator.loaders.huggingface import download_hf_dataset

        if self.verbose:
            print(f"  Downloading {self.repo_id}/{self.subset} -> {self.download_dir}")
        assert self.download_dir is not None, "download_dir required for dataset download"
        return download_hf_dataset(
            repo_id=self.repo_id,
            download_dir=self.download_dir,
            subset=self.subset,
        )
