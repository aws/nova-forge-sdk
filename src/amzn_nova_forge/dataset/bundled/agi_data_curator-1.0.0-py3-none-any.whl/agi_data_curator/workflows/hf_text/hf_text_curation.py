"""HuggingFace text curation workflow.

Downloads from HuggingFace Hub, normalizes text, applies quality filters
(word count, URLs, repeated lines/paragraphs, n-grams, token count),
and writes output as JSONL.

Replaces scripts/examples/hf_text_curation.py as the primary implementation.

Usage::

    python -m agi_data_curator.config.run \
        --config-path $(pwd)/src/agi_data_curator/workflows/hf_text \
        --config-name hf_text_curation \
        download_dir=s3://bucket/hf-downloads \
        output_path=s3://bucket/curated/nemotron-cc
"""

from __future__ import annotations

import logging
import time
from typing import Any

from nemo_curator.pipeline import Pipeline
from nemo_curator.stages.text.filters.heuristic_filter import (
    BoilerPlateStringFilter,
    MeanWordLengthFilter,
    NonAlphaNumericFilter,
    RepeatedLinesFilter,
    RepeatedParagraphsFilter,
    RepeatingDuplicateNGramsFilter,
    RepeatingTopNGramsFilter,
    TokenCountFilter,
    UrlsFilter,
    WordCountFilter,
)
from nemo_curator.stages.text.io.writer.jsonl import JsonlWriter
from nemo_curator.stages.text.modifiers.unicode_reformatter import UnicodeReformatter
from nemo_curator.stages.text.modules.modifier import Modify
from nemo_curator.stages.text.modules.score_filter import ScoreFilter

from agi_data_curator.loaders.huggingface import HuggingFaceDatasetStage
from agi_data_curator.tracking.stats_collector import StatsCollector
from agi_data_curator.utils.dataset_normalizer import DatasetNormalizer, TextCleaner

logger = logging.getLogger(__name__)


class HFTextCurationWorkflow:
    """HuggingFace text curation with normalization and quality filtering.

    Pipeline: Download → TextCleaner → DatasetNormalizer → UnicodeReformatter
    → WordCount → URLs → RepeatedLines → RepeatedParagraphs → RepeatingNGrams
    → TokenCount → JsonlWriter

    All filter stages are wrapped with StatsCollector for per-filter
    curation reporting.

    Args:
        download_dir: Local or S3 path for HuggingFace downloads.
        output_path: Output path for curated JSONL.
        pipeline_name: Name for reporting. Default ``"hf_text_curation"``.
        repo_id: HuggingFace dataset repo. Default Nemotron-CC sample.
        subset: Dataset subset. Default ``"Nemotron-CC-High-Quality"``.
        text_field: Text column name. Default ``"text"``.
        tokenizer: HF tokenizer for token count filter.
        hf_token: Optional HuggingFace token for private datasets.
        min_words: Minimum word count. Default 50.
        max_words: Maximum word count. Default 20000.
        min_tokens: Minimum token count. Default 128.
        max_tokens: Maximum token count. Default 16000.
        max_url_ratio: Max URL-to-text ratio. Default 0.3.
        max_repeated_lines: Max repeated line fraction. Default 0.3.
        max_repeated_paragraphs: Max repeated paragraph ratio. Default 0.7.
        max_repeating_ngrams: Max repeating n-gram ratio. Default 0.2.
        verbose: Print progress. Default True.
    """

    def __init__(
        self,
        download_dir: str,
        output_path: str,
        pipeline_name: str = "hf_text_curation",
        repo_id: str = "nvidia/Nemotron-Pretraining-Dataset-sample",
        subset: str = "Nemotron-CC-High-Quality",
        text_field: str = "text",
        tokenizer: str = "microsoft/Phi-3-mini-4k-instruct",
        hf_token: str | None = None,
        min_words: int = 50,
        max_words: int = 20000,
        min_tokens: int = 128,
        max_tokens: int = 16000,
        max_url_ratio: float = 0.3,
        max_non_alpha_ratio: float = 0.5,
        max_boilerplate_ratio: float = 0.3,
        max_repeated_lines: float = 0.3,
        max_repeated_paragraphs: float = 0.7,
        max_repeating_ngrams: float = 0.2,
        max_char_repetition: float = 0.2,
        min_mean_word_length: float = 3.0,
        max_mean_word_length: float = 10.0,
        verbose: bool = True,
    ):
        self.download_dir = download_dir
        self.output_path = output_path
        self.pipeline_name = pipeline_name
        self.repo_id = repo_id
        self.subset = subset
        self.text_field = text_field
        self.tokenizer = tokenizer
        self.hf_token = hf_token
        self.min_words = min_words
        self.max_words = max_words
        self.min_tokens = min_tokens
        self.max_tokens = max_tokens
        self.max_url_ratio = max_url_ratio
        self.max_non_alpha_ratio = max_non_alpha_ratio
        self.max_boilerplate_ratio = max_boilerplate_ratio
        self.max_repeated_lines = max_repeated_lines
        self.max_repeated_paragraphs = max_repeated_paragraphs
        self.max_repeating_ngrams = max_repeating_ngrams
        self.max_char_repetition = max_char_repetition
        self.min_mean_word_length = min_mean_word_length
        self.max_mean_word_length = max_mean_word_length
        self.verbose = verbose

    def run(self, executor: Any | None = None) -> Any:
        if self.verbose:
            print(f"\nHF Text Curation [{self.repo_id}/{self.subset}]")
            print(f"  Filters: words=[{self.min_words}, {self.max_words}], "
                  f"tokens=[{self.min_tokens}, {self.max_tokens}]")
            print(f"  Output: {self.output_path}")

        start = time.time()
        result = self._build_pipeline().run(executor=executor)
        elapsed = time.time() - start

        if self.verbose:
            print(f"\nDone in {elapsed:.1f}s ({elapsed / 60:.1f} min) → {self.output_path}")
        return result

    def _build_pipeline(self) -> Pipeline:
        pipeline = Pipeline(name=self.pipeline_name)
        tf = self.text_field

        # 1. Download dataset files from HuggingFace Hub
        assert HuggingFaceDatasetStage is not None, "nemo-curator required for HFTextCurationWorkflow"
        pipeline.add_stage(HuggingFaceDatasetStage(
            repo_id=self.repo_id,
            download_dir=self.download_dir,
            subset=self.subset,
            verbose=self.verbose,
        ))

        # 2. Fix encoding, whitespace, and invisible characters
        pipeline.add_stage(Modify(
            modifier_fn=TextCleaner(fix_encoding=True, normalize_whitespace=True, remove_invisible=True),
            input_fields=tf,
        ))

        # 3. Normalize newlines and control characters
        pipeline.add_stage(Modify(
            modifier_fn=DatasetNormalizer(
                target_format="standard",
                strip_whitespace=True,
                normalize_newlines=True,
                remove_control_chars=True,
                max_consecutive_newlines=2,
            ),
            input_fields=tf,
        ))

        # 4. Unicode normalization
        pipeline.add_stage(Modify(modifier_fn=UnicodeReformatter(), input_fields=tf))

        # 5. Filter by word count
        pipeline.add_stage(StatsCollector(ScoreFilter(
            WordCountFilter(min_words=self.min_words, max_words=self.max_words),
            text_field=tf, score_field="words",
        ), name="WordCountFilter"))

        # 6. Filter by alphanumeric ratio
        pipeline.add_stage(StatsCollector(ScoreFilter(
            NonAlphaNumericFilter(max_non_alpha_numeric_to_text_ratio=self.max_non_alpha_ratio),
            text_field=tf, score_field="alpha",
        ), name="AlphanumericFilter"))

        # 7. Filter by URL density
        pipeline.add_stage(StatsCollector(ScoreFilter(
            UrlsFilter(max_url_to_text_ratio=self.max_url_ratio),
            text_field=tf, score_field="urls",
        ), name="UrlsFilter"))

        # 8. Filter by boilerplate
        pipeline.add_stage(StatsCollector(ScoreFilter(
            BoilerPlateStringFilter(max_boilerplate_string_ratio=self.max_boilerplate_ratio),
            text_field=tf, score_field="boilerplate",
        ), name="BoilerplateFilter"))

        # 9. Filter by repeated lines
        pipeline.add_stage(StatsCollector(ScoreFilter(
            RepeatedLinesFilter(max_repeated_line_fraction=self.max_repeated_lines),
            text_field=tf, score_field="rep_lines",
        ), name="RepeatedLinesFilter"))

        # 10. Filter by repeated paragraphs
        pipeline.add_stage(StatsCollector(ScoreFilter(
            RepeatedParagraphsFilter(max_repeated_paragraphs_ratio=self.max_repeated_paragraphs),
            text_field=tf, score_field="rep_para",
        ), name="RepeatedParagraphsFilter"))

        # 11. Filter by repeating n-grams
        pipeline.add_stage(StatsCollector(ScoreFilter(
            RepeatingTopNGramsFilter(n=2, max_repeating_ngram_ratio=self.max_repeating_ngrams),
            text_field=tf, score_field="rep_ngrams",
        ), name="RepeatingNGramsFilter"))

        # 12. Filter by character repetition
        pipeline.add_stage(StatsCollector(ScoreFilter(
            RepeatingDuplicateNGramsFilter(n=5, max_repeating_duplicate_ngram_ratio=self.max_char_repetition),
            text_field=tf, score_field="char_rep",
        ), name="CharRepetitionFilter"))

        # 13. Filter by mean word length
        pipeline.add_stage(StatsCollector(ScoreFilter(
            MeanWordLengthFilter(min_mean_word_length=self.min_mean_word_length, max_mean_word_length=self.max_mean_word_length),
            text_field=tf, score_field="word_len",
        ), name="MeanWordLengthFilter"))

        # 14. Filter by token count
        pipeline.add_stage(StatsCollector(ScoreFilter(
            TokenCountFilter(
                hf_model_name=self.tokenizer,
                hf_token=self.hf_token,
                min_tokens=self.min_tokens,
                max_tokens=self.max_tokens,
            ),
            text_field=tf, score_field="tokens",
        ), name="TokenCountFilter"))

        # 15. Write curated output as JSONL
        pipeline.add_stage(JsonlWriter(self.output_path, fields=None))

        return pipeline
