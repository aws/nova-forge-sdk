"""Data writers for various output formats.

All writers extend NemoCurator's ``ProcessingStage`` and require
``pip install agi-data-curator[gpu]``.
"""

try:
    from agi_data_curator.writers.arrow_writer import ArrowWriter
    from agi_data_curator.writers.chunked_parquet_writer import ChunkedParquetWriter
    from agi_data_curator.writers.multi_bucket_writer import MultiBucketParquetWriter

    __all__ = [
        "ArrowWriter",
        "ChunkedParquetWriter",
        "MultiBucketParquetWriter",
    ]
except ImportError:
    __all__ = []
