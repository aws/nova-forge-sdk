"""
Chunked Parquet writer stage.

Splits large DocumentBatches into multiple parquet files with controlled
size, matching the behavior of save_parquet_in_chunks from the
Prepare-PT-parquet notebooks.

Training data loaders (NeMo, Megatron) expect many small parquet files.
This writer ensures output files are ~max_size_mb each.
"""

from __future__ import annotations

import gc
import hashlib
import logging
import uuid
from dataclasses import dataclass, field
from typing import Any

import pandas as pd

from nemo_curator.stages.base import ProcessingStage
from nemo_curator.tasks import DocumentBatch, FileGroupTask
from nemo_curator.utils.client_utils import is_remote_url

logger = logging.getLogger(__name__)


def _estimate_df_size_bytes(df: pd.DataFrame) -> int:
    """Fast estimate of DataFrame in-memory size.

    Uses df.memory_usage(deep=True) which accounts for actual string
    object sizes without materializing copies. Falls back to a
    row-count heuristic if deep introspection is slow.
    """
    try:
        return int(df.memory_usage(deep=True).sum())
    except Exception:
        # Fallback: assume ~500 bytes per row average
        return len(df) * 500


def _chunk_df_by_size(
    df: pd.DataFrame, max_size_bytes: int
) -> list[pd.DataFrame]:
    """Split a DataFrame into chunks where each chunk's estimated size
    doesn't exceed max_size_bytes.

    Uses row-proportional splitting based on total estimated size.
    Avoids .copy() — uses .iloc slices which are zero-copy views
    that become independent on write.
    """
    total_size = _estimate_df_size_bytes(df)

    if total_size <= max_size_bytes or len(df) <= 1:
        return [df]

    # Calculate rows per chunk proportionally
    avg_row_size = max(1, total_size // len(df))
    rows_per_chunk = max(1, max_size_bytes // avg_row_size)

    chunks = []
    for start in range(0, len(df), rows_per_chunk):
        end = min(start + rows_per_chunk, len(df))
        chunks.append(df.iloc[start:end])

    return chunks


@dataclass
class ChunkedParquetWriter(ProcessingStage[DocumentBatch, FileGroupTask]):
    """Writes DocumentBatches as multiple parquet files with size control.

    Splits large batches into multiple files capped at max_size_mb each.
    Output files are named: {hash}_part_{N}.parquet

    Matches the behavior of save_parquet_in_chunks from the
    Prepare-PT-parquet notebooks.

    Args:
        path: Output directory (S3 or local).
        max_size_mb: Maximum estimated size per output file in MB.
            Default 60 (parquet compression typically gives ~3x reduction,
            so 60 MB JSON → ~20 MB parquet).
        compression: Parquet compression codec. Default "snappy".
        fields: Optional list of columns to write. None = all.
        write_kwargs: Additional kwargs for DataFrame.to_parquet().
    """

    path: str = ""
    max_size_mb: int = 60
    compression: str = "snappy"
    fields: list[str] | None = None
    write_kwargs: dict[str, Any] = field(default_factory=dict)
    name: str = "chunked_parquet_writer"

    def __post_init__(self):
        from fsspec.core import url_to_fs
        self.storage_options = (self.write_kwargs or {}).get("storage_options", {})
        self.fs, self._fs_path = url_to_fs(self.path, **self.storage_options)

    def inputs(self) -> tuple[list[str], list[str]]:
        return ["data"], []

    def outputs(self) -> tuple[list[str], list[str]]:
        return ["data"], []

    def process(self, batch: DocumentBatch) -> FileGroupTask:
        df = batch.to_pandas()
        total_rows = len(df)

        # Column selection
        if self.fields is not None:
            available = [c for c in self.fields if c in df.columns]
            if available:
                df = df[available]

        # Split into size-limited chunks
        max_bytes = self.max_size_mb * 1024 * 1024
        chunks = _chunk_df_by_size(df, max_bytes)
        del df

        # Generate base filename from task metadata
        if source_files := batch._metadata.get("source_files"):
            base_name = hashlib.md5(
                str(source_files).encode() + batch.task_id.encode()
            ).hexdigest()[:12]
        else:
            base_name = uuid.uuid4().hex[:12]

        # Write each chunk
        written_paths: list[str] = []
        write_kwargs = {"index": None, "compression": self.compression}
        write_kwargs.update(self.write_kwargs)

        for i, chunk_df in enumerate(chunks):
            filename = f"{base_name}_part_{i + 1}.parquet"
            file_path = self.fs.sep.join([self._fs_path, filename])

            if is_remote_url(self.path):
                file_path_with_protocol = self.fs.unstrip_protocol(file_path)
            else:
                file_path_with_protocol = file_path

            chunk_df.to_parquet(file_path_with_protocol, **write_kwargs)
            written_paths.append(file_path_with_protocol)

            logger.debug(
                "Wrote chunk %d/%d: %d rows to %s",
                i + 1, len(chunks), len(chunk_df), file_path_with_protocol,
            )
            del chunk_df

        gc.collect()

        logger.info(
            "ChunkedParquetWriter: %d rows → %d files (max %d MB each) in %s",
            total_rows, len(written_paths), self.max_size_mb, self.path,
        )

        return FileGroupTask(
            task_id=batch.task_id,
            dataset_name=batch.dataset_name,
            data=written_paths,
            _metadata={
                **batch._metadata,
                "format": "parquet",
                "num_chunks": len(written_paths),
            },
            _stage_perf=batch._stage_perf,
        )