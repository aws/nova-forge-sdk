"""
Arrow IPC writer stage — matches ParquetWriter pattern exactly.

Writes DocumentBatches as Parquet files (the standard interchange format).

Usage::

    from agi_data_curator.writers.arrow_writer import ArrowWriter

    pipeline = Pipeline([
        ArrowReader(file_paths="s3://bucket/arrows/"),
        HeuristicFilter(min_words=50),
        ArrowWriter(path="s3://bucket/curated/"),
    ])
"""

from __future__ import annotations

import gc
import logging
from dataclasses import dataclass, field
from typing import Any

import pyarrow as pa

from nemo_curator.stages.resources import Resources
from nemo_curator.stages.text.io.writer.base import BaseWriter
from nemo_curator.tasks import DocumentBatch

from agi_data_curator.loaders.arrow_reader import (
    _WRITER_MEMORY_PER_WORKER_GB,
    _compute_cpus_per_worker,
)
from agi_data_curator.utils.arrow_helpers import apply_schema

logger = logging.getLogger(__name__)


@dataclass
class ArrowWriter(BaseWriter):
    """Writer that writes a DocumentBatch to a Parquet file.

    Matches the ParquetWriter pattern. Supports schema enforcement
    and configurable compression.

    Args:
        write_kwargs: Additional kwargs for ``DataFrame.to_parquet()``.
        compression: Parquet compression codec. Default "snappy".
        schema: Optional pa.Schema to cast data before writing.
    """

    write_kwargs: dict[str, Any] = field(default_factory=dict)
    file_extension: str = "parquet"
    name: str = "arrow_writer"
    compression: str = "snappy"
    schema: pa.Schema | None = None

    # Dynamically computed at import time based on system memory.
    # Limits the autoscaler from spawning too many concurrent writers
    # whose combined memory would exceed available RAM.
    resources = Resources(
        cpus=_compute_cpus_per_worker(_WRITER_MEMORY_PER_WORKER_GB)
    )

    def write_data(self, task: DocumentBatch, file_path: str) -> None:
        """Write data to Parquet file using pandas DataFrame.to_parquet.

        Matches ParquetWriter.write_data() pattern.
        Supports both local and S3 paths. For S3, uses the fsspec
        filesystem from BaseWriter to ensure proper credentials
        and retry handling.

        Parallel writing is handled by the pipeline framework —
        multiple ArrowWriter actors run concurrently, each writing
        a different DocumentBatch to a different file path.
        """
        df = task.to_pandas()

        # Field selection (from BaseWriter)
        if self.fields is not None:
            available = [c for c in self.fields if c in df.columns]
            df = df[available]

        # Schema enforcement
        if self.schema is not None:
            table = pa.Table.from_pandas(df, preserve_index=False)
            table = apply_schema(table, self.schema)
            df = table.to_pandas()
            del table

        # Build kwargs with defaults
        write_kwargs = {
            "index": None,
            "compression": self.compression,
        }
        write_kwargs.update(self.write_kwargs)

        # Pass storage_options for S3/remote filesystem support.
        # BaseWriter.__post_init__ extracts these from write_kwargs
        # and creates self.fs / self.storage_options.
        if hasattr(self, "storage_options") and self.storage_options:
            write_kwargs.setdefault("storage_options", self.storage_options)

        # Use the fsspec filesystem directly for remote paths to ensure
        # proper credentials, retries, and connection pooling.
        if hasattr(self, "fs") and self.fs.protocol != "file":
            write_kwargs["filesystem"] = self.fs

        num_rows = len(df)
        df.to_parquet(file_path, **write_kwargs)

        logger.debug(
            "Wrote %d rows to %s (compression=%s)",
            num_rows, file_path, self.compression,
        )

        # Free DataFrame memory after writing to disk
        del df
        gc.collect()
