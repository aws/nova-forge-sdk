"""Multi-bucket parquet writer — routes documents to per-bucket output folders.

Shared by all FinePDFs workflow variants (fra_Latn, eng_Latn, etc.).
"""

from __future__ import annotations

from typing import Any

from nemo_curator.stages.base import ProcessingStage
from nemo_curator.tasks import DocumentBatch


class MultiBucketParquetWriter(ProcessingStage):
    """Route documents to per-bucket output folders based on quality_bucket_name.

    Args:
        output_path: Base output path. Each bucket writes to ``{output_path}/{bucket_name}/``.
        min_bucket: Minimum bucket ID to write (inclusive).
        max_bucket: Maximum bucket ID to write (inclusive).
    """

    name = "multi_bucket_parquet_writer"

    def __init__(self, output_path: str, min_bucket: int = 0, max_bucket: int = 9):
        self.output_path = output_path.rstrip("/")
        self.min_bucket = min_bucket
        self.max_bucket = max_bucket
        self._writers: dict[str, Any] = {}

    def inputs(self) -> tuple[list[str], list[str]]:
        return ["data"], ["quality_bucket_id", "quality_bucket_name"]

    def outputs(self) -> tuple[list[str], list[str]]:
        return ["data"], []

    def _get_writer(self, bucket_name: str) -> Any:
        if bucket_name not in self._writers:
            from nemo_curator.stages.text.io.writer.parquet import ParquetWriter
            self._writers[bucket_name] = ParquetWriter(f"{self.output_path}/{bucket_name}")
        return self._writers[bucket_name]

    def process(self, batch: DocumentBatch) -> DocumentBatch:
        df = batch.to_pandas()
        in_range = (
            (df["quality_bucket_id"] >= self.min_bucket)
            & (df["quality_bucket_id"] <= self.max_bucket)
        )
        df_filtered = df[in_range]

        if df_filtered.empty:
            del df
            return DocumentBatch(task_id=batch.task_id, dataset_name=batch.dataset_name, data=df_filtered)

        for bucket_name, group_df in df_filtered.groupby("quality_bucket_name"):
            keep = [c for c in group_df.columns if c not in ("quality_bucket_id", "quality_bucket_name")]
            out = group_df[keep].reset_index(drop=True)
            self._get_writer(bucket_name).process(
                DocumentBatch(
                    task_id=f"{batch.task_id}_{bucket_name}",
                    dataset_name=batch.dataset_name,
                    data=out,
                )
            )
            del out

        # Return empty batch — all rows already written to per-bucket writers
        empty = df_filtered.iloc[0:0]
        del df, df_filtered
        return DocumentBatch(task_id=batch.task_id, dataset_name=batch.dataset_name, data=empty)
