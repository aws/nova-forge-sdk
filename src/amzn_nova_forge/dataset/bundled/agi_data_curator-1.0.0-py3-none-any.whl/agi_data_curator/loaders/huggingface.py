"""HuggingFace dataset download and extraction.

Provides two interfaces:

- :func:`download_hf_dataset` — standalone function, no NemoCurator required.
  Used by ``CurationPipeline``-based workflows (pure Ray path).

- :class:`HuggingFaceDatasetStage` — NemoCurator pipeline stage.
  Requires ``pip install agi-data-curator[gpu]``.
"""

from __future__ import annotations

import logging
import os
from typing import Any

import pyarrow.parquet as pq

logger = logging.getLogger(__name__)


class HuggingFaceURLGenerator:
    """Generate parquet file URLs for a HuggingFace dataset.

    Args:
        repo_id: HuggingFace dataset repository ID.
        subset: Optional subset/config name to filter files.
    """

    def __init__(self, repo_id: str, subset: str | None = None):
        self.repo_id = repo_id
        self.subset = subset

    def generate_urls(self) -> list[str]:
        from huggingface_hub import list_repo_files

        all_files = list_repo_files(self.repo_id, repo_type="dataset")
        prefix = f"{self.subset}/" if self.subset else ""
        files = [f for f in all_files if f.startswith(prefix) and f.endswith(".parquet")]
        base = f"https://huggingface.co/datasets/{self.repo_id}/resolve/main"
        return [f"{base}/{f}" for f in files]


class HuggingFaceDownloader:
    """Download HuggingFace dataset files to local or S3 paths.

    Args:
        download_dir: Destination directory (local path or ``s3://`` URI).
        verbose: Log progress for each file.
    """

    def __init__(self, download_dir: str, verbose: bool = False):
        self._download_dir = download_dir
        self._verbose = verbose
        self._is_s3 = download_dir.startswith("s3://")
        if not self._is_s3:
            os.makedirs(download_dir, exist_ok=True)

    def _get_output_filename(self, url: str) -> str:
        return os.path.basename(url)

    def _output_path(self, url: str) -> str:
        name = self._get_output_filename(url)
        sep = "/" if self._is_s3 else os.sep
        return f"{self._download_dir.rstrip(sep)}{sep}{name}"

    def _already_downloaded(self, path: str) -> bool:
        if self._is_s3:
            import s3fs
            fs = s3fs.S3FileSystem()
            key = path[5:]  # strip "s3://"
            return fs.exists(key) and fs.info(key).get("size", 0) > 0
        return os.path.exists(path) and os.path.getsize(path) > 0

    def _parse_url(self, url: str) -> tuple[str, str]:
        """Return (repo_id, filename) from a HuggingFace resolve URL."""
        parts = url.split("/resolve/main/")
        if len(parts) != 2:
            raise ValueError(f"Unexpected URL format: {url}")
        repo_id = parts[0].split("/datasets/")[1]
        return repo_id, parts[1]

    def _download_to_path(self, url: str, dest: str) -> tuple[bool, str | None]:
        import shutil
        import tempfile
        from huggingface_hub import hf_hub_download

        repo_id, filename = self._parse_url(url)
        try:
            with tempfile.TemporaryDirectory() as tmp:
                local = hf_hub_download(  # type: ignore[call-overload]
                    repo_id=repo_id,
                    filename=filename,
                    repo_type="dataset",
                    local_dir=tmp,
                    local_dir_use_symlinks=False,
                )
                if dest.startswith("s3://"):
                    import s3fs
                    s3fs.S3FileSystem().put(local, dest[5:])
                else:
                    os.makedirs(os.path.dirname(dest), exist_ok=True)
                    shutil.copy2(local, dest)
            return True, None
        except Exception as exc:
            return False, str(exc)

    def download(self, url: str) -> str | None:
        dest = self._output_path(url)

        if self._already_downloaded(dest):
            if self._verbose:
                logger.info("Already downloaded: %s", dest)
            return dest

        success, error = self._download_to_path(url, dest)
        if success:
            return dest
        logger.error("Download failed for %s: %s", dest, error)
        return None


def download_hf_dataset(
    repo_id: str,
    download_dir: str,
    subset: str | None = None,
    verbose: bool = True,
) -> str:
    """Download a HuggingFace dataset to a local or S3 directory.

    This is a standalone convenience function (no NemoCurator pipeline
    required).  It downloads all parquet files for the given repo/subset
    and returns the directory path containing the downloaded files.

    Args:
        repo_id: HuggingFace dataset repository ID.
        download_dir: Local or S3 path to store downloaded files.
        subset: Optional dataset subset/config name.
        verbose: Log per-file download progress.

    Returns:
        The *download_dir* path (files are written there).
    """
    url_gen = HuggingFaceURLGenerator(repo_id=repo_id, subset=subset)
    downloader = HuggingFaceDownloader(download_dir=download_dir, verbose=verbose)

    urls = url_gen.generate_urls()
    if verbose:
        logger.info(
            "Downloading %d file(s) from %s/%s -> %s",
            len(urls), repo_id, subset or "", download_dir,
        )

    for url in urls:
        downloader.download(url)

    return download_dir


# ── NemoCurator pipeline stage (requires nemo-curator) ───────────────
# Only available when nemo-curator is installed.

def _build_nemo_classes() -> type | None:
    """Lazily define HuggingFaceDatasetStage to avoid top-level NemoCurator imports."""
    try:
        from collections.abc import Iterator

        from nemo_curator.stages.text.download.base import (
            DocumentDownloader,
            DocumentDownloadExtractStage,
            DocumentExtractor,
            DocumentIterator,
            URLGenerator,
        )

        class _NemoURLGenerator(URLGenerator):
            def __init__(self, repo_id: str, subset: str | None = None):
                self._gen = HuggingFaceURLGenerator(repo_id=repo_id, subset=subset)

            def generate_urls(self) -> list[str]:
                return self._gen.generate_urls()

        class _NemoDownloader(DocumentDownloader):
            def __init__(self, download_dir: str, verbose: bool = False):
                self._dl = HuggingFaceDownloader(download_dir=download_dir, verbose=verbose)

            def _get_output_filename(self, url: str) -> str:
                return self._dl._get_output_filename(url)

            def _download_to_path(self, url: str, dest: str) -> tuple[bool, str | None]:
                return self._dl._download_to_path(url, dest)

            def download(self, url: str) -> str | None:
                return self._dl.download(url)

        class _ParquetIterator(DocumentIterator):
            def iterate(self, file_path: str) -> Iterator[dict[str, Any]]:
                if file_path.startswith("s3://"):
                    import s3fs
                    with s3fs.S3FileSystem().open(file_path[5:], "rb") as f:
                        table = pq.read_table(f)
                else:
                    if not os.path.exists(file_path):
                        return
                    table = pq.read_table(file_path)
                yield from table.to_pylist()

            def output_columns(self) -> list[str]:
                return []

        class _PassThroughExtractor(DocumentExtractor):
            def extract(self, record: dict[str, Any]) -> dict[str, Any] | None:
                return record

            def input_columns(self) -> list[str]:
                return []

            def output_columns(self) -> list[str]:
                return []

        class HuggingFaceDatasetStage(DocumentDownloadExtractStage):
            """Download and extract a HuggingFace dataset as a NeMo Curator pipeline stage.

            Requires ``nemo-curator`` (``pip install agi-data-curator[gpu]``).

            Args:
                repo_id: HuggingFace dataset repository ID.
                download_dir: Local or S3 path to cache downloaded files.
                subset: Optional dataset subset/config name.
                verbose: Log per-file download progress.
            """

            def __init__(
                self,
                repo_id: str,
                download_dir: str,
                subset: str | None = None,
                verbose: bool = True,
            ):
                self.repo_id = repo_id
                self.subset = subset
                super().__init__(
                    url_generator=_NemoURLGenerator(repo_id=repo_id, subset=subset),
                    downloader=_NemoDownloader(download_dir=download_dir, verbose=verbose),
                    iterator=_ParquetIterator(),
                    extractor=_PassThroughExtractor(),
                    add_filename_column=True,
                )

            def get_description(self) -> str:
                suffix = f"/{self.subset}" if self.subset else ""
                return f"HuggingFace: {self.repo_id}{suffix}"

        return HuggingFaceDatasetStage

    except ImportError:
        return None


# Expose HuggingFaceDatasetStage at module level if nemo-curator is available
HuggingFaceDatasetStage = _build_nemo_classes()
