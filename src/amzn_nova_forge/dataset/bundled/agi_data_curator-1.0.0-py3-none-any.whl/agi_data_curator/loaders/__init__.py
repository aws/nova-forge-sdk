"""Data loaders for various sources.

:func:`download_hf_dataset` is always available (no NemoCurator required).
The NemoCurator pipeline stages (``ArrowReader``, ``HuggingFaceDatasetStage``,
``SmartParquetReader``) require ``pip install agi-data-curator[gpu]``.
"""

# Always available — standalone function, no NemoCurator dependency
from agi_data_curator.loaders.huggingface import download_hf_dataset

# NemoCurator pipeline stages — require nemo-curator
try:
    from agi_data_curator.loaders.arrow_reader import ArrowReader, ArrowReaderStage
    from agi_data_curator.loaders.huggingface import HuggingFaceDatasetStage
    from agi_data_curator.loaders.parquet_reader import SmartParquetReader, SmartParquetReaderStage

    _NEMO_AVAILABLE = True
except ImportError:
    _NEMO_AVAILABLE = False

__all__ = [
    "download_hf_dataset",
]

if _NEMO_AVAILABLE:
    __all__.extend([
        "ArrowReader",
        "ArrowReaderStage",
        "HuggingFaceDatasetStage",
        "SmartParquetReader",
        "SmartParquetReaderStage",
    ])
