"""
Smart Parquet reader with row-group-level splitting for large files.

Provides ``SmartParquetReaderStage`` and ``SmartParquetReader`` that read
parquet files using ``pyarrow.parquet.ParquetFile`` row-group-by-row-group
instead of loading entire files into memory. This avoids the xenna
executor's "Number of output references" error on large files (see
https://github.com/NVIDIA-NeMo/Curator/issues/1152).

For small files, reads all row groups at once (same speed as upstream
``ParquetReaderStage``). For large files, yields manageable chunks that
stay under a configurable memory threshold.

Memory safety:
- Dynamic CPU resource budgeting limits concurrent Ray actors based on
  available RAM (same pattern as ArrowReaderStage).
- Row-group streaming caps peak memory per actor to ~target_batch_size_mb.
- Column selection via ``fields`` avoids loading unused columns.
- Explicit ``gc.collect()`` after each flush releases memory to OS.

Usage::

    from agi_data_curator.loaders.parquet_reader import SmartParquetReader

    # Auto-splits large files, reads small files whole
    reader = SmartParquetReader(
        file_paths="s3://bucket/data/",
        fields=["text", "id", "url", "language", "fw_edu_scores"],
        split_row_groups="auto",
        target_batch_size_mb=512,
    )
"""

from __future__ import annotations

import gc
import logging
import os
from dataclasses import dataclass, field
from typing import Any, Literal

import pandas as pd
import psutil
import pyarrow as pa
import pyarrow.parquet as pq

from nemo_curator.stages.base import CompositeStage
from nemo_curator.stages.file_partitioning import FilePartitioningStage
from nemo_curator.stages.resources import Resources
from nemo_curator.stages.text.io.reader.base import BaseReader
from nemo_curator.tasks import DocumentBatch, FileGroupTask, _EmptyTask

logger = logging.getLogger(__name__)

_S3_RETRY_CONFIG = {"max_attempts": 10, "mode": "standard"}

# Parquet in-memory is typically 3-5x larger than on-disk.
_PARQUET_EXPANSION_FACTOR = 4.0


def _cast_strings_to_large_string(df: pd.DataFrame) -> pd.DataFrame:
    """Cast pyarrow string columns to large_string to avoid 2 GB offset
    overflow during Ray serialization.

    PyArrow string type uses int32 offsets (max 2 GB per column chunk).
    Large documents (full PDFs) can exceed this during Ray IPC transfer.
    large_string uses int64 offsets, avoiding the limit.
    """
    for col in df.columns:
        if hasattr(df[col].dtype, "pyarrow_dtype"):
            if df[col].dtype.pyarrow_dtype == pa.string():
                df[col] = df[col].astype(pd.ArrowDtype(pa.large_string()))
    return df


def _compute_cpus_per_worker(
    memory_per_worker_gb: float,
    min_cpus: float = 1.0,
) -> float:
    """Dynamically compute CPUs to request per worker based on memory.

    Limits total concurrent workers so their combined memory fits in RAM.
    Formula: cpus_per_worker = total_cpus / max_workers
    where max_workers = usable_memory / memory_per_worker.

    Same pattern as ArrowReaderStage for consistency.
    """
    total_memory_gb = psutil.virtual_memory().total / (1024**3)
    total_cpus = float(os.cpu_count() or 64)

    # Reserve 20% for OS, Ray overhead, object store
    usable_memory_gb = total_memory_gb * 0.8
    max_workers = max(1, int(usable_memory_gb / memory_per_worker_gb))
    cpus_per_worker = total_cpus / max_workers

    # Clamp to reasonable range
    cpus_per_worker = max(min_cpus, min(cpus_per_worker, total_cpus / 2))

    logger.info(
        "SmartParquetReader resources: %.1f GB total, %.1f GB/worker -> "
        "max %d workers, %.1f CPUs/worker (of %.0f total)",
        total_memory_gb, memory_per_worker_gb,
        max_workers, cpus_per_worker, total_cpus,
    )
    return round(cpus_per_worker, 1)


def _get_filesystem(sample_path: str, storage_options: dict[str, Any]) -> Any:
    """Create a cached filesystem for S3/remote paths. Returns None for local."""
    if "://" not in sample_path:
        return None
    import fsspec

    opts = dict(storage_options)
    protocol = sample_path.split("://")[0]
    if protocol == "s3":
        config_kwargs = opts.setdefault("config_kwargs", {})
        config_kwargs.setdefault("retries", _S3_RETRY_CONFIG)
    fs, _ = fsspec.core.url_to_fs(sample_path, **opts)
    return fs


def _open_parquet_file(path: str, fs: Any | None) -> pq.ParquetFile:
    """Open a ParquetFile with filesystem support."""
    if fs is not None:
        fs_path = fs._strip_protocol(path)
        return pq.ParquetFile(fs.open(fs_path, "rb"))
    return pq.ParquetFile(path)


def _should_split(path: str, fs: Any | None, target_bytes: int) -> bool:
    """Check if a file's estimated in-memory size exceeds the target.

    Uses on-disk file size × expansion factor as a fast heuristic.
    """
    try:
        if fs is not None:
            fs_path = fs._strip_protocol(path)
            info = fs.info(fs_path)
            disk_size = info.get("size", 0)
        else:
            disk_size = os.path.getsize(path)
        estimated_memory = disk_size * _PARQUET_EXPANSION_FACTOR
        return estimated_memory > target_bytes
    except Exception:
        logger.warning("Could not determine size of %s, assuming split needed", path)
        return True


def _read_file_whole(
    path: str, fs: Any | None, fields: list[str] | None,
) -> pd.DataFrame:
    """Read an entire parquet file at once (fast path for small files)."""
    kwargs: dict[str, Any] = {"engine": "pyarrow", "dtype_backend": "pyarrow"}
    if fields is not None:
        kwargs["columns"] = fields
    if fs is not None:
        kwargs["filesystem"] = fs
        fs_path = fs._strip_protocol(path)
        df = pd.read_parquet(fs_path, **kwargs)
    else:
        df = pd.read_parquet(path, **kwargs)
    return _cast_strings_to_large_string(df)


def _read_file_by_row_groups(
    path: str,
    fs: Any | None,
    fields: list[str] | None,
    target_bytes: int,
) -> list[pd.DataFrame]:
    """Read a parquet file row-group-by-row-group, returning DataFrames
    that stay under target_bytes each.

    Accumulates row groups until the next one would push over the limit,
    then flushes. Each returned DataFrame is small enough for Ray's
    object store (avoids the multi-reference error).
    """
    pf = _open_parquet_file(path, fs)
    num_row_groups = pf.metadata.num_row_groups

    if num_row_groups == 0:
        logger.warning("Empty parquet file: %s", path)
        return []

    logger.info(
        "Reading %s by row groups: %d groups, target %d MB/batch",
        path, num_row_groups, target_bytes // (1024 * 1024),
    )

    results: list[pd.DataFrame] = []
    accumulated_tables: list[pa.Table] = []
    accumulated_bytes = 0

    for rg_idx in range(num_row_groups):
        table = pf.read_row_group(rg_idx, columns=fields)
        table_bytes = table.nbytes

        # Flush if adding this row group would exceed target
        if accumulated_tables and (accumulated_bytes + table_bytes) > target_bytes:
            combined = pa.concat_tables(accumulated_tables)
            df = _cast_strings_to_large_string(combined.to_pandas(types_mapper=pd.ArrowDtype))
            results.append(df)
            del combined, accumulated_tables, df
            gc.collect()
            accumulated_tables = []
            accumulated_bytes = 0

        accumulated_tables.append(table)
        accumulated_bytes += table_bytes
        del table

    # Flush remaining
    if accumulated_tables:
        combined = pa.concat_tables(accumulated_tables)
        df = _cast_strings_to_large_string(combined.to_pandas(types_mapper=pd.ArrowDtype))
        results.append(df)
        del combined, accumulated_tables, df
        gc.collect()

    logger.info("Split %s into %d batches (from %d row groups)", path, len(results), num_row_groups)
    return results


@dataclass
class SmartParquetReaderStage(BaseReader):
    """Parquet reader that splits large files by row group.

    For small files, reads whole (same as upstream ParquetReaderStage).
    For large files, reads row-group-by-row-group and returns multiple
    DocumentBatch objects via fan-out.

    Memory safety:
    - ``resources`` limits concurrent actors via CPU budgeting (computed
      dynamically from system RAM at import time).
    - Row-group streaming caps peak memory per actor.
    - ``gc.collect()`` after each flush releases memory to OS.

    Fan-out behavior:
    - When ``split_row_groups`` triggers splitting, ``process()`` returns
      ``list[DocumentBatch]`` and ``ray_stage_spec()`` declares
      ``IS_FANOUT_STAGE: True``. The xenna executor distributes each
      batch to downstream stages independently.
    - If fan-out causes issues with a specific executor version, set
      ``split_row_groups=False`` and use ``files_per_partition=1`` with
      smaller files (pre-split with the NVIDIA split_large_files script).

    Args:
        fields: Column selection. Only these columns are loaded.
        read_kwargs: Passthrough kwargs (e.g. ``storage_options``).
        split_row_groups: ``True`` always splits, ``False`` never splits,
            ``"auto"`` splits only when estimated size exceeds target.
        target_batch_size_mb: Max in-memory size per output batch in MB.
    """

    name: str = "smart_parquet_reader"
    split_row_groups: bool | str = "auto"
    target_batch_size_mb: int = 512
    memory_per_worker_gb: float = 4.0

    def __post_init__(self):
        """Compute per-instance resource budget.

        ``memory_per_worker_gb`` controls how many concurrent reader actors
        Ray will schedule. Set higher for large files (e.g., 20 for 4+ GB
        parquet files) to limit concurrency and prevent OOM. Set lower for
        small files (e.g., 2-4) to maximize parallelism.
        """
        cpus = _compute_cpus_per_worker(self.memory_per_worker_gb)
        self.resources = Resources(cpus=cpus)

    def read_data(
        self,
        paths: list[str],
        read_kwargs: dict[str, Any] | None = None,
        fields: list[str] | None = None,
    ) -> pd.DataFrame:
        """Read parquet files whole. Called by BaseReader.process() when
        split_row_groups is False (single DocumentBatch return)."""
        read_kwargs = {} if read_kwargs is None else dict(read_kwargs)
        storage_options = read_kwargs.pop("storage_options", {})
        fs = _get_filesystem(paths[0], storage_options) if paths else None

        dfs: list[pd.DataFrame] = []
        for path in paths:
            dfs.append(_read_file_whole(path, fs, fields))

        if not dfs:
            msg = f"No data read from parquet files: {paths}"
            raise ValueError(msg)

        result = pd.concat(dfs, ignore_index=True)
        del dfs
        gc.collect()
        return result

    def process(self, task: FileGroupTask) -> DocumentBatch | list[DocumentBatch]:
        """Override BaseReader.process() to support fan-out for large files.

        Returns list[DocumentBatch] when splitting is active (fan-out).
        Returns single DocumentBatch otherwise (standard path).
        """
        effective_read_kwargs: dict[str, Any] = {}
        if self.read_kwargs:
            effective_read_kwargs.update(self.read_kwargs)
        storage_options = effective_read_kwargs.pop("storage_options", {})

        target_bytes = self.target_batch_size_mb * 1024 * 1024
        fs = _get_filesystem(task.data[0], storage_options) if task.data else None

        all_dfs: list[pd.DataFrame] = []
        needs_split = False

        for path in task.data:
            if self.split_row_groups == "auto":
                do_split = _should_split(path, fs, target_bytes)
            elif self.split_row_groups is True or self.split_row_groups == "true":
                do_split = True
            else:
                do_split = False

            if do_split:
                needs_split = True
                chunks = _read_file_by_row_groups(path, fs, self.fields, target_bytes)
                all_dfs.extend(chunks)
            else:
                all_dfs.append(_read_file_whole(path, fs, self.fields))

        if not all_dfs:
            msg = f"No data read from files in task {task.task_id}"
            raise ValueError(msg)

        # No splitting needed — return single DocumentBatch (standard path)
        if not needs_split or len(all_dfs) == 1:
            result = pd.concat(all_dfs, ignore_index=True) if len(all_dfs) > 1 else all_dfs[0]
            del all_dfs
            gc.collect()
            return DocumentBatch(
                task_id=f"{task.task_id}_processed",
                dataset_name=task.dataset_name,
                data=result,
                _metadata=task._metadata,
            )

        # Fan-out: return multiple DocumentBatch objects, each under target size.
        # Each batch flows through downstream stages independently.
        batches: list[DocumentBatch] = []
        for i, df in enumerate(all_dfs):
            if df is not None and len(df) > 0:
                batches.append(DocumentBatch(
                    task_id=f"{task.task_id}_chunk_{i}",
                    dataset_name=task.dataset_name,
                    data=df,
                    _metadata={**task._metadata, "chunk_index": i},
                ))
        del all_dfs
        gc.collect()

        logger.info(
            "SmartParquetReader: task %s → %d batches (split_row_groups=%s)",
            task.task_id, len(batches), self.split_row_groups,
        )
        return batches

    def ray_stage_spec(self) -> dict[str, Any]:
        """Declare fan-out capability for the xenna executor.

        IS_FANOUT_STAGE tells the executor that process() may return
        a list of tasks, each of which should be routed to downstream
        stages independently. This is the same mechanism used by
        FilePartitioningStage.
        """
        from nemo_curator.backends.experimental.utils import RayStageSpecKeys
        return {RayStageSpecKeys.IS_FANOUT_STAGE: True}


@dataclass
class SmartParquetReader(CompositeStage[_EmptyTask, DocumentBatch]):
    """Composite stage for reading parquet files with large-file support.

    Decomposes into:
    1. ``FilePartitioningStage`` — partitions files into groups
    2. ``SmartParquetReaderStage`` — reads files, splitting large ones

    Drop-in replacement for upstream ``ParquetReader`` that handles
    multi-GB parquet files without the xenna output reference error.

    Ray parallelism:
    - ``FilePartitioningStage`` creates one ``FileGroupTask`` per partition
      (controlled by ``files_per_partition`` or ``blocksize``).
    - Each ``SmartParquetReaderStage`` actor processes one partition.
    - Dynamic CPU budgeting (``Resources(cpus=N)``) limits concurrent
      actors so their combined memory fits in available RAM.
    - When a file is split by row groups, the actor fans out multiple
      ``DocumentBatch`` objects — each flows through downstream stages
      as an independent unit of work.

    Args:
        file_paths: S3 or local path to parquet files.
        files_per_partition: Files per Ray actor. Default 1.
        blocksize: Alternative to files_per_partition (e.g. ``"1GB"``).
        fields: Column selection — only load these columns.
        read_kwargs: Passthrough kwargs (e.g. ``storage_options``).
        file_extensions: Extensions to match. Default ``[".parquet"]``.
        split_row_groups: ``True``, ``False``, or ``"auto"`` (default).
        target_batch_size_mb: Max batch size in MB. Default 512.
    """

    file_paths: str | list[str] = ""
    files_per_partition: int | None = None
    blocksize: int | str | None = None
    fields: list[str] | None = None
    read_kwargs: dict[str, Any] | None = None
    file_extensions: list[str] = field(default_factory=lambda: [".parquet"])
    task_type: Literal["document"] = "document"
    split_row_groups: bool | str = "auto"
    target_batch_size_mb: int = 512
    memory_per_worker_gb: float = 4.0
    _generate_ids: bool = False
    _assign_ids: bool = False
    name: str = "smart_parquet_reader"
    max_files: int | None = None

    def __post_init__(self):
        super().__init__()
        if self.read_kwargs is not None:
            self.storage_options = self.read_kwargs.get("storage_options", {})

    def decompose(self) -> list:
        return [
            FilePartitioningStage(
                file_paths=self.file_paths,
                files_per_partition=self.files_per_partition,
                blocksize=self.blocksize,
                file_extensions=self.file_extensions,
                limit=self.max_files,
                storage_options=(
                    self.read_kwargs.get("storage_options", {})
                    if self.read_kwargs is not None
                    else None
                ),
            ),
            SmartParquetReaderStage(
                fields=self.fields,
                read_kwargs=self.read_kwargs or {},
                split_row_groups=self.split_row_groups,
                target_batch_size_mb=self.target_batch_size_mb,
                memory_per_worker_gb=self.memory_per_worker_gb,
                _generate_ids=self._generate_ids,
                _assign_ids=self._assign_ids,
            ),
        ]

    def get_description(self) -> str:
        parts = [f"Read parquet files from {self.file_paths}"]
        if self.files_per_partition:
            parts.append(f"{self.files_per_partition} files/partition")
        if self.fields:
            parts.append(f"columns: {self.fields}")
        parts.append(f"split_row_groups={self.split_row_groups}")
        parts.append(f"target_batch={self.target_batch_size_mb}MB")
        return ", ".join(parts)
