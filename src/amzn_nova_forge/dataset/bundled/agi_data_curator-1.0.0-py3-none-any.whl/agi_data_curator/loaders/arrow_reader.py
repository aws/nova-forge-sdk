"""
Arrow IPC reader stages — matches ParquetReader pattern exactly.

Two classes:
- ``ArrowReaderStage(BaseReader)`` — reads Arrow IPC files from a
  FileGroupTask into a DocumentBatch. Used by the pipeline runner.
- ``ArrowReader(CompositeStage)`` — decomposes into FilePartitioningStage
  + ArrowReaderStage. Drop-in replacement for ParquetReader.

Memory-efficient: uses streaming RecordBatch iteration instead of
loading entire files into memory. This caps peak memory per worker
to ~1 RecordBatch (a few MB) instead of the entire file (many GB).

Usage::

    from agi_data_curator.loaders.arrow_reader import ArrowReader

    pipeline = Pipeline([
        ArrowReader(file_paths="s3://bucket/arrows/", doc_separator="[DOC]"),
        HeuristicFilter(min_words=50),
        ParquetWriter(path="s3://bucket/curated/"),
    ])
"""

from __future__ import annotations

import gc
import io
import logging
import os
from dataclasses import dataclass, field
from typing import Any, Iterator, Literal

import pandas as pd
import psutil
import pyarrow as pa
import pyarrow.ipc as ipc

from nemo_curator.stages.base import CompositeStage
from nemo_curator.stages.file_partitioning import FilePartitioningStage
from nemo_curator.stages.resources import Resources
from nemo_curator.stages.text.io.reader.base import BaseReader
from nemo_curator.tasks import DocumentBatch, _EmptyTask

from agi_data_curator.utils.arrow_helpers import (
    ARROW_EXTENSIONS,
    apply_schema,
    split_documents_vectorized,
)

logger = logging.getLogger(__name__)

# S3 retry config
_S3_RETRY_CONFIG = {"max_attempts": 10, "mode": "standard"}

# Estimated peak memory per worker across the ENTIRE pipeline chain.
# A single Arrow file flows: Reader (19 GB) → ScoreFilter (45 GB peak) → Writer (5 GB).
# The ScoreFilter holds input + filtered copy + scores = ~2.5× the file size.
# We size for the WORST CASE (ScoreFilter) so the autoscaler accounts for
# the full pipeline memory, not just the reader.
_READER_MEMORY_PER_WORKER_GB = 45.0
# Writer memory is lower — it receives the filtered DataFrame and writes to disk.
_WRITER_MEMORY_PER_WORKER_GB = 10.0


def _compute_cpus_per_worker(
    memory_per_worker_gb: float,
    min_cpus: float = 1.0,
) -> float:
    """Dynamically compute CPUs to request per worker based on memory.

    The goal: limit total concurrent workers so their combined memory
    fits within available RAM. We do this by requesting enough CPUs
    per worker that the autoscaler can't spawn too many.

    Formula:
        max_workers = total_memory_gb / memory_per_worker_gb
        cpus_per_worker = total_cpus / max_workers

    This uses ALL available CPUs (no hardcoded limits) while ensuring
    memory safety through the CPU-based scheduling constraint.
    """
    total_memory_gb = psutil.virtual_memory().total / (1024**3)
    total_cpus = float(os.cpu_count() or 64)

    # Reserve 20% of memory for OS, Ray overhead, object store
    usable_memory_gb = total_memory_gb * 0.8
    max_workers = max(1, int(usable_memory_gb / memory_per_worker_gb))
    cpus_per_worker = total_cpus / max_workers

    # Clamp to reasonable range
    cpus_per_worker = max(min_cpus, min(cpus_per_worker, total_cpus / 2))

    logger.info(
        "Dynamic resources: %.1f GB total, %.1f GB/worker -> "
        "max %d workers, %.1f CPUs/worker (of %.0f total)",
        total_memory_gb, memory_per_worker_gb,
        max_workers, cpus_per_worker, total_cpus,
    )
    return round(cpus_per_worker, 1)


@dataclass
class ArrowReaderStage(BaseReader):
    """Stage that reads Arrow IPC files into a DocumentBatch.

    Accepts FileGroupTasks created by FilePartitioningStage and reads
    the Arrow IPC file contents into DocumentBatches (pandas DataFrames
    backed by PyArrow).

    Uses streaming RecordBatch iteration to cap peak memory per worker
    to approximately one RecordBatch at a time, rather than loading
    entire files into memory.

    Supports optional [DOC] splitting and schema enforcement.

    Args:
        fields: If specified, only read these columns.
        read_kwargs: Additional kwargs (e.g. ``storage_options``).
        doc_separator: Optional separator for splitting multi-document
            text fields. If None, no splitting is done.
        text_field: Column to split when doc_separator is set.
        schema: Optional pa.Schema to cast tables to.
    """

    name: str = "arrow_reader"
    doc_separator: str | None = None
    text_field: str = "text"
    schema: pa.Schema | None = None

    # Dynamically computed at import time based on system memory.
    # Limits the autoscaler from spawning too many concurrent readers
    # whose combined memory would exceed available RAM.
    resources = Resources(
        cpus=_compute_cpus_per_worker(_READER_MEMORY_PER_WORKER_GB)
    )

    def read_data(
        self,
        paths: list[str],
        read_kwargs: dict[str, Any] | None = None,
        fields: list[str] | None = None,
    ) -> pd.DataFrame:
        """Read Arrow IPC files and return a pandas DataFrame.

        Streams RecordBatches one at a time to avoid loading entire
        files into memory. Each batch is immediately processed
        (column selection, schema enforcement, [DOC] splitting)
        and converted to a small pandas DataFrame. Only the
        processed DataFrames are accumulated and concatenated at
        the end.
        """
        read_kwargs = {} if read_kwargs is None else dict(read_kwargs)
        storage_options = read_kwargs.pop("storage_options", {})

        # Auto-derive fields from text_field if not explicitly set.
        # This ensures we only load the columns needed, dramatically
        # reducing memory for Arrow files with many columns.
        if fields is None and self.text_field:
            fields = [self.text_field]
            logger.info(
                "fields not set — auto-selecting [%s] from text_field. "
                "Override with fields=[...] to include more columns.",
                self.text_field,
            )

        # Create cached filesystem
        fs = self._get_filesystem(paths[0], storage_options) if paths else None

        # Process files in streaming fashion — one RecordBatch at a time.
        # We incrementally concat to avoid holding 2x memory (list + concat result).
        result: pd.DataFrame | None = None

        for path in paths:
            for batch in self._iter_batches(path, fs):
                df = self._process_batch(batch, fields)
                del batch  # free Arrow memory immediately
                if df is not None and len(df) > 0:
                    if result is None:
                        result = df
                    else:
                        result = pd.concat([result, df], ignore_index=True)
                    del df
            # Force GC after each file to release Arrow/pandas memory
            # back to the OS before processing the next file
            gc.collect()

        if result is None or len(result) == 0:
            msg = f"No data read from Arrow files: {paths}"
            raise ValueError(msg)

        return result

    def _process_batch(
        self, batch: pa.RecordBatch, fields: list[str] | None
    ) -> pd.DataFrame | None:
        """Process a single RecordBatch: select columns, cast schema,
        split docs, convert to pandas.

        Returns None if the batch is empty after processing.
        """
        table = pa.Table.from_batches([batch])

        if table.num_rows == 0:
            return None

        # Column selection
        if fields is not None:
            available = [f for f in fields if f in table.column_names]
            if available:
                table = table.select(available)

        # Schema enforcement
        table = apply_schema(table, self.schema)

        # Convert to pandas
        df = table.to_pandas(types_mapper=pd.ArrowDtype)
        del table

        # [DOC] splitting
        if self.doc_separator is not None:
            df = split_documents_vectorized(
                df, self.doc_separator, self.text_field
            )

        if len(df) == 0:
            return None

        return df

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _get_filesystem(
        sample_path: str, storage_options: dict[str, Any]
    ) -> Any:
        """Create a cached filesystem for S3 paths."""
        if "://" not in sample_path:
            return None
        import fsspec

        opts = dict(storage_options)
        protocol = sample_path.split("://")[0]
        if protocol == "s3":
            config_kwargs = opts.setdefault("config_kwargs", {})
            config_kwargs.setdefault("retries", _S3_RETRY_CONFIG)
        fs, _ = fsspec.core.url_to_fs(sample_path, **opts)
        return fs

    @staticmethod
    def _iter_batches(
        path: str, fs: Any
    ) -> Iterator[pa.RecordBatch]:
        """Yield RecordBatches from an Arrow IPC file one at a time.

        Tries IPC Stream format first, falls back to IPC File format.
        For IPC File format, iterates over batches to avoid loading
        the entire file into memory.
        """
        if fs is not None:
            fs_path = fs._strip_protocol(path)
            try:
                with fs.open(fs_path, "rb") as f:
                    reader = ipc.open_stream(f)
                    for batch in reader:
                        if batch.num_rows > 0:
                            yield batch
                return
            except (pa.ArrowInvalid, pa.ArrowNotImplementedError):
                # Fall back to IPC File format — must read into memory
                # for seekable access, but iterate batches
                data = fs.cat_file(fs_path)
                buf = io.BytesIO(data)
                del data
                try:
                    reader = ipc.open_file(buf)
                    for i in range(reader.num_record_batches):
                        batch = reader.get_batch(i)
                        if batch.num_rows > 0:
                            yield batch
                finally:
                    del buf
                return
        else:
            # Local file
            with open(path, "rb") as f:
                raw = f.read()
            buf = io.BytesIO(raw)
            del raw

            try:
                # Try IPC File format first for local (more common)
                reader = ipc.open_file(buf)
                for i in range(reader.num_record_batches):
                    batch = reader.get_batch(i)
                    if batch.num_rows > 0:
                        yield batch
            except (pa.ArrowInvalid, pa.ArrowNotImplementedError):
                buf.seek(0)
                reader = ipc.open_stream(buf)
                for batch in reader:
                    if batch.num_rows > 0:
                        yield batch
            finally:
                del buf


@dataclass
class ArrowReader(CompositeStage[_EmptyTask, DocumentBatch]):
    """Composite stage for reading Arrow IPC files.

    Decomposes into:
    1. ``FilePartitioningStage`` — partitions files into groups
    2. ``ArrowReaderStage`` — reads file groups into DocumentBatches

    Matches the ParquetReader pattern exactly.

    Args:
        file_paths: Path or list of paths to Arrow files (S3 or local).
        files_per_partition: Number of files per partition.
        blocksize: Target partition size (alternative to files_per_partition).
        fields: If specified, only read these columns.
        read_kwargs: Additional kwargs (e.g. ``storage_options``).
        file_extensions: Extensions to match. Default [".arrow", ".ipc"].
        doc_separator: Optional [DOC] separator for splitting.
        text_field: Column to split. Default "text".
        schema: Optional pa.Schema to enforce.
    """

    file_paths: str | list[str] = ""
    files_per_partition: int | None = None
    blocksize: int | str | None = None
    fields: list[str] | None = None
    read_kwargs: dict[str, Any] | None = None
    file_extensions: list[str] = field(
        default_factory=lambda: list(ARROW_EXTENSIONS)
    )
    task_type: Literal["document"] = "document"
    doc_separator: str | None = None
    text_field: str = "text"
    schema: pa.Schema | None = None
    _generate_ids: bool = False
    _assign_ids: bool = False
    name: str = "arrow_reader"

    def __post_init__(self):
        """Initialize parent class after dataclass initialization."""
        super().__init__()
        if self.read_kwargs is not None:
            self.storage_options = self.read_kwargs.get("storage_options", {})

    def decompose(self) -> list:
        """Decompose into file partitioning and Arrow reading stages."""
        return [
            FilePartitioningStage(
                file_paths=self.file_paths,
                files_per_partition=self.files_per_partition,
                blocksize=self.blocksize,
                file_extensions=self.file_extensions,
                storage_options=(
                    self.read_kwargs.get("storage_options", {})
                    if self.read_kwargs is not None
                    else None
                ),
            ),
            ArrowReaderStage(
                fields=self.fields,
                read_kwargs=self.read_kwargs or {},
                doc_separator=self.doc_separator,
                text_field=self.text_field,
                schema=self.schema,
                _generate_ids=self._generate_ids,
                _assign_ids=self._assign_ids,
            ),
        ]

    def get_description(self) -> str:
        """Get a description of this composite stage."""
        parts = [f"Read Arrow IPC files from {self.file_paths}"]
        if self.files_per_partition:
            parts.append(f"with {self.files_per_partition} files per partition")
        elif self.blocksize:
            parts.append(f"with target blocksize {self.blocksize}")
        if self.fields:
            parts.append(f"reading columns: {self.fields}")
        if self.doc_separator:
            parts.append(f"splitting '{self.text_field}' on '{self.doc_separator}'")
        return ", ".join(parts)