"""Mapper workflow definitions."""
