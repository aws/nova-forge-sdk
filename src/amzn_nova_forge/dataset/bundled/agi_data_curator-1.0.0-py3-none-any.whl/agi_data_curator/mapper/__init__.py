"""Mapper module for AGIDataCurator."""
