"""Text deduplication workflows using NeMo Curator on Ray.

Architecture:
    ExactIdentificationWorkflow — runs exact dedup via NeMo ExactDeduplicationWorkflow
        → DuplicateRemovalWorkflow — removes identified duplicates (streaming)
    FuzzyIdentificationWorkflow — runs fuzzy dedup via NeMo FuzzyDeduplicationWorkflow
        → DuplicateRemovalWorkflow — removes identified duplicates (streaming)

Identification steps use CustomRayExecutor (actor pool, GPU-capable) for
NCCL-based shuffle. Removal steps use CustomRayDataExecutor (streaming) to
avoid materializing data on the head node.

Use TextDedupOrchestrator to construct a WorkflowOrchestrator that chains
these workflows with proper DAG dependencies.

Requires GPU-enabled Ray workers (cudf/RAPIDS dependency for identification).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

from loguru import logger

from nemo_curator.stages.deduplication.exact.workflow import ExactDeduplicationWorkflow
from nemo_curator.stages.deduplication.fuzzy.workflow import FuzzyDeduplicationWorkflow
from nemo_curator.stages.deduplication.id_generator import CURATOR_DEDUP_ID_STR
from nemo_curator.stages.text.deduplication.removal_workflow import TextDuplicatesRemovalWorkflow

from agi_data_curator.dedup.executor import CustomRayDataExecutor, CustomRayExecutor
from agi_data_curator.pipeline.workflow import (
    WorkflowBase,
    WorkflowOrchestrator,
    WorkflowRunResult,
    WorkflowStep,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _kill_stale_id_generator() -> None:
    """Kill any leftover id_generator actor from a previous run.

    NeMo Curator creates the actor with lifetime='detached', so it
    persists across job restarts and blocks new runs with
    'name is already taken'. Safe to call even if no actor exists.
    """
    import ray

    from nemo_curator.stages.deduplication.id_generator import (
        CURATOR_ID_GENERATOR_ACTOR_NAME,
    )

    try:
        ray.init(ignore_reinit_error=True)
        actor = ray.get_actor(
            name=CURATOR_ID_GENERATOR_ACTOR_NAME,
            namespace=CURATOR_ID_GENERATOR_ACTOR_NAME,
        )
        ray.kill(actor)
        logger.info("Killed stale id_generator actor from previous run")
    except (ValueError, Exception):
        pass  # No actor to kill — expected on fresh runs
    finally:
        ray.shutdown()


# ---------------------------------------------------------------------------
# Standalone Workflows (each is a single atomic job)
# ---------------------------------------------------------------------------


@dataclass
class ExactIdentificationWorkflow(WorkflowBase):
    """Exact (MD5 hash) duplicate identification via NeMo ExactDeduplicationWorkflow.

    Uses CustomRayExecutor to handle mixed GPU/CPU clusters.
    """

    input_path: str = ""
    output_path: str = ""
    text_field: str = "text"
    input_filetype: Literal["parquet", "jsonl"] = "parquet"
    input_blocksize: str = "256MiB"
    storage_options: dict = field(default_factory=dict)
    workflow_name: str = "exact-identification"

    def run(self) -> WorkflowRunResult:
        logger.info(f"Starting exact deduplication: input={self.input_path}")
        read_kwargs = {"storage_options": self.storage_options} if self.storage_options else None

        wf = ExactDeduplicationWorkflow(
            input_path=self.input_path,
            output_path=self.output_path,
            input_filetype=self.input_filetype,
            input_blocksize=self.input_blocksize,
            read_kwargs=read_kwargs,
            write_kwargs=read_kwargs,
            text_field=self.text_field,
            assign_id=True,
            id_field=None,
        )
        wf.run(executor=CustomRayExecutor())

        logger.info(f"Exact dedup IDs written to {self.output_path}")
        return WorkflowRunResult(
            workflow_name=self.workflow_name,
            metadata={"output_path": self.output_path},
        )


@dataclass
class FuzzyIdentificationWorkflow(WorkflowBase):
    """Fuzzy (MinHash + LSH) duplicate identification via NeMo FuzzyDeduplicationWorkflow.

    Uses CustomRayExecutor to handle mixed GPU/CPU clusters.
    """

    input_path: str = ""
    output_path: str = ""
    cache_path: str = ""
    text_field: str = "text"
    input_filetype: Literal["parquet", "jsonl"] = "parquet"
    input_blocksize: str = "256MiB"
    char_ngrams: int = 24
    num_bands: int = 20
    minhashes_per_band: int = 13
    seed: int = 42
    use_64_bit_hash: bool = False
    bands_per_iteration: int = 5
    storage_options: dict = field(default_factory=dict)
    workflow_name: str = "fuzzy-identification"

    def run(self) -> WorkflowRunResult:
        logger.info(f"Starting fuzzy deduplication: input={self.input_path}")
        read_kwargs = {"storage_options": self.storage_options} if self.storage_options else None

        # Kill any stale id_generator actor from a previous crashed run.
        # NeMo creates it with lifetime="detached" so it survives job restarts.
        _kill_stale_id_generator()

        wf = FuzzyDeduplicationWorkflow(
            input_path=self.input_path,
            cache_path=self.cache_path,
            output_path=self.output_path,
            input_filetype=self.input_filetype,
            input_blocksize=self.input_blocksize,
            read_kwargs=read_kwargs,
            cache_kwargs=read_kwargs,
            write_kwargs=read_kwargs,
            text_field=self.text_field,
            char_ngrams=self.char_ngrams,
            num_bands=self.num_bands,
            minhashes_per_band=self.minhashes_per_band,
            seed=self.seed,
            use_64_bit_hash=self.use_64_bit_hash,
            bands_per_iteration=self.bands_per_iteration,
        )
        wf.run(executor=CustomRayExecutor())

        logger.info(f"Fuzzy dedup IDs written to {self.output_path}")
        return WorkflowRunResult(
            workflow_name=self.workflow_name,
            metadata={"output_path": self.output_path},
        )


@dataclass
class DuplicateRemovalWorkflow(WorkflowBase):
    """Remove duplicates from a dataset using identified duplicate IDs.

    Uses CustomRayDataExecutor (streaming) to avoid materializing data on
    the head node's object store (prevents OutOfDiskError on large datasets).
    """

    input_path: str = ""
    ids_to_remove_path: str = ""
    id_generator_path: str | None = None
    output_path: str = ""
    input_filetype: Literal["parquet", "jsonl"] = "parquet"
    input_blocksize: str = "256MiB"
    output_filetype: Literal["parquet", "jsonl"] = "parquet"
    input_id_field: str | None = CURATOR_DEDUP_ID_STR
    storage_options: dict = field(default_factory=dict)
    workflow_name: str = "duplicate-removal"

    def run(self) -> WorkflowRunResult:
        logger.info(
            f"Starting duplicate removal: input={self.input_path}, "
            f"ids={self.ids_to_remove_path}, output={self.output_path}"
        )
        read_kwargs = {"storage_options": self.storage_options} if self.storage_options else None
        # index=False prevents pandas from writing a row index column,
        # which causes inconsistent schema across output parquet files
        output_kwargs = {**(read_kwargs or {}), "index": False}
        wf = TextDuplicatesRemovalWorkflow(
            input_path=self.input_path,
            ids_to_remove_path=self.ids_to_remove_path,
            output_path=self.output_path,
            input_filetype=self.input_filetype,
            input_blocksize=self.input_blocksize,
            input_kwargs=read_kwargs,
            input_id_field=self.input_id_field,
            output_fields=None,
            output_filetype=self.output_filetype,
            output_kwargs=output_kwargs,
            id_generator_path=self.id_generator_path,
            id_generator_storage_options=self.storage_options if self.id_generator_path else None,
            ids_to_remove_duplicate_id_field=CURATOR_DEDUP_ID_STR,
            ids_to_remove_read_kwargs=read_kwargs,
        )
        # Use RayDataExecutor for streaming execution — data flows between stages
        # without materializing on the head node's object store. This avoids
        # OutOfDiskError when processing large datasets (10M+ docs).
        wf.run(executor=CustomRayDataExecutor())

        logger.info(f"Deduplicated output written to {self.output_path}")
        return WorkflowRunResult(
            workflow_name=self.workflow_name,
            metadata={"output_path": self.output_path},
        )


# ---------------------------------------------------------------------------
# Text Dedup Orchestrator
# ---------------------------------------------------------------------------


@dataclass
class TextDedupOrchestrator(WorkflowOrchestrator):
    """Orchestrator for text deduplication DAG.

    Constructs WorkflowSteps with proper DAG dependencies:
        exact_identification (no deps)
            → exact_removal (depends: exact_identification)
        fuzzy_identification (depends: exact_removal when both modes enabled)
            → fuzzy_removal (depends: fuzzy_identification)
    """

    input_path: str = ""
    output_path: str = ""
    cache_path: str = ""
    text_field: str = "text"
    run_exact: bool = True
    run_fuzzy: bool = False
    perform_removal: bool = True
    input_filetype: Literal["parquet", "jsonl"] = "parquet"
    output_filetype: Literal["parquet", "jsonl"] = "parquet"
    input_blocksize: str = "256MiB"
    char_ngrams: int = 24
    num_bands: int = 20
    minhashes_per_band: int = 13
    seed: int = 42
    use_64_bit_hash: bool = False
    bands_per_iteration: int = 5
    jaccard_threshold: float = 0.8
    use_gpu: bool = True
    workflow_name: str = "text-deduplication"

    def __post_init__(self) -> None:
        if not self.input_path:
            raise ValueError("input_path is required")
        if not self.output_path:
            raise ValueError("output_path is required")
        if self.run_fuzzy and self.use_gpu and not self.cache_path:
            raise ValueError("cache_path is required when run_fuzzy=true and use_gpu=true")
        if not self.run_exact and not self.run_fuzzy:
            raise ValueError("At least one of run_exact or run_fuzzy must be true")

        self.steps = self._build_steps()

    def _build_steps(self) -> list[WorkflowStep]:
        storage_opts = self.storage_options
        base = self.output_path.rstrip("/")
        steps: list[WorkflowStep] = []

        # Computed paths
        exact_output_path = f"{base}/exact_ids"
        exact_deduplicated_path = f"{base}/exact_deduplicated"
        fuzzy_output_path = f"{base}/fuzzy_ids"
        fuzzy_deduplicated_path = f"{base}/fuzzy_deduplicated"

        # Exact identification
        if self.run_exact:
            steps.append(WorkflowStep(
                name="exact_identification",
                workflow=ExactIdentificationWorkflow(
                    input_path=self.input_path,
                    output_path=exact_output_path,
                    text_field=self.text_field,
                    input_filetype=self.input_filetype,
                    input_blocksize=self.input_blocksize,
                    storage_options=storage_opts,
                ),
                depends_on=[],
                output_path=exact_output_path,
            ))

            if self.perform_removal:
                steps.append(WorkflowStep(
                    name="exact_removal",
                    workflow=DuplicateRemovalWorkflow(
                        input_path=self.input_path,
                        ids_to_remove_path=f"{exact_output_path}/ExactDuplicateIds/",
                        id_generator_path=f"{exact_output_path}/exact_id_generator.json",
                        output_path=exact_deduplicated_path,
                        input_filetype=self.input_filetype,
                        input_blocksize=self.input_blocksize,
                        output_filetype=self.output_filetype,
                        storage_options=storage_opts,
                    ),
                    depends_on=["exact_identification"],
                    output_path=exact_deduplicated_path,
                ))

        # Fuzzy identification
        if self.run_fuzzy:
            # If fuzzy runs after exact removal, it reads the deduplicated output
            fuzzy_deps = []
            if self.run_exact and self.perform_removal:
                fuzzy_input_path = exact_deduplicated_path
                fuzzy_deps = ["exact_removal"]
            else:
                fuzzy_input_path = self.input_path

            steps.append(WorkflowStep(
                name="fuzzy_identification",
                workflow=self._build_fuzzy_workflow(fuzzy_input_path, fuzzy_output_path, storage_opts),
                depends_on=fuzzy_deps,
                output_path=fuzzy_output_path,
            ))

            if self.perform_removal:
                steps.append(WorkflowStep(
                    name="fuzzy_removal",
                    workflow=DuplicateRemovalWorkflow(
                        input_path=fuzzy_input_path,
                        ids_to_remove_path=f"{fuzzy_output_path}/FuzzyDuplicateIds/",
                        id_generator_path=f"{fuzzy_output_path}/fuzzy_id_generator.json",
                        output_path=fuzzy_deduplicated_path,
                        input_filetype=self.input_filetype,
                        input_blocksize=self.input_blocksize,
                        output_filetype=self.output_filetype,
                        storage_options=storage_opts,
                    ),
                    depends_on=["fuzzy_identification"],
                    output_path=fuzzy_deduplicated_path,
                ))

        return steps

    def _build_fuzzy_workflow(
        self,
        input_path: str,
        output_path: str,
        storage_opts: dict,
    ) -> WorkflowBase:
        """Build GPU or CPU fuzzy identification workflow based on use_gpu flag."""
        if self.use_gpu:
            return FuzzyIdentificationWorkflow(
                input_path=input_path,
                output_path=output_path,
                cache_path=self.cache_path,
                text_field=self.text_field,
                input_filetype=self.input_filetype,
                input_blocksize=self.input_blocksize,
                char_ngrams=self.char_ngrams,
                num_bands=self.num_bands,
                minhashes_per_band=self.minhashes_per_band,
                seed=self.seed,
                use_64_bit_hash=self.use_64_bit_hash,
                bands_per_iteration=self.bands_per_iteration,
                storage_options=storage_opts,
            )

        from agi_data_curator.dedup.fuzzy_dedup_cpu import CPUFuzzyDedupWorkflow

        return CPUFuzzyDedupWorkflow(
            input_path=input_path,
            output_path=output_path,
            text_field=self.text_field,
            num_perm=self.num_bands * self.minhashes_per_band,
            ngram_size=self.char_ngrams,
            jaccard_threshold=self.jaccard_threshold,
            num_bands=self.num_bands,
            rows_per_band=self.minhashes_per_band,
            bands_per_iteration=self.bands_per_iteration,
            seed=self.seed,
            input_format=self.input_filetype,
            storage_options=storage_opts,
        )
