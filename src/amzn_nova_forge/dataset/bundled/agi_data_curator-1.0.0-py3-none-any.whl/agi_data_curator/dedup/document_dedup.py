"""Document-level deduplication for multimodal (text + image) samples.

Computes an MD5 hash over the concatenation of the text field and all
JPEG-encoded images, then drops duplicate rows keeping the first
occurrence.

Each sample is expected to have a text field and an image field whose
value is a JPEG-encoded byte string.

Uses the same distributed approach as :func:`run_exact_dedup`:
hashes are computed via ``map_batches``, only the hash column is
collected to the driver, and filtering happens distributed.

Usage::

    from agi_data_curator.dedup.document_dedup import run_document_dedup

    stats = run_document_dedup(
        input_path="s3://bucket/input/",
        output_path="s3://bucket/output/",
        text_field="text",
        image_field="image",
    )
"""

from __future__ import annotations

import hashlib
import io
import logging
import numpy as np
from PIL import Image

import pandas as pd

from agi_data_curator.pipeline.curation_stage import CurationStage

logger = logging.getLogger(__name__)


def _binary_array_to_hex(arr):
    """
    internal function to make a hex string out of a binary array.
    """
    bit_string = ''.join(str(b) for b in 1 * arr.flatten())
    width = int(np.ceil(len(bit_string) / 4))
    return '{:0>{width}x}'.format(int(bit_string, 2), width=width)


def _hash_image(image, hash_size=16, highfreq_factor=4):
    import scipy.fftpack

    if hash_size < 2:
        raise ValueError("Hash size must be greater than or equal to 2")
    img_size = hash_size * highfreq_factor
    image = image.convert("L").resize((img_size, img_size), Image.Resampling.LANCZOS)
    pixels = np.asarray(image)
    dct = scipy.fftpack.dct(scipy.fftpack.dct(pixels, axis=0), axis=1)
    dctlowfreq = dct[:hash_size, :hash_size]
    med = np.median(dctlowfreq)
    diff = dctlowfreq > med
    return _binary_array_to_hex(diff)


def _hash_document(text: str | None, image_data: bytes) -> str:
    """Compute MD5 over text and phash-256 over JPEG image in the sample."""

    text_hash = hashlib.md5((text if text else "").encode("utf-8")).hexdigest()
    with io.BytesIO(image_data) as b:
        img: Image.Image = Image.open(b)
        img.load()
        img = img.convert('RGB')
        img_hash = _hash_image(img, hash_size=16)
    return text_hash + img_hash


class DocumentDedupStage(CurationStage):
    """Remove exact duplicate multimodal documents based on MD5 hash.

    Computes ``md5(text + image_bytes)`` for each row, then drops
    duplicates keeping the first occurrence.

    Args:
        text_field: Column containing the document text. Default ``"text"``.
        image_field: Column containing JPEG-encoded byte string. Default ``"image"``.
        hash_field: Output column for the MD5 hash. Default ``"_doc_hash"``.
        keep_hash_column: If False, drop the hash column from output.
            Default True.
    """

    def __init__(
        self,
        text_field: str = "text",
        image_field: str = "image",
        hash_field: str = "_doc_hash",
        keep_hash_column: bool = True,
    ):
        self.text_field = text_field
        self.image_field = image_field
        self.hash_field = hash_field
        self.keep_hash_column = keep_hash_column

    def input_columns(self) -> list[str]:
        return [self.text_field, self.image_field]

    def output_columns(self) -> list[str]:
        return [self.hash_field] if self.keep_hash_column else []

    def process_df(self, df: pd.DataFrame) -> pd.DataFrame:
        if df.empty:
            return df

        df = df.copy()
        # TODO - Vectorize hash calculation for speed up.
        df[self.hash_field] = df.apply(
            lambda row: _hash_document(
                row.get(self.text_field, ""),
                row.get(self.image_field),
            ),
            axis=1,
        )

        before = len(df)
        df = df.drop_duplicates(subset=[self.hash_field], keep="first").reset_index(drop=True)
        n_dropped = before - len(df)

        if n_dropped:
            logger.info("DocumentDedupStage: removed %d/%d duplicates", n_dropped, before)

        if not self.keep_hash_column:
            df = df.drop(columns=[self.hash_field])

        return df

def _compute_doc_hash_batch(
    batch: pd.DataFrame, text_field: str, image_field: str,
) -> pd.DataFrame:
    """Compute document hash for each row in a batch.

    Called via ``map_batches`` with ``batch_format="pandas"`` — receives
    and returns a DataFrame.  Adds a ``_doc_hash`` column with the hex digest.
    """
    batch["_doc_hash"] = [
        _hash_document(t, img)
        for t, img in zip(batch[text_field].fillna(""), batch[image_field])
    ]
    return batch


def run_document_dedup(
    input_path: str,
    output_path: str,
    *,
    text_field: str = "text",
    image_field: str = "image",
    input_format: str = "parquet",
    output_format: str = "parquet",
    output_num_files: int | None = None,
    ray_init_kwargs: dict | None = None,
    shutdown_ray: bool = False,
) -> dict:
    """Run global document-level deduplication on a multimodal dataset.

    Uses the same distributed approach as :func:`run_exact_dedup` but
    hashes both the text and all JPEG images in each sample.

    1. **Hash** — ``map_batches`` computes MD5 over text + images.
    2. **Collect hashes** — only the hash column is collected to the
       driver to identify first-occurrence duplicates.
    3. **Filter** — the original dataset is filtered distributed.
    4. **Write** — output is written with all original columns.

    Args:
        input_path: Path to input data (local or S3).
        output_path: Path for deduplicated output (local or S3).
        text_field: Text column name. Default ``"text"``.
        image_field: Image column name. Default ``"image"``.
        input_format: ``"parquet"`` or ``"jsonl"``. Default ``"parquet"``.
        output_format: ``"parquet"`` or ``"jsonl"``. Default ``"parquet"``.
        output_num_files: Number of output files. Default None (auto).
        ray_init_kwargs: Optional kwargs for ``ray.init()``.
        shutdown_ray: If True, shut down Ray after completion.

    Returns:
        Dict with ``input_count``, ``output_count``, ``duplicates_removed``.
    """
    import ray
    import ray.data

    from agi_data_curator.pipeline.runner import _ensure_ray_initialized

    _ensure_ray_initialized(ray_init_kwargs)

    try:
        # Step 1: Read dataset
        if input_format == "jsonl":
            ds = ray.data.read_json(input_path)
        else:
            ds = ray.data.read_parquet(input_path)

        input_count = ds.count()

        # Step 2: Compute hashes distributed across workers.
        ds_hashed = ds.map_batches(
            _compute_doc_hash_batch,  # type: ignore[arg-type]
            fn_kwargs={"text_field": text_field, "image_field": image_field},
            batch_format="pandas",
        ).materialize()

        # Step 3: Collect only hash column to driver to find duplicates.
        hash_col = ds_hashed.select_columns(["_doc_hash"])
        all_hashes = [row["_doc_hash"] for row in hash_col.iter_rows()]

        seen: set[str] = set()
        duplicate_indices: set[int] = set()
        for idx, h in enumerate(all_hashes):
            if h in seen:
                duplicate_indices.add(idx)
            else:
                seen.add(h)

        duplicates_removed = len(duplicate_indices)

        logger.info(
            "Document dedup: %d → %d rows (%d duplicates removed)",
            input_count, input_count - duplicates_removed, duplicates_removed,
        )

        if duplicates_removed == 0:
            ds_out = ds
        else:
            # Step 4: Filter out duplicate rows using hash values.
            # Build set of hashes that appear more than once.
            from collections import Counter
            hash_counts = Counter(all_hashes)
            duplicate_hashes = frozenset(
                h for h, c in hash_counts.items() if c > 1
            )

            # Filter keeps all unique-hash rows immediately.
            # For duplicate-hash rows, keeps only the first occurrence
            # using per-actor seen-set state (concurrency=1 ensures
            # a single actor processes all rows sequentially).
            dup_ref = ray.put(duplicate_hashes)

            class _FirstOccurrenceFilter:
                def __init__(self):
                    self._dup_hashes: frozenset | None = None
                    self._seen: set[str] = set()

                def __call__(self, row: dict) -> bool:
                    if self._dup_hashes is None:
                        self._dup_hashes = ray.get(dup_ref)
                    h = row["_doc_hash"]
                    if h not in self._dup_hashes:
                        return True  # unique hash — always keep
                    if h not in self._seen:
                        self._seen.add(h)
                        return True  # first occurrence of duplicate
                    return False

            ds_filtered = ds_hashed.filter(
                _FirstOccurrenceFilter,
                compute=ray.data.ActorPoolStrategy(min_size=1, max_size=1),
            )
            # Drop the temporary _text_hash column
            original_cols = ds.schema().names
            ds_out = ds_filtered.select_columns(original_cols)

        # Step 5: Write output
        output_count = input_count - duplicates_removed

        if output_format == "jsonl":
            import fsspec

            df_out = ds_out.to_pandas()
            out = output_path.rstrip("/")
            file_path = out if out.endswith(".jsonl") else f"{out}/output.jsonl"
            jsonl = df_out.to_json(orient="records", lines=True, force_ascii=False)
            with fsspec.open(file_path, "w") as f:
                f.write(jsonl)
        else:
            if output_num_files is not None:
                ds_out = ds_out.repartition(output_num_files)
            ds_out.write_parquet(output_path)

        return {
            "input_count": input_count,
            "output_count": output_count,
            "duplicates_removed": duplicates_removed,
        }
    finally:
        if shutdown_ray:
            ray.shutdown()
