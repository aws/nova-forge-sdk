"""Exact deduplication stage for pure Ray pipelines.

Computes an MD5 hash of the text field and drops duplicate rows,
keeping the first occurrence.

Uses a distributed approach: hashes are computed via Ray ``map_batches``
across workers, only the lightweight hash column is collected to the
driver to identify duplicates, and the original dataset is filtered
in a distributed fashion. This avoids loading the full dataset into
driver memory and scales to 10M+ rows.

No NemoCurator dependency — runs entirely on pandas + hashlib.

Usage::

    from agi_data_curator.dedup.exact_dedup import ExactDedupStage
    from agi_data_curator.pipeline import CurationPipeline, run_pipeline

    pipeline = CurationPipeline(
        stages=[ExactDedupStage()],
        input_path="s3://bucket/input/",
        output_path="s3://bucket/output/",
    )
    run_pipeline(pipeline)
"""

from __future__ import annotations

import hashlib
import logging

import pandas as pd

from agi_data_curator.pipeline.curation_stage import CurationStage

logger = logging.getLogger(__name__)


class ExactDedupStage(CurationStage):
    """Remove exact duplicate documents based on MD5 hash of text.

    Computes ``md5(text.encode('utf-8'))`` for each row, then drops
    duplicates keeping the first occurrence. The hash column is added
    to the output so downstream stages can inspect it.

    This is a **global** dedup — it needs to see all rows to detect
    duplicates. The ``CurationPipeline`` runs stages via ``map_batches``
    which processes independent batches. To handle this, the pipeline
    should be configured with ``concurrency=1`` and a large batch size,
    or this stage should be used via :meth:`run_dedup` which collects
    the full dataset.

    For truly global dedup across batches, use :func:`run_exact_dedup`
    which operates on the full ``ray.data.Dataset`` directly.

    Args:
        text_field: Column containing the document text. Default ``"text"``.
        hash_field: Output column for the MD5 hash. Default ``"_text_hash"``.
        keep_hash_column: If False, drop the hash column from output.
            Default True.
    """

    def __init__(
        self,
        text_field: str = "text",
        hash_field: str = "_text_hash",
        keep_hash_column: bool = True,
    ):
        self.text_field = text_field
        self.hash_field = hash_field
        self.keep_hash_column = keep_hash_column

    def input_columns(self) -> list[str]:
        return [self.text_field]

    def output_columns(self) -> list[str]:
        return [self.hash_field] if self.keep_hash_column else []

    def process_df(self, df: pd.DataFrame) -> pd.DataFrame:
        raise NotImplementedError(
            "ExactDedupStage.process_df is not supported. "
            "Use run_exact_dedup() for global deduplication across the full dataset."
        )



def _compute_hash_batch(batch: pd.DataFrame, text_field: str, normalize: bool) -> pd.DataFrame:
    """Normalize (optionally) and compute MD5 hash for each row.

    Called via ``map_batches`` with ``batch_format="pandas"`` — receives
    and returns a DataFrame.  Using pandas avoids Arrow serialisation
    failures on columns that contain mixed ``None``/string values (which
    numpy represents as multi-dimensional ``object`` arrays).

    When ``normalize`` is True, the hash is computed from the normalized
    text (stripped, collapsed whitespace, lowercased) so that whitespace
    and case variants are detected as duplicates.
    """
    import re

    hash_source = batch[text_field].fillna("")
    if normalize:
        hash_source = hash_source.str.strip()
        hash_source = hash_source.apply(lambda t: re.sub(r"\s+", " ", t))
        hash_source = hash_source.str.lower()
    batch["_text_hash"] = hash_source.apply(
        lambda t: hashlib.md5(t.encode("utf-8")).hexdigest()
    )
    return batch


def run_exact_dedup(
    input_path: str,
    output_path: str,
    *,
    text_field: str = "text",
    normalize: bool = True,
    input_format: str = "parquet",
    output_format: str = "parquet",
    output_num_files: int | None = None,
    ray_init_kwargs: dict | None = None,
    shutdown_ray: bool = False,
) -> dict:
    """Run global exact deduplication on a dataset.

    Uses a distributed approach to avoid loading the full dataset into
    driver memory:

    1. **Normalize + Hash** — ``map_batches`` optionally normalizes text
       (strip, collapse whitespace, lowercase) then computes MD5 hashes
       across workers.
    2. **Collect hashes** — only the hash column (~32 bytes/row) is
       collected to the driver to identify first-occurrence duplicates.
    3. **Filter** — the original dataset (with hashes) is filtered
       in a distributed fashion using a set of duplicate hashes.
    4. **Write** — output is written directly from the Ray dataset
       with all original columns preserved (original text is unchanged).

    Scales to 10M+ rows since only the hash column is materialized
    on the driver. For even larger datasets, use the NemoCurator-based
    ``TextDedupOrchestrator`` which uses GPU-accelerated cuDF shuffle.

    Args:
        input_path: Path to input data (local or S3).
        output_path: Path for deduplicated output (local or S3).
        text_field: Text column to hash. Default ``"text"``.
        normalize: If True (default), normalize text before hashing —
            strips whitespace, collapses internal whitespace runs, and
            lowercases. This catches whitespace and case variants as
            duplicates while preserving the original text in the output.
        input_format: ``"parquet"`` or ``"jsonl"``. Default ``"parquet"``.
        output_format: ``"parquet"`` or ``"jsonl"``. Default ``"parquet"``.
        output_num_files: Number of output files. Default None (auto).
        ray_init_kwargs: Optional kwargs for ``ray.init()``.
        shutdown_ray: If True, shut down Ray after completion.

    Returns:
        Dict with ``input_count``, ``output_count``, ``duplicates_removed``.
    """
    import ray
    import ray.data

    from agi_data_curator.pipeline.runner import _ensure_ray_initialized

    _ensure_ray_initialized(ray_init_kwargs)

    try:
        # Step 1: Read dataset
        if input_format == "jsonl":
            ds = ray.data.read_json(input_path, partition_filter=None)
        else:
            ds = ray.data.read_parquet(input_path)

        input_count = ds.count()

        # Step 2: Compute hashes distributed across workers.
        # Materialize so both the hash collection and filtering passes
        # see the same data in the same deterministic order.
        ds_hashed = ds.map_batches(
            _compute_hash_batch,  # type: ignore[arg-type]
            fn_kwargs={"text_field": text_field, "normalize": normalize},
            batch_format="pandas",
        ).materialize()

        # Step 3: Collect only hash column to driver to find duplicates.
        # Each hash is 32 chars (~32 bytes), so 10M rows ≈ 320 MB on driver.
        hash_col = ds_hashed.select_columns(["_text_hash"])
        all_hashes = [row["_text_hash"] for row in hash_col.iter_rows()]

        # Build set of duplicate hashes (hashes that appear more than once,
        # excluding the first occurrence)
        seen: set[str] = set()
        duplicate_indices: set[int] = set()
        for idx, h in enumerate(all_hashes):
            if h in seen:
                duplicate_indices.add(idx)
            else:
                seen.add(h)

        duplicates_removed = len(duplicate_indices)

        logger.info(
            "Exact dedup: %d → %d rows (%d duplicates removed)",
            input_count, input_count - duplicates_removed, duplicates_removed,
        )

        if duplicates_removed == 0:
            # No duplicates — write original dataset directly
            ds_out = ds
        else:
            # Step 4: Filter out duplicate rows using hash values.
            # Build set of hashes that appear more than once.
            from collections import Counter
            hash_counts = Counter(all_hashes)
            duplicate_hashes = frozenset(
                h for h, c in hash_counts.items() if c > 1
            )

            # Filter keeps all unique-hash rows immediately.
            # For duplicate-hash rows, keeps only the first occurrence
            # using per-actor seen-set state (concurrency=1 ensures
            # a single actor processes all rows sequentially).
            dup_ref = ray.put(duplicate_hashes)

            class _FirstOccurrenceFilter:
                def __init__(self):
                    self._dup_hashes: frozenset | None = None
                    self._seen: set[str] = set()

                def __call__(self, row: dict) -> bool:
                    if self._dup_hashes is None:
                        self._dup_hashes = ray.get(dup_ref)
                    h = row["_text_hash"]
                    if h not in self._dup_hashes:
                        return True  # unique hash — always keep
                    if h not in self._seen:
                        self._seen.add(h)
                        return True  # first occurrence of duplicate
                    return False

            ds_filtered = ds_hashed.filter(
                _FirstOccurrenceFilter,
                compute=ray.data.ActorPoolStrategy(min_size=1, max_size=1),
            )
            # Drop the temporary _text_hash column
            original_cols = ds.schema().names
            ds_out = ds_filtered.select_columns(original_cols)

        # Step 5: Write output
        output_count = input_count - duplicates_removed

        if output_format == "jsonl":
            import fsspec

            df_out = ds_out.to_pandas()
            out = output_path.rstrip("/")
            file_path = out if out.endswith(".jsonl") else f"{out}/output.jsonl"
            jsonl = df_out.to_json(orient="records", lines=True, force_ascii=False)
            with fsspec.open(file_path, "w") as f:
                f.write(jsonl)
        else:
            if output_num_files is not None:
                ds_out = ds_out.repartition(output_num_files)
            ds_out.write_parquet(output_path)

        return {
            "input_count": input_count,
            "output_count": output_count,
            "duplicates_removed": duplicates_removed,
        }
    finally:
        if shutdown_ray:
            ray.shutdown()
