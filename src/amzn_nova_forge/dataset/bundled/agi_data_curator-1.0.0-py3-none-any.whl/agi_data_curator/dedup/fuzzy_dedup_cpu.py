"""CPU-only fuzzy deduplication via MinHash LSH on Ray.

Pure numpy implementation — no cuDF, RAPIDS, or datasketch dependency.
Distributes MinHash computation across Ray cluster via Ray Data map_batches.

Follows the same pattern as ``exact_dedup.py``:
    - ``FuzzyDedupStage(CurationStage)`` — placeholder for pipeline integration
    - ``run_fuzzy_dedup()`` — standalone function for global fuzzy dedup
    - ``CPUFuzzyDedupWorkflow(WorkflowBase)`` — thin wrapper for orchestrator

No NemoCurator dependency — runs entirely on numpy + Ray Data.

Usage::

    # Standalone function (like run_exact_dedup)
    from agi_data_curator.dedup.fuzzy_dedup_cpu import run_fuzzy_dedup

    result = run_fuzzy_dedup(
        input_path="s3://bucket/data/",
        output_path="s3://bucket/dedup_output/",
        text_field="text",
        jaccard_threshold=0.8,
    )

    # Or via ForgeWorkflows:
    forge.execute("fuzzy_dedup_cpu", input_path="s3://...", output_path="s3://...")
"""

from __future__ import annotations

from typing import Any

import hashlib
import json
import struct
import time

import numpy as np
import pandas as pd
from loguru import logger

from agi_data_curator.pipeline.curation_stage import CurationStage
from agi_data_curator.pipeline.workflow import (
    WorkflowBase,
    WorkflowRunResult,
    write_success,
)

# ── Constants ────────────────────────────────────────────────────────
MERSENNE_PRIME = np.uint64((1 << 61) - 1)
MAX_HASH = np.uint64((1 << 32) - 1)
CURATOR_DEDUP_ID_STR = "__curator_dedup_id"

# ── Hash function: xxhash (5x faster) with sha1 fallback ────────────
try:
    import xxhash

    def _hash32(data: bytes) -> int:
        return xxhash.xxh32(data).intdigest()

    _HASH_BACKEND = "xxhash"
except ImportError:
    _HASH_BACKEND = "sha1"

    def _hash32(data: bytes) -> int:
        return struct.unpack("<I", hashlib.sha1(data).digest()[:4])[0]


def sha1_hash32(data: bytes) -> int:
    """SHA1-based uint32 hash. Kept for API compatibility and tests."""
    return struct.unpack("<I", hashlib.sha1(data).digest()[:4])[0]


# ── CurationStage ────────────────────────────────────────────────────


class FuzzyDedupStage(CurationStage):
    """Fuzzy deduplication via MinHash LSH.

    This is a **global** dedup — it needs to see all rows to detect
    near-duplicates. ``process_df`` raises ``NotImplementedError``.

    For global fuzzy dedup, use :func:`run_fuzzy_dedup` which operates
    on the full ``ray.data.Dataset`` directly.

    Args:
        text_field: Column containing the document text. Default ``"text"``.
        jaccard_threshold: Jaccard similarity threshold. Default 0.8.
        num_perm: Number of MinHash permutations. Default 256.
        ngram_size: Character n-gram size. Default 24.
    """

    def __init__(
        self,
        text_field: str = "text",
        jaccard_threshold: float = 0.8,
        num_perm: int = 256,
        ngram_size: int = 24,
    ):
        self.text_field = text_field
        self.jaccard_threshold = jaccard_threshold
        self.num_perm = num_perm
        self.ngram_size = ngram_size

    def input_columns(self) -> list[str]:
        return [self.text_field]

    def output_columns(self) -> list[str]:
        return []

    def process_df(self, df: pd.DataFrame) -> pd.DataFrame:
        raise NotImplementedError(
            "FuzzyDedupStage.process_df is not supported. "
            "Use run_fuzzy_dedup() for global fuzzy deduplication across the full dataset."
        )


# ── Algorithm primitives ─────────────────────────────────────────────


def optimal_param(
    threshold: float,
    num_perm: int,
    false_positive_weight: float = 0.5,
    false_negative_weight: float = 0.5,
) -> tuple[int, int]:
    """Compute optimal LSH (num_bands, rows_per_band) for a Jaccard threshold."""
    _N = 1000
    # np.trapz was renamed to np.trapezoid in NumPy 2.0.
    trapezoid = getattr(np, "trapezoid", None) or getattr(np, "trapz")

    def _fp(th, b, r):
        s = np.linspace(0.0, th, _N)
        return float(trapezoid(1.0 - (1.0 - s ** float(r)) ** float(b), s))

    def _fn(th, b, r):
        s = np.linspace(th, 1.0, _N)
        return float(trapezoid(1.0 - (1.0 - (1.0 - s ** float(r)) ** float(b)), s))

    best_err, opt = float("inf"), (0, 0)
    for b in range(1, num_perm + 1):
        for r in range(1, num_perm // b + 1):
            err = _fp(threshold, b, r) * false_positive_weight + _fn(threshold, b, r) * false_negative_weight
            if err < best_err:
                best_err, opt = err, (b, r)
    return opt


class MinHasher:
    """Compute MinHash signatures using numpy-vectorized permutations."""

    def __init__(self, num_perm=256, ngram_size=24, seed=42, lowercase=True):
        self.num_perm = num_perm
        self.ngram_size = ngram_size
        self.lowercase = lowercase
        gen = np.random.RandomState(seed=seed)
        self.perm_a, self.perm_b = np.array(
            [(gen.randint(1, MERSENNE_PRIME, dtype=np.uint64),
              gen.randint(0, MERSENNE_PRIME, dtype=np.uint64))
             for _ in range(num_perm)], dtype=np.uint64,
        ).T

    def compute(self, text: str) -> np.ndarray:
        """Returns uint32[num_perm] signature."""
        if self.lowercase:
            text = text.lower()
        n = self.ngram_size
        if len(text) < n:
            return np.full(self.num_perm, MAX_HASH, dtype=np.uint32)
        seen: set[int] = set()
        hashes: list[int] = []
        for i in range(len(text) - n + 1):
            h = _hash32(text[i : i + n].encode("utf-8"))
            if h not in seen:
                seen.add(h)
                hashes.append(h)
        if not hashes:
            return np.full(self.num_perm, MAX_HASH, dtype=np.uint32)
        hv = np.array(hashes, dtype=np.uint64)
        phv = np.bitwise_and(
            (hv[:, None] * self.perm_a + self.perm_b) % MERSENNE_PRIME, MAX_HASH,
        )
        return phv.min(axis=0).astype(np.uint32)


class LSHIndex:
    """LSH index using banding. Raw minhash bytes as band key."""

    def __init__(self, num_bands, rows_per_band):
        self.num_bands = num_bands
        self.rows_per_band = rows_per_band
        self.tables: list[dict[bytes, list[int]]] = [{} for _ in range(num_bands)]

    def insert(self, doc_id, minhash):
        rpb = self.rows_per_band
        for b in range(self.num_bands):
            key = minhash[b * rpb : (b + 1) * rpb].tobytes()
            t = self.tables[b]
            if key in t:
                t[key].append(doc_id)
            else:
                t[key] = [doc_id]

    def insert_bands(self, doc_id, minhash, band_start, band_end):
        rpb = self.rows_per_band
        for b in range(band_start, band_end):
            key = minhash[b * rpb : (b + 1) * rpb].tobytes()
            t = self.tables[b]
            if key in t:
                t[key].append(doc_id)
            else:
                t[key] = [doc_id]

    def get_candidate_pairs(self):
        for table in self.tables:
            for bucket in table.values():
                if len(bucket) > 1:
                    yield bucket

    def clear_bands(self, band_start, band_end):
        for b in range(band_start, band_end):
            self.tables[b].clear()

    def clear(self):
        for t in self.tables:
            t.clear()


class UnionFind:
    """Disjoint set — path compression + union by minimum ID."""
    __slots__ = ("parent",)

    def __init__(self):
        self.parent: dict[int, int] = {}

    def find(self, x):
        if x not in self.parent:
            self.parent[x] = x
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])
        return self.parent[x]

    def union(self, x, y):
        px, py = self.find(x), self.find(y)
        self.parent[px] = self.parent[py] = min(px, py)

    def get_duplicate_ids(self):
        return [x for x in self.parent if self.find(x) != x]

    def cluster_count(self):
        roots: dict[int, int] = {}
        for x in self.parent:
            r = self.find(x)
            roots[r] = roots.get(r, 0) + 1
        return sum(1 for c in roots.values() if c > 1)



# ── Ray Data batch function ──────────────────────────────────────────


class _MinHashBatchFn:
    """Class-based callable for map_batches — creates MinHasher once."""

    def __init__(self, text_field, num_perm, ngram_size, seed, lowercase):
        self.hasher = MinHasher(num_perm=num_perm, ngram_size=ngram_size, seed=seed, lowercase=lowercase)
        self.text_field = text_field

    def __call__(self, batch: pd.DataFrame) -> pd.DataFrame:
        texts = batch[self.text_field].fillna("")
        sigs = [self.hasher.compute(text).tobytes() for text in texts]
        batch = batch.copy()
        batch["__minhash_sig"] = sigs
        return batch


# ── Standalone dedup function ─────────────────────────────────────────


def run_fuzzy_dedup(
    input_path: str | list[str],
    output_path: str,
    *,
    text_field: str = "text",
    num_perm: int = 256,
    ngram_size: int = 24,
    jaccard_threshold: float = 0.8,
    num_bands: int | None = None,
    rows_per_band: int | None = None,
    bands_per_iteration: int = 4,
    seed: int = 42,
    lowercase: bool = True,
    input_format: str = "parquet",
    output_format: str = "parquet",
    output_num_files: int | None = None,
    ray_init_kwargs: dict | None = None,
    shutdown_ray: bool = False,
    storage_options: dict | None = None,
) -> dict:
    """Run global fuzzy deduplication on a dataset.

    Uses a distributed approach matching ``run_exact_dedup``:

    1. **MinHash** — ``map_batches`` computes MinHash signatures across
       workers. Signatures stored as a single binary column.
    2. **LSH + Union-Find** — for each band group, band keys are streamed
       to the driver, LSH index built, candidate pairs unioned.
    3. **Write** — duplicate IDs written as parquet (NeMo format).

    Args:
        input_path: Path to input data (local or S3).
        output_path: Path for dedup output (duplicate IDs + id_generator).
        text_field: Text column. Default ``"text"``.
        num_perm: MinHash permutations. Default 256.
        ngram_size: Character n-gram size. Default 24.
        jaccard_threshold: Similarity threshold. Default 0.8.
        num_bands: LSH bands (auto-computed if None).
        rows_per_band: Rows per band (auto-computed if None).
        bands_per_iteration: Bands per memory iteration. Default 4.
        seed: Random seed. Default 42.
        lowercase: Lowercase text before shingling. Default True.
        input_format: ``"parquet"`` or ``"jsonl"``. Default ``"parquet"``.
        output_format: ``"parquet"`` or ``"jsonl"``. Default ``"parquet"``.
        output_num_files: Number of output files. Default None (auto).
        ray_init_kwargs: Optional kwargs for ``ray.init()``.
        shutdown_ray: If True, shut down Ray after completion.
        storage_options: S3/fsspec options.

    Returns:
        Dict with ``input_count``, ``num_unique``, ``num_duplicates``,
        ``num_clusters``, ``elapsed_seconds``.
    """
    import ray
    import ray.data

    from agi_data_curator.pipeline.runner import _ensure_ray_initialized

    _ensure_ray_initialized(ray_init_kwargs)
    storage_opts = storage_options or {}

    # Auto-compute band parameters
    if num_bands is None or rows_per_band is None:
        num_bands, rows_per_band = optimal_param(jaccard_threshold, num_perm)
        logger.info(
            f"Auto-computed LSH params: bands={num_bands}, "
            f"rows_per_band={rows_per_band} "
            f"(threshold={jaccard_threshold}, num_perm={num_perm})"
        )

    if num_bands * rows_per_band > num_perm:
        raise ValueError(
            f"bands({num_bands}) × rows({rows_per_band}) "
            f"= {num_bands * rows_per_band} > num_perm({num_perm})"
        )

    t_start = time.time()
    logger.info(
        f"CPU Fuzzy Dedup: input={input_path}, "
        f"threshold={jaccard_threshold}, num_perm={num_perm}, "
        f"bands={num_bands}×{rows_per_band}, "
        f"bands_per_iter={bands_per_iteration}, hash={_HASH_BACKEND}"
    )

    try:
        # ── Step 1: Read dataset ─────────────────────────────────────
        paths = input_path if isinstance(input_path, list) else [input_path]
        ray_storage: dict[str, Any] = {"storage_options": storage_opts} if storage_opts else {}

        if input_format == "jsonl":
            ds = ray.data.read_json(paths, partition_filter=None, **ray_storage)
        else:
            ds = ray.data.read_parquet(paths, **ray_storage)

        input_count = ds.count()
        logger.info(f"  Step 1: {input_count:,} docs read")

        # ── Step 2: Assign global doc IDs ────────────────────────────
        # Materialize read first to prevent fusion with ID assigner
        ds = ds.materialize()

        class _GlobalIdAssigner:
            def __init__(self):
                self._offset = 0

            def __call__(self, batch: pd.DataFrame) -> pd.DataFrame:
                n = len(batch)
                batch = batch.copy()
                batch["__doc_id"] = np.arange(self._offset, self._offset + n, dtype=np.int64)
                self._offset += n
                return batch

        ds = ds.map_batches(
            _GlobalIdAssigner,
            batch_format="pandas",
            compute=ray.data.ActorPoolStrategy(min_size=1, max_size=1),
        ).materialize()

        # ── Step 3: Compute MinHash signatures (distributed) ────────
        logger.info("  Step 3: Computing MinHash signatures (distributed)...")
        t_hash = time.time()

        ds_hashed = ds.map_batches(
            _MinHashBatchFn,
            fn_constructor_args=(text_field, num_perm, ngram_size, seed, lowercase),
            batch_format="pandas",
            compute=ray.data.ActorPoolStrategy(min_size=1, max_size=1),
        ).materialize()

        logger.info(f"  Step 3: {input_count:,} docs hashed in {time.time() - t_hash:.1f}s")

        # ── Step 4: LSH + Union-Find (bands_per_iteration) ──────────
        uf = UnionFind()
        total_candidates = 0
        num_band_groups = (num_bands + bands_per_iteration - 1) // bands_per_iteration
        rpb = rows_per_band

        for group_idx in range(num_band_groups):
            band_start = group_idx * bands_per_iteration
            band_end = min(band_start + bands_per_iteration, num_bands)
            t_group = time.time()
            logger.info(
                f"  Step 4: Band group {group_idx + 1}/{num_band_groups} "
                f"(bands {band_start}-{band_end - 1})..."
            )

            ds_band = ds_hashed.select_columns(["__doc_id", "__minhash_sig"])
            lsh = LSHIndex(num_bands=num_bands, rows_per_band=rpb)

            for batch in ds_band.iter_batches(batch_size=50_000, batch_format="pandas"):
                doc_ids = batch["__doc_id"].values
                sig_bytes_list = batch["__minhash_sig"].values

                for row_idx in range(len(batch)):
                    doc_id = int(doc_ids[row_idx])
                    sig = np.frombuffer(sig_bytes_list[row_idx], dtype=np.uint32)
                    for b in range(band_start, band_end):
                        key = sig[b * rpb : (b + 1) * rpb].tobytes()
                        t = lsh.tables[b]
                        if key in t:
                            t[key].append(doc_id)
                        else:
                            t[key] = [doc_id]

            group_candidates = 0
            for b in range(band_start, band_end):
                for bucket in lsh.tables[b].values():
                    if len(bucket) <= 1:
                        continue
                    group_candidates += len(bucket)
                    min_id = min(bucket)
                    for doc_id in bucket:
                        uf.union(doc_id, min_id)

            total_candidates += group_candidates
            lsh.clear_bands(band_start, band_end)
            del lsh, ds_band

            logger.info(
                f"    Band group {group_idx + 1}: {group_candidates:,} candidates, "
                f"{time.time() - t_group:.1f}s"
            )

        # ── Step 5: Write results ────────────────────────────────────
        logger.info("  Step 5: Writing results...")
        duplicate_ids = uf.get_duplicate_ids()
        n_unique = input_count - len(duplicate_ids)
        n_clusters = uf.cluster_count()

        # Write duplicate ID metadata to a subdirectory (not top-level)
        # so downstream Ray read_parquet() only sees filtered data files.
        metadata_path = f"{output_path.rstrip('/')}/_dedup_metadata"
        _write_duplicate_ids(metadata_path, duplicate_ids, storage_opts)
        _write_id_generator(metadata_path, input_path, input_format, storage_opts)

        # ── Step 6: Write deduplicated dataset ───────────────────────
        logger.info("  Step 6: Writing deduplicated dataset...")
        dup_id_set = frozenset(duplicate_ids)
        dup_ref = ray.put(dup_id_set)

        class _DuplicateFilter:
            def __init__(self):
                self._dup_ids: frozenset | None = None

            def __call__(self, row: dict) -> bool:
                if self._dup_ids is None:
                    self._dup_ids = ray.get(dup_ref)
                return int(row["__doc_id"]) not in self._dup_ids

        ds_filtered = ds.filter(
            _DuplicateFilter,
            compute=ray.data.ActorPoolStrategy(min_size=1),
        )

        # Drop temporary columns (__doc_id, __minhash_sig if present)
        original_cols = [c for c in ds_filtered.schema().names
                         if not c.startswith("__")]
        ds_out = ds_filtered.select_columns(original_cols)

        write_kwargs: dict[str, Any] = {}
        if storage_opts:
            write_kwargs["storage_options"] = storage_opts

        if output_format == "jsonl":
            # JSONL path collects to driver into a single file, so
            # repartition has no effect here — skip it.
            import fsspec

            df_out = ds_out.to_pandas()
            out = output_path.rstrip("/")
            file_path = out if out.endswith(".jsonl") else f"{out}/output.jsonl"
            jsonl = df_out.to_json(orient="records", lines=True, force_ascii=False)
            open_kwargs = {"storage_options": storage_opts} if storage_opts else {}
            with fsspec.open(file_path, "w", **open_kwargs) as f:
                f.write(jsonl)
        else:
            if output_num_files is not None:
                ds_out = ds_out.repartition(output_num_files)
            ds_out.write_parquet(output_path, **write_kwargs)

        write_success(metadata_path, storage_opts or None)

        elapsed = time.time() - t_start
        logger.info(
            f"CPU Fuzzy Dedup complete: {input_count:,} docs → "
            f"{n_unique:,} unique, {len(duplicate_ids):,} duplicates "
            f"({len(duplicate_ids) / max(input_count, 1) * 100:.1f}%), "
            f"{n_clusters:,} clusters, {elapsed:.1f}s ({elapsed / 60:.1f} min)"
        )

        return {
            "input_count": input_count,
            "num_unique": n_unique,
            "num_duplicates": len(duplicate_ids),
            "num_clusters": n_clusters,
            "elapsed_seconds": round(elapsed, 2),
        }
    finally:
        if shutdown_ray:
            ray.shutdown()


# ── Output helpers ────────────────────────────────────────────────────


def _write_duplicate_ids(output_path: str, duplicate_ids: list[int], storage_opts: dict) -> None:
    import fsspec

    output_dir = f"{output_path.rstrip('/')}/FuzzyDuplicateIds"
    fs, fs_path = fsspec.core.url_to_fs(output_dir, **storage_opts)
    fs.mkdirs(fs_path, exist_ok=True)
    chunk_size = 1_000_000
    for i in range(0, max(len(duplicate_ids), 1), chunk_size):
        chunk = duplicate_ids[i : i + chunk_size]
        path = f"{output_dir}/part_{i // chunk_size:04d}.parquet"
        pd.DataFrame({CURATOR_DEDUP_ID_STR: chunk}).to_parquet(
            path, index=False, storage_options=storage_opts or None,
        )
    logger.info(f"  Wrote {len(duplicate_ids):,} duplicate IDs to {output_dir}")


def _write_id_generator(
    output_path: str,
    input_path: str | list[str],
    input_format: str,
    storage_opts: dict,
) -> None:
    import fsspec

    paths = input_path if isinstance(input_path, list) else [input_path]
    ext = ".jsonl" if input_format == "jsonl" else ".parquet"

    all_files: list[str] = []
    for p in paths:
        fs, fs_path = fsspec.core.url_to_fs(p, **storage_opts)
        if fs.isdir(fs_path):
            files = [f"{p.rstrip('/')}/{f.split('/')[-1]}"
                     for f in fs.ls(fs_path) if f.endswith(ext)]
            all_files.extend(sorted(files))
        else:
            all_files.append(p)

    ranges: dict[str, dict[str, int]] = {}
    offset = 0
    for fpath in all_files:
        if input_format == "parquet":
            import pyarrow.parquet as pq

            fs_obj = fsspec.core.url_to_fs(fpath, **storage_opts)[0] if "://" in fpath else None
            n = pq.read_metadata(fpath, filesystem=fs_obj).num_rows
        else:
            fs, _ = fsspec.core.url_to_fs(fpath, **storage_opts)
            with fs.open(fs._strip_protocol(fpath), "r") as f:
                n = sum(1 for _ in f)
        ranges[fpath] = {"start": offset, "end": offset + n}
        offset += n

    out = f"{output_path.rstrip('/')}/fuzzy_id_generator.json"
    fs, _ = fsspec.core.url_to_fs(out, **storage_opts)
    with fs.open(fs._strip_protocol(out), "w") as f:
        json.dump(ranges, f, indent=2)
    logger.info(f"  Wrote id_generator to {out}")


# ── WorkflowBase wrapper ─────────────────────────────────────────────


class CPUFuzzyDedupWorkflow(WorkflowBase):
    """Thin wrapper around ``run_fuzzy_dedup`` for orchestrator integration.

    Implements ``WorkflowBase.run()`` so it can be used as a step in
    ``TextDedupOrchestrator`` when ``use_gpu=False``.
    """

    workflow_name: str = "cpu-fuzzy-dedup"

    def __init__(self, **kwargs):
        self._kwargs = kwargs

    def run(self) -> WorkflowRunResult:
        result = run_fuzzy_dedup(**self._kwargs)
        return WorkflowRunResult(
            workflow_name=self.workflow_name,
            metadata=result,
        )
