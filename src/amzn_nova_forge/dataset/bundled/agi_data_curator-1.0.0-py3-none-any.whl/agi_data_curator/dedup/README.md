# Text Deduplication

Exact and fuzzy text deduplication using NeMo Curator on Ray.

## Architecture

```
TextDedupOrchestrator
  exact_identification  (CustomRayExecutor — actor pool, GPU)
    -> exact_removal    (CustomRayDataExecutor — streaming)
  fuzzy_identification  (CustomRayExecutor — actor pool, GPU)
    -> fuzzy_removal    (CustomRayDataExecutor — streaming)
```

- **Identification** uses `CustomRayExecutor` (actor pool) for NCCL-based GPU shuffle
- **Removal** uses `CustomRayDataExecutor` (streaming) to avoid materializing data on the head node

## Prerequisites

- GPU-enabled environment (cudf/RAPIDS required by NeMo Curator)
- Ray 2.54+
- NeMo Curator installed with dedup dependencies

## Running Locally (no cluster required)

Runs the orchestrator in-process. Ray starts a local single-node instance
automatically via `ray.init()` — no separate Ray cluster or dashboard needed.

**Do NOT use `scripts/run_text_dedup.sh` for local runs** — that script submits
Ray jobs to a cluster via `ray job submit` and requires a running Ray head at
`localhost:8265`.

### Exact dedup only

```bash
python -m agi_data_curator.config.run \
  --config-path $PWD/config/templates \
  --config-name text_deduplication \
  input_path="s3://bucket/input/" \
  output_path="s3://bucket/output/"
```

### Exact + fuzzy

```bash
python -m agi_data_curator.config.run \
  --config-path /path/to/config/templates \
  --config-name text_deduplication \
  input_path="s3://bucket/input/" \
  output_path="s3://bucket/output/" \
  cache_path="s3://bucket/cache/" \
  run_fuzzy=true
```

### Identification only (no removal)

```bash
python -m agi_data_curator.config.run \
  --config-path /path/to/config/templates \
  --config-name text_deduplication \
  input_path="s3://bucket/input/" \
  output_path="s3://bucket/output/" \
  perform_removal=false
```

### Resume after failure

Steps with `_AGI_CURATOR_SUCCESS` markers are auto-skipped:

```bash
python -m agi_data_curator.config.run \
  --config-path /path/to/config/templates \
  --config-name text_deduplication \
  input_path="s3://bucket/input/" \
  output_path="s3://bucket/output/" \
  resume_from_checkpoint=true
```

## Running on a Ray Cluster (EKS)

### 1. Create the RayCluster

```bash
kubectl apply -f config/infra/raycluster-text-dedup.yaml
```

Verify pods are running:

```bash
kubectl get pods -n agi-dev -l ray.io/cluster=raycluster-text-dedup
```

Wait for head and worker pods to be `Running`:

```bash
kubectl wait --for=condition=Ready pods \
  -l ray.io/cluster=raycluster-text-dedup \
  -n agi-dev --timeout=300s
```

### 2. Port-forward the Ray dashboard and job submission API

```bash
kubectl port-forward -n agi-dev svc/raycluster-text-dedup-head-svc 8265:8265
```

The Ray dashboard is now available at `http://localhost:8265`.

### 3. Submit jobs

**Shell script** — submits each dedup step as a separate Ray job, polling until completion:

```bash
# Exact dedup only
bash scripts/run_text_dedup.sh \
  --input s3://bucket/input/ \
  --output s3://bucket/output/

# Exact + fuzzy
bash scripts/run_text_dedup.sh \
  --input s3://bucket/input/ \
  --output s3://bucket/output/ \
  --cache s3://bucket/cache/ \
  --run-exact --run-fuzzy

# Dry run (prints commands without submitting)
bash scripts/run_text_dedup.sh --dry-run \
  --input s3://bucket/input/ \
  --output s3://bucket/output/
```

Options:

| Flag | Default | Description |
|------|---------|-------------|
| `--input` | (required) | Input dataset path |
| `--output` | (required) | Output base path |
| `--cache` | (required for fuzzy) | Cache path for fuzzy dedup |
| `--ray-address` | `$RAY_ADDRESS` or `http://localhost:8265` | Ray head address |
| `--run-exact` / `--no-exact` | `true` | Enable/disable exact dedup |
| `--run-fuzzy` / `--no-fuzzy` | `false` | Enable/disable fuzzy dedup |
| `--poll-interval` | `30` | Seconds between job status checks |
| `--dry-run` | `false` | Print commands without submitting |

**Python submit script** — alternative using the Ray Job Submission SDK
(uploads local code, no image rebuild needed):

```bash
python scripts/submit_eks_job.py run \
    --cmd "python -m agi_data_curator.config.run --config-path \$PWD/config/templates --config-name text_deduplication input_path=s3://bucket/input/ output_path=s3://bucket/output/"
```

See `src/agi_data_curator_harness/RUNBOOK.md` section 5 for full `submit_eks_job.py` documentation.

### 4. Check job status and logs

```bash
# List all jobs
ray job list --address http://localhost:8265

# Check status of a specific job
ray job status --address http://localhost:8265 <job-id>

# Stream logs for a running/completed job
ray job logs --address http://localhost:8265 <job-id>

# Follow logs in real-time
ray job logs --address http://localhost:8265 --follow <job-id>
```

### 5. Check the Ray dashboard

With port-forwarding active (`localhost:8265`):

- **Jobs tab** — status, duration, and logs for each submitted job
- **Cluster tab** — node health, CPU/GPU utilization, alive/dead nodes
- **Actors tab** — actor pool status (useful for debugging CustomRayExecutor)

### 6. Tear down the cluster

```bash
kubectl delete raycluster raycluster-text-dedup -n agi-dev
```

## Output Structure

```
output_path/
  exact_ids/                    # Exact identification output
    ExactDuplicateIds/          # Duplicate ID parquet files
    exact_id_generator.json     # ID generator state
    _AGI_CURATOR_SUCCESS        # Checkpoint marker
  exact_deduplicated/           # Exact removal output (clean dataset)
    _AGI_CURATOR_SUCCESS
  fuzzy_ids/                    # Fuzzy identification output (if enabled)
    FuzzyDuplicateIds/
    fuzzy_id_generator.json
    _AGI_CURATOR_SUCCESS
  fuzzy_deduplicated/           # Fuzzy removal output (if enabled)
    _AGI_CURATOR_SUCCESS
```

## Configuration

See `config/templates/text_deduplication.yaml` for all parameters including fuzzy dedup tuning (char_ngrams, num_bands, minhashes_per_band, etc.).

For EKS with KubeRay RayJob CRD (ephemeral cluster per step), see `config/templates/text_deduplication_eks.yaml`.

## Key Files

| File | Description |
|------|-------------|
| `dedup/text_dedup_workflow.py` | Workflow classes and TextDedupOrchestrator |
| `dedup/executor.py` | Custom executors with node-aware filtering for mixed GPU/CPU clusters |
| `pipeline/workflow.py` | WorkflowBase, WorkflowStep, WorkflowOrchestrator, checkpoint logic |
| `config/run.py` | Hydra entrypoint that dispatches to orchestrator/workflow/stages |
| `scripts/run_text_dedup.sh` | Shell script for step-by-step Ray job submission |
| `scripts/submit_eks_job.py` | Python CLI for submitting any job to EKS via Ray SDK |
| `config/templates/text_deduplication.yaml` | Hydra config for local/single-cluster runs |
| `config/infra/raycluster-text-dedup.yaml` | RayCluster manifest for long-running cluster |
