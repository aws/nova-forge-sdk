"""Custom Ray executors with node-aware setup filtering for mixed GPU/CPU clusters.

NeMo Curator's execute_setup_on_node broadcasts all stages to every node in
ray.nodes() using NodeAffinitySchedulingStrategy(soft=False). This causes
TaskUnschedulableError in two scenarios:

1. GPU/CPU mismatch: GPU stages (e.g., MinHashStage) are pinned to
   CPU-only workers that have no GPUs.
2. Phantom nodes: After ray.shutdown()/ray.init() cycles on EKS, dead driver
   nodes persist in ray.nodes() with CPU=0, failing any task pinned to them.

These executors monkey-patch execute_setup_on_node to filter nodes by
capability before pinning stages.
"""

from __future__ import annotations

import importlib
from typing import Any

import ray
import ray.data
from loguru import logger
from ray.util.scheduling_strategies import NodeAffinitySchedulingStrategy

from nemo_curator.backends.experimental import utils as _nemo_utils
from nemo_curator.backends.experimental.ray_actor_pool import RayActorPoolExecutor
from nemo_curator.backends.experimental.ray_data.executor import RayDataExecutor


def _filtered_execute_setup_on_node(stages, ignore_head_node=False):
    """Run stage setup only on nodes that have the required resources.

    Filters out:
    - Dead nodes (Alive=False)
    - Head node (when ignore_head_node=True)
    - Phantom/driver nodes with no CPU resources
    - GPU stages on CPU-only workers (no GPU resources)
    """
    head_node_id = _nemo_utils.get_head_node_id()
    all_nodes = ray.nodes()

    # Partition nodes for summary logging instead of per-node spam
    live_nodes = []
    dead_count = 0
    no_cpu_count = 0
    skipped_head = False

    for node in all_nodes:
        if not node.get("Alive", True):
            dead_count += 1
            continue
        node_id = node["NodeID"]
        if ignore_head_node and node_id == head_node_id:
            skipped_head = True
            continue
        node_resources = node.get("Resources", {})
        if not node_resources.get("CPU", 0):
            no_cpu_count += 1
            continue
        live_nodes.append(node)

    # Log summary instead of per-node
    logger.info(
        f"Node setup: {len(live_nodes)} live nodes, "
        f"{dead_count} dead, {no_cpu_count} no-CPU"
        f"{', head skipped' if skipped_head else ''}"
    )

    ray_tasks = []
    gpu_skip_count = 0
    for node in live_nodes:
        node_id = node["NodeID"]
        node_resources = node.get("Resources", {})
        for stage in stages:
            required_gpus = stage.resources.gpus if stage.resources is not None else 0
            if required_gpus > 0 and not node_resources.get("GPU", 0):
                gpu_skip_count += 1
                continue
            ray_tasks.append(
                _nemo_utils._setup_stage_on_node.options(
                    num_cpus=stage.resources.cpus if stage.resources is not None else 1,
                    num_gpus=stage.resources.gpus if stage.resources is not None else 0,
                    scheduling_strategy=NodeAffinitySchedulingStrategy(
                        node_id=node_id, soft=False
                    ),
                ).remote(
                    stage,
                    _nemo_utils.NodeInfo(node_id=node_id),
                    _nemo_utils.WorkerMetadata(worker_id="", allocation=None),
                )
            )

    if gpu_skip_count:
        logger.info(f"Skipped {gpu_skip_count} GPU stage setups on CPU-only nodes")

    logger.info(f"Running {len(ray_tasks)} setup tasks across {len(live_nodes)} nodes")
    ray.get(ray_tasks)


def _patch_setup_on_node(module_path: str):
    """Monkey-patch execute_setup_on_node in a given module."""
    mod = importlib.import_module(module_path)
    original = mod.execute_setup_on_node  # type: ignore[attr-defined]
    mod.execute_setup_on_node = _filtered_execute_setup_on_node  # type: ignore[attr-defined]
    return mod, original


class CustomRayExecutor(RayActorPoolExecutor):
    """RayActorPoolExecutor that filters out resource-less nodes during setup.

    Used for GPU stages (MinHash, LSH, Connected Components) where
    NeMo's default setup would crash on CPU-only or dead nodes.
    """

    def __init__(self, config: dict[str, Any] | None = None):
        super().__init__(config=config, ignore_head_node=True)

    def execute(self, stages, initial_tasks=None):
        mod, original = _patch_setup_on_node(
            "nemo_curator.backends.experimental.ray_actor_pool.executor"
        )
        logger.info("Using CustomRayExecutor — filtered node setup, head node excluded")
        try:
            return super().execute(stages, initial_tasks)
        finally:
            mod.execute_setup_on_node = original


class CustomRayDataExecutor(RayDataExecutor):
    """RayDataExecutor that filters out resource-less nodes during setup.

    Used for the streaming removal stage. Sets max_errored_blocks to
    tolerate transient worker failures (OOM-killed nodes) instead of
    aborting the entire pipeline.
    """

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        max_errored_blocks: int = 100,
    ):
        super().__init__(config=config, ignore_head_node=True)
        self._max_errored_blocks = max_errored_blocks

    def execute(self, stages, initial_tasks=None):
        mod, original = _patch_setup_on_node(
            "nemo_curator.backends.experimental.ray_data.executor"
        )
        ctx = ray.data.DataContext.get_current()
        ctx.max_errored_blocks = self._max_errored_blocks
        logger.info(
            f"Using CustomRayDataExecutor — streaming, filtered setup, "
            f"max_errored_blocks={self._max_errored_blocks}"
        )
        try:
            return super().execute(stages, initial_tasks)
        finally:
            mod.execute_setup_on_node = original
