"""Data deduplication module.

Always available:
    - ExactDedupStage, run_exact_dedup (CPU, no NeMo dependency)
    - CPUFuzzyDedupWorkflow (CPU, no NeMo dependency)

Requires ``nemo-curator`` (``pip install agi-data-curator[gpu]``):
    - ExactIdentificationWorkflow, FuzzyIdentificationWorkflow
    - DuplicateRemovalWorkflow, TextDedupOrchestrator
    - CustomRayExecutor, CustomRayDataExecutor
"""

# ── Always available (no NeMo dependency) ────────────────────────────
from agi_data_curator.dedup.exact_dedup import ExactDedupStage, run_exact_dedup
from agi_data_curator.dedup.fuzzy_dedup_cpu import (
    CPUFuzzyDedupWorkflow,
    FuzzyDedupStage,
    run_fuzzy_dedup,
)

# ── Requires nemo-curator ────────────────────────────────────────────
try:
    from agi_data_curator.dedup.executor import CustomRayDataExecutor, CustomRayExecutor
    from agi_data_curator.dedup.text_dedup_workflow import (
        DuplicateRemovalWorkflow,
        ExactIdentificationWorkflow,
        FuzzyIdentificationWorkflow,
        TextDedupOrchestrator,
    )

    _NEMO_AVAILABLE = True
except ImportError:
    _NEMO_AVAILABLE = False

__all__ = [
    # Always available
    "CPUFuzzyDedupWorkflow",
    "ExactDedupStage",
    "FuzzyDedupStage",
    "run_exact_dedup",
    "run_fuzzy_dedup",
]

if _NEMO_AVAILABLE:
    __all__.extend([
        "CustomRayDataExecutor",
        "CustomRayExecutor",
        "DuplicateRemovalWorkflow",
        "ExactIdentificationWorkflow",
        "FuzzyIdentificationWorkflow",
        "TextDedupOrchestrator",
    ])
