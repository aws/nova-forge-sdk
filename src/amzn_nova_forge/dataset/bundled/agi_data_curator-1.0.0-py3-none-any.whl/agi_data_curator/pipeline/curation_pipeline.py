"""Dual-executor curation pipeline.

Runs a sequence of :class:`CurationStage` instances using either:

- **Pure Ray** (``use_nemo_curator=False``, default): Uses ``ray.data.Dataset``
  with ``map_batches`` for distributed pandas processing. No NemoCurator
  or RAPIDS dependency required at runtime.

- **NemoCurator + xenna** (``use_nemo_curator=True``): Wraps each stage in a
  :class:`NemoCuratorAdapter` and runs via NemoCurator's ``Pipeline``
  with the xenna executor for GPU-accelerated RAPIDS processing.

Usage::

    from agi_data_curator.pipeline.curation_pipeline import CurationPipeline
    from agi_data_curator.filtering.topic_classifier import TopicClassifierStage

    pipeline = CurationPipeline(
        stages=[TopicClassifierStage(vllm_base_url="http://localhost:8000")],
        input_path="s3://bucket/input/",
        output_path="s3://bucket/output/",
        use_nemo_curator=False,
    )
    pipeline.run()
"""

from __future__ import annotations

import logging
import time
from typing import Any

from agi_data_curator.pipeline.curation_stage import CurationStage

logger = logging.getLogger(__name__)


class _RayBatchProcessor:
    """Callable wrapper for use with ``ray.data.Dataset.map_batches``.

    Ray Data requires a **class** (not an instance) for ``map_batches``
    with ``compute=ActorPoolStrategy``.  Ray instantiates one per actor
    using ``fn_constructor_kwargs``, calls ``__call__`` for each batch.
    """

    def __init__(self, stage: CurationStage):
        self._stage = stage
        self._stage.setup()

    def __call__(self, batch):  # type: ignore[no-untyped-def]
        import pandas as pd

        df = pd.DataFrame(batch) if not isinstance(batch, pd.DataFrame) else batch
        return self._stage.process_df(df)


_SUPPORTED_FORMATS = ("parquet", "jsonl")


class CurationPipeline:
    """Dual-executor pipeline for curation stages.

    Args:
        stages: Ordered list of curation stages to apply.
        input_path: Path to input data files (local or S3).
        output_path: Path for output data files (local or S3).
        input_format: Input file format — ``"parquet"`` (default) or ``"jsonl"``.
        output_format: Output file format — ``"parquet"`` (default) or ``"jsonl"``.
        output_num_files: Number of output files to write. If ``None``
            (default), uses 1 for JSONL (single file) and keeps Ray's
            natural partitioning for Parquet. Set explicitly to control
            output file count (e.g. ``10`` to split into 10 files).
        use_nemo_curator: If True, run via NemoCurator + xenna executor.
            If False (default), run via pure Ray Data.
        ray_batch_size: Batch size for Ray Data ``map_batches``.
        concurrency: Number of Ray actors for ``map_batches``. Each actor
            runs ``max_concurrent`` HTTP threads, so total vLLM load is
            ``concurrency × max_concurrent``. Default 1 to avoid
            overwhelming the vLLM server. Scale up only if you have
            multiple vLLM replicas.
        verbose: Print progress information.
    """

    def __init__(
        self,
        stages: list[CurationStage],
        input_path: str,
        output_path: str,
        input_format: str = "parquet",
        output_format: str = "parquet",
        output_num_files: int | None = None,
        use_nemo_curator: bool = False,
        ray_batch_size: int = 1024,
        concurrency: int = 1,
        verbose: bool = True,
    ):
        if input_format not in _SUPPORTED_FORMATS:
            raise ValueError(f"input_format must be one of {_SUPPORTED_FORMATS}, got {input_format!r}")
        if output_format not in _SUPPORTED_FORMATS:
            raise ValueError(f"output_format must be one of {_SUPPORTED_FORMATS}, got {output_format!r}")
        self.stages = stages
        self.input_path = input_path
        self.output_path = output_path
        self.input_format = input_format
        self.output_format = output_format
        self.output_num_files = output_num_files
        self.use_nemo_curator = use_nemo_curator
        self.ray_batch_size = ray_batch_size
        self.concurrency = concurrency
        self.verbose = verbose

    def run(self, executor: Any | None = None) -> Any:
        """Execute the pipeline.

        Args:
            executor: Optional xenna executor instance (used only when
                ``use_nemo_curator=True``). If not provided and ``use_nemo_curator=True``,
                the default executor is used.
        """
        if self.verbose:
            mode = "NemoCurator + xenna" if self.use_nemo_curator else "Ray Data"
            logger.info("Running pipeline: %s → %s [%s, %d stages]",
                        self.input_path, self.output_path, mode, len(self.stages))

        start = time.time()

        if self.use_nemo_curator:
            result = self._run_xenna(executor)
        else:
            result = self._run_ray()

        elapsed = time.time() - start
        if self.verbose:
            logger.info("Pipeline completed in %.1fs (%.1f min)", elapsed, elapsed / 60)

        return result

    def _make_reader(self) -> Any:
        """Return the appropriate NemoCurator reader stage for ``input_format``."""
        if self.input_format == "jsonl":
            from nemo_curator.stages.text.io.reader.jsonl import JsonlReader
            logger.info("Using JsonlReader for input_format=%r", self.input_format)
            return JsonlReader(self.input_path)
        else:
            from nemo_curator.stages.text.io.reader.parquet import ParquetReader
            logger.info("Using ParquetReader for input_format=%r", self.input_format)
            return ParquetReader(self.input_path)

    def _run_ray(self) -> Any:
        """Execute via pure Ray Data — no NemoCurator dependency."""
        import ray.data

        # Read
        if self.input_format == "jsonl":
            ds = ray.data.read_json(self.input_path, partition_filter=None)
        else:
            ds = ray.data.read_parquet(self.input_path)

        for stage in self.stages:
            map_kwargs: dict[str, Any] = {
                "fn": _RayBatchProcessor,
                "fn_constructor_kwargs": {"stage": stage},
                "batch_format": "pandas",
                "batch_size": self.ray_batch_size,
            }
            from ray.data import ActorPoolStrategy
            map_kwargs["compute"] = ActorPoolStrategy(
                min_size=self.concurrency,
                max_size=self.concurrency,
            )

            ds = ds.map_batches(**map_kwargs)

        # Write
        if self.output_format == "jsonl":
            self._write_jsonl(ds)
        else:
            num_files = self.output_num_files
            if num_files is not None:
                ds = ds.repartition(num_files)
            ds.write_parquet(self.output_path)
        return ds

    def _write_jsonl(self, ds: Any) -> None:
        """Write dataset as proper JSONL (one JSON object per line).

        Streams block-by-block from the Ray dataset — never collects the
        full dataset into driver memory. Each block is converted to pandas
        and appended as JSONL lines.

        Supports local paths and S3 (via ``fsspec``/``s3fs``).
        """
        import fsspec

        output_path = self.output_path.rstrip("/")

        # If path ends with .jsonl, write directly to that file.
        # Otherwise treat it as a directory and write output.jsonl inside it.
        if output_path.endswith(".jsonl"):
            file_path = output_path
        else:
            file_path = f"{output_path}/output.jsonl"

        num_files = self.output_num_files or 1
        if num_files == 1:
            total_rows = 0
            with fsspec.open(file_path, "w") as f:
                for batch in ds.iter_batches(batch_format="pandas"):
                    content = batch.to_json(orient="records", lines=True, force_ascii=False)
                    if content:
                        f.write(content)
                        if not content.endswith("\n"):
                            f.write("\n")
                    total_rows += len(batch)
            logger.info("Wrote %d rows to %s", total_rows, file_path)
        else:
            # Multi-file: collect then split (for sharding use cases)
            import numpy as np

            df = ds.to_pandas()
            chunks = np.array_split(df, num_files)
            base = file_path.rsplit(".", 1)[0]  # strip .jsonl
            for i, chunk in enumerate(chunks):
                part_path = f"{base}_{i:05d}.jsonl"
                content = chunk.to_json(orient="records", lines=True, force_ascii=False)  # type: ignore[attr-defined]
                with fsspec.open(part_path, "w") as f:
                    f.write(content)
            logger.info("Wrote %d rows across %d files to %s", len(df), num_files, output_path)

    def _run_xenna(self, executor: Any | None = None) -> Any:
        """Execute via NemoCurator Pipeline + xenna executor."""
        from nemo_curator.pipeline import Pipeline
        from nemo_curator.stages.text.io.writer.parquet import ParquetWriter

        from agi_data_curator.pipeline.nemo_adapter import NemoCuratorAdapter
        from agi_data_curator.tracking.stats_collector import StatsCollector

        pipeline = Pipeline(name="curation_pipeline")

        # Reader — pick based on detected input format
        reader = self._make_reader()
        pipeline.add_stage(reader)

        # Wrap each CurationStage in the NemoCurator adapter
        for stage in self.stages:
            adapted = NemoCuratorAdapter(stage)
            pipeline.add_stage(StatsCollector(adapted, name=stage.__class__.__name__))

        # Writer
        pipeline.add_stage(ParquetWriter(self.output_path, fields=None))

        return pipeline.run(executor=executor)
