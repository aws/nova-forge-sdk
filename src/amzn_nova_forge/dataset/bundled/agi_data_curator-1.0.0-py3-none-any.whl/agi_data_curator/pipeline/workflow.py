# Copyright (c) 2025, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

import fsspec
from loguru import logger

try:
    from nemo_curator.tasks import Task
except ImportError:
    Task = Any  # type: ignore[assignment,misc]

from agi_data_curator.pipeline.config_utils import ConfigSerializer, build_ray_entrypoint

_SUCCESS_MARKER = "_AGI_CURATOR_SUCCESS"


def write_success(output_path: str, storage_options: dict | None = None) -> None:
    """Write a _SUCCESS marker after a step completes successfully."""
    marker = f"{output_path.rstrip('/')}/{_SUCCESS_MARKER}"
    fs, _ = fsspec.core.url_to_fs(marker, **(storage_options or {}))
    fs.mkdirs(marker.rsplit("/", 1)[0], exist_ok=True)
    with fs.open(marker, "w") as f:
        f.write("")
    logger.info(f"Checkpoint: {marker}")


def check_success(output_path: str, storage_options: dict | None = None) -> bool:
    """Check whether a _SUCCESS marker exists for a given output path."""
    marker = f"{output_path.rstrip('/')}/{_SUCCESS_MARKER}"
    fs, _ = fsspec.core.url_to_fs(marker, **(storage_options or {}))
    return fs.exists(marker)


@dataclass
class WorkflowRunResult:
    """Container returned by high-level workflows to expose pipeline outputs.

    Attributes:
        workflow_name: Human readable workflow identifier (e.g., "fuzzy_dedup").
        pipeline_tasks: Mapping of pipeline names to the ``Task`` objects they produced.
        metadata: Free-form dictionary for workflow specific timing or counters.
    """

    workflow_name: str
    pipeline_tasks: dict[str, list[Task]] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    def add_pipeline_tasks(self, pipeline_name: str, tasks: list[Task] | None) -> None:
        """Record the tasks emitted by a pipeline run (empty list if None)."""
        self.pipeline_tasks[pipeline_name] = list(tasks or [])

    def extend_metadata(self, updates: dict[str, Any] | None = None) -> None:
        """Update metadata dictionary in-place."""
        if updates:
            self.metadata.update(updates)

    def add_metadata(self, key: str, value: Any) -> None:  # noqa: ANN401
        """Add a metadata key-value pair."""
        self.metadata[key] = value

    def get_metadata(self, key: str) -> Any:  # noqa: ANN401
        """Get a metadata value."""
        return self.metadata.get(key)


class WorkflowBase(ABC):
    """A single atomic job — Spark on EMR, Ray on EKS, etc.

    Subclasses implement run() to execute their job.
    """

    workflow_name: str = "workflow"

    @abstractmethod
    def run(self, *args, **kwargs) -> WorkflowRunResult: ...


@dataclass
class WorkflowStep:
    """A workflow positioned within a DAG.

    Attributes:
        name: Unique step identifier (e.g., "exact_identification").
        workflow: The workflow instance to execute for this step.
        depends_on: Names of steps that must complete before this one.
        output_path: Where this step writes output (used for _SUCCESS marker).
    """

    name: str
    workflow: WorkflowBase
    depends_on: list[str] = field(default_factory=list)
    output_path: str = ""


@dataclass
class WorkflowOrchestrator:
    """Chains workflows based on a DAG — respects dependency ordering.

    Walks the DAG in topological order. Steps only run after their
    dependencies have completed. Independent steps run in sequence locally
    (true parallelism is handled by Argo at the K8s level or using Airflow).

    Execution modes:
        - Local (submitter=None): calls workflow.run() directly.
        - Remote (submitter provided): submits each workflow via the pluggable JobSubmitter. [WIP]
        - Argo: use argo.py to generate Argo Workflow YAML from get_steps(). [WIP use argo or airflow for orchestration]
    """

    steps: list[WorkflowStep] = field(default_factory=list)
    submitter: Any = None  # JobSubmitter | None — Any to avoid circular import
    resume_from_checkpoint: bool = True
    storage_options: dict = field(default_factory=dict)
    config_name: str = ""
    config_path: str = "/app/config/templates"
    workflow_name: str = "orchestrator"

    def get_steps(self) -> list[WorkflowStep]:
        """Return the workflow steps (for Argo DAG generation)."""
        return list(self.steps)

    def get_dag(self) -> dict[str, list[str]]:
        """Return step dependency graph as {step_name: [depends_on]}."""
        return {step.name: list(step.depends_on) for step in self.steps}

    def run(self) -> WorkflowRunResult:
        """Execute the DAG in topological order."""
        execution_order = self._topological_sort()
        result = WorkflowRunResult(workflow_name=self.workflow_name)
        storage_opts = self.storage_options or None

        for step in execution_order:
            if self.resume_from_checkpoint and step.output_path and check_success(step.output_path, storage_opts):
                logger.info(f"Skipping '{step.name}' (checkpoint found)")
                continue

            if self.submitter:
                step_result = self._submit_remote(step)
            else:
                logger.info(f"Running step '{step.name}' locally")
                step_result = step.workflow.run()

            if step.output_path:
                write_success(step.output_path, storage_opts)
            result.extend_metadata({step.name: step_result.metadata})
            logger.info(f"Step '{step.name}' completed")

        return result

    def _topological_sort(self) -> list[WorkflowStep]:
        """Sort steps in topological order (dependencies first)."""
        step_map = {s.name: s for s in self.steps}
        visiting: set[str] = set()
        visited: set[str] = set()
        order: list[WorkflowStep] = []

        def visit(name: str) -> None:
            if name in visited:
                return
            if name in visiting:
                raise ValueError(f"Cycle detected involving step '{name}'")
            visiting.add(name)
            step = step_map[name]
            for dep in step.depends_on:
                if dep not in step_map:
                    raise ValueError(f"Step '{name}' depends on unknown step '{dep}'")
                visit(dep)
            visiting.discard(name)
            visited.add(name)
            order.append(step)

        for step in self.steps:
            visit(step.name)

        return order

    def _submit_remote(self, step: WorkflowStep) -> WorkflowRunResult:
        """Submit a workflow step via the configured operator."""
        logger.info(f"Submitting step '{step.name}' remotely")
        overrides = ConfigSerializer.to_hydra_overrides(step.workflow)
        entrypoint = build_ray_entrypoint(self.config_name, self.config_path, overrides)
        self.submitter.submit_and_wait(entrypoint)
        return WorkflowRunResult(workflow_name=step.name)
