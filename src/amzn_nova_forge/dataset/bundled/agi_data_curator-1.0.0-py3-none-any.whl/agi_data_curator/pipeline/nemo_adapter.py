"""Adapter that wraps a :class:`CurationStage` into a NemoCurator ProcessingStage.

This allows any ``CurationStage`` to run on the xenna executor with
RAPIDS/cuDF acceleration, without the stage itself depending on NemoCurator.

Usage::

    from agi_data_curator.pipeline.nemo_adapter import NemoCuratorAdapter
    from agi_data_curator.filtering.topic_classifier import TopicClassifier

    # Wrap for xenna execution
    nemo_stage = NemoCuratorAdapter(TopicClassifier(vllm_base_url="http://..."))
"""

from __future__ import annotations

import logging
from typing import Any

import pandas as pd

from nemo_curator.backends.base import NodeInfo, WorkerMetadata
from nemo_curator.stages.base import ProcessingStage
from nemo_curator.tasks import DocumentBatch

from agi_data_curator.pipeline.curation_stage import CurationStage

logger = logging.getLogger(__name__)


class NemoCuratorAdapter(ProcessingStage[DocumentBatch, DocumentBatch]):
    """Wraps a :class:`CurationStage` for execution on the xenna executor.

    Translates between NemoCurator's ``DocumentBatch`` interface and the
    stage's pandas DataFrame interface.

    Args:
        stage: The curation stage to wrap.
        name: Optional name for logging / stats.
    """

    def __init__(self, stage: CurationStage, name: str | None = None):
        super().__init__()
        self._stage = stage
        self._adapter_name = name or stage.__class__.__name__

    def inputs(self) -> tuple[list[str], list[str]]:
        return ["data"], self._stage.input_columns()

    def outputs(self) -> tuple[list[str], list[str]]:
        return ["data"], self._stage.output_columns()

    def setup_on_node(
        self,
        _node_info: NodeInfo | None = None,
        _worker_metadata: WorkerMetadata = None,
    ) -> None:
        pass

    def setup(self, _: WorkerMetadata | None = None) -> None:
        self._stage.setup()

    def teardown(self, *args: Any, **kwargs: Any) -> None:
        self._stage.teardown()

    def process(self, batch: DocumentBatch) -> DocumentBatch:
        df = batch.to_pandas()
        result_df = self._stage.process_df(df)
        return DocumentBatch(
            task_id=batch.task_id,
            dataset_name=batch.dataset_name,
            data=result_df,
            _metadata=batch._metadata,
            _stage_perf=batch._stage_perf,
        )
