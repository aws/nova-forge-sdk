"""Base curation stage abstraction.

Stages implement :meth:`process_df` which operates on a pandas DataFrame.
The same stage can run on:

- **Pure Ray** (default): via :class:`CurationPipeline` using Ray Data
  ``map_batches``.
- **NemoCurator + xenna**: via :class:`NemoCuratorAdapter` which wraps the
  stage into a ``ProcessingStage[DocumentBatch, DocumentBatch]`` for
  GPU-accelerated execution with RAPIDS.

This lets you write business logic once and switch execution engines via
a ``use_nemo_curator`` flag in the YAML config.

Example::

    class MyFilter(CurationStage):
        def setup(self) -> None:
            self._threshold = 50

        def process_df(self, df: pd.DataFrame) -> pd.DataFrame:
            return df[df["word_count"] >= self._threshold]

        def output_columns(self) -> list[str]:
            return []  # no new columns, just filtering
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import pandas as pd

logger = logging.getLogger(__name__)


class CurationStage(ABC):
    """Base class for all curation stages.

    Subclasses must implement:
    - :meth:`process_df`: transform a pandas DataFrame
    - :meth:`output_columns`: declare new columns added by this stage

    Optionally override:
    - :meth:`setup`: one-time initialisation (called once per worker)
    - :meth:`teardown`: cleanup
    - :meth:`input_columns`: declare required input columns
    """

    def setup(self) -> None:
        """One-time initialisation, called once per Ray worker / xenna actor."""

    def teardown(self) -> None:
        """Cleanup, called when the worker is shutting down."""

    @abstractmethod
    def process_df(self, df: pd.DataFrame) -> pd.DataFrame:
        """Process a batch of documents as a pandas DataFrame.

        This is the core business logic. The DataFrame will contain at
        least the columns declared by :meth:`input_columns`.

        Args:
            df: Input DataFrame batch.

        Returns:
            Transformed DataFrame (may have new columns, fewer rows, etc.).
        """
        ...

    def input_columns(self) -> list[str]:
        """Columns required in the input DataFrame.

        Override to declare dependencies. Default returns empty (no
        specific requirements).
        """
        return []

    @abstractmethod
    def output_columns(self) -> list[str]:
        """New columns added by this stage.

        Must be accurate — the xenna executor validates these when
        running in GPU mode.
        """
        ...
