"""Config serialization utilities for workflow orchestration.

Provides ConfigSerializer for auto-serializing workflow dataclass fields
to Hydra CLI overrides, and build_ray_entrypoint for constructing entrypoint strings.
"""

from __future__ import annotations

import dataclasses
import shlex


class ConfigSerializer:
    """Serializes workflow dataclass fields to Hydra CLI overrides."""

    @staticmethod
    def to_hydra_overrides(
        workflow: object,
        skip_keys: set[str] | None = None,
    ) -> list[str]:
        """Convert a dataclass instance to Hydra CLI override strings.

        Uses dataclasses.fields() to auto-serialize ALL fields, fixing
        the silent parameter dropping in the old _submit_ray_job approach.

        Args:
            workflow: A dataclass instance whose fields to serialize.
            skip_keys: Field names to exclude from serialization.

        Returns:
            List of "key=value" override strings.
        """
        if not dataclasses.is_dataclass(workflow):
            raise TypeError(f"Expected a dataclass, got {type(workflow).__name__}")

        skip = skip_keys or {"workflow_name", "execution_mode", "ray_address", "submitter"}
        overrides = []

        for f in dataclasses.fields(workflow):
            if f.name in skip or f.name.startswith("_"):
                continue
            val = getattr(workflow, f.name)
            if val is None:
                continue
            if isinstance(val, dict) and not val:
                continue
            if isinstance(val, bool):
                overrides.append(f"{f.name}={str(val).lower()}")
            elif isinstance(val, (int, float)):
                overrides.append(f"{f.name}={val}")
            elif isinstance(val, str):
                if val:
                    overrides.append(f"{f.name}={shlex.quote(val)}")
            else:
                overrides.append(f"{f.name}={shlex.quote(str(val))}")

        return overrides


def build_ray_entrypoint(
    config_name: str,
    config_path: str,
    overrides: list[str],
) -> str:
    """Build a Hydra entrypoint command string.

    Single source of truth for the entrypoint format used by both
    remote job submission and Argo YAML generation.
    """
    parts = [
        "python", "-m", "agi_data_curator.config.run",
        f"--config-path={shlex.quote(config_path)}",
        f"--config-name={shlex.quote(config_name)}",
        *overrides,
    ]
    return " ".join(parts)
