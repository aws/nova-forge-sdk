"""EMRWorkflow -- base class for submitting jobs on EMR.

This class handles cluster creation and step submission.

Example:
    emr_cfg = EMRClusterConfig(account="...", ...)
    workflow = EMRWorkflow(
        emr_config=emr_cfg,
        cluster_name="agi-curator-myuser-dedup",
        steps=[
            SparkSubmitStep(
                script_s3_path="s3://bucket/scripts/dedup.py",
                py_files=["s3://bucket/packages/my_lib-1.0.whl"],
                script_args=["--input", "s3://data/input/", "--output", "s3://data/output/"],
            ),
        ],
    )
    result = workflow.run()
    print(result.metadata["cluster_id"])
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from loguru import logger

from agi_data_curator.config.emr_config import (
    EMRClusterConfig,
    EMROperatorConfig,
    StepConfig,
)
from agi_data_curator.operator.emr_operator import EMROperator

from agi_data_curator.pipeline.workflow import WorkflowBase, WorkflowRunResult


@dataclass
class EMRWorkflow(WorkflowBase):
    """Workflow for submitting jobs on EMR clusters.

    Handles cluster creation and step submission via EMROperator.

    Args:
        emr_config: Pre-built EMR cluster config. Mutually exclusive with env_name.
        env_name: Environment name ("beta" or "prod") to derive cluster config from.
        num_nodes: Number of core nodes. Only used when env_name is set.
        steps: One or more EMR steps (SparkSubmitStep, CustomStep, etc.) to submit.
        cluster_name: Name for the EMR cluster. Required.
        workflow_name: Human-readable identifier for logging and result tracking.
        debug: Enable EMR debug logging (Hadoop debugging step).
        emr_release_label: EMR release version (e.g. "emr-7.12.0").
        auto_termination_idle_seconds: Idle timeout before auto-terminating the cluster.
        bootstrap_actions: Bootstrap scripts to run on cluster nodes. Keys are S3 URIs
            of the scripts, values are argument lists (empty list for no args).
        username: Override for the developer username tag. Defaults to OS user.
    """

    emr_config: Optional[EMRClusterConfig] = None
    env_name: Optional[str] = None
    num_nodes: int = 5
    steps: List[StepConfig] = field(default_factory=list)
    cluster_name: str = ""
    workflow_name: str = "emr-workflow"
    debug: bool = False
    emr_release_label: str = "emr-7.12.0"
    auto_termination_idle_seconds: int = 3600
    bootstrap_actions: Dict[str, List[str]] = field(default_factory=dict)
    username: Optional[str] = None

    def _resolve_emr_config(self) -> EMRClusterConfig:
        """Resolve EMR config from emr_config or env_name."""
        if self.emr_config is not None:
            return self.emr_config
        if self.env_name is not None:
            return EMRClusterConfig.from_env(self.env_name, num_nodes=self.num_nodes)
        raise ValueError("Provide either emr_config or env_name")

    def _build_operator_config(self) -> EMROperatorConfig:
        """Assemble the full EMROperatorConfig from workflow fields."""
        return EMROperatorConfig(
            emr=self._resolve_emr_config(),
            steps=list(self.steps),
            cluster_name=self.cluster_name,
            debug=self.debug,
            auto_termination_idle_seconds=self.auto_termination_idle_seconds,
            emr_release_label=self.emr_release_label,
            bootstrap_actions=self.bootstrap_actions,
            username=self.username,
        )

    def run(self, *args, **kwargs) -> WorkflowRunResult:
        """Create EMR cluster and submit step(s).

        Returns:
            WorkflowRunResult with submission details in metadata:
                - cluster_id: EMR cluster ID
                - cluster_name: EMR cluster name
                - step_ids: List of all EMR step IDs
                - console_url: EMR console URL
        """
        if not self.cluster_name:
            raise ValueError("cluster_name is required")

        logger.info(f"Starting workflow: {self.workflow_name}")

        config = self._build_operator_config()
        operator = EMROperator(config=config)
        submission_details = operator.submit()

        step_ids = submission_details["step_ids"]
        logger.info(
            f"Workflow '{self.workflow_name}' submitted. "
            f"Cluster: {submission_details['cluster_id']}, "
            f"Steps: {step_ids}"
        )

        result = WorkflowRunResult(workflow_name=self.workflow_name)
        result.add_metadata("cluster_id", submission_details["cluster_id"])
        result.add_metadata("cluster_name", submission_details["cluster_name"])
        result.add_metadata("step_ids", step_ids)
        result.add_metadata("console_url", submission_details["console_url"])

        return result
