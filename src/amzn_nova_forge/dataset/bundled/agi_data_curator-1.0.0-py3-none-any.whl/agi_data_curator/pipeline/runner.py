"""Programmatic pipeline runner for local and AWS Glue for Ray.

Provides a single ``run_pipeline()`` entry point that external packages
can call after ``pip install agi-data-curator``.  Handles Ray
initialisation automatically based on the detected environment:

- **AWS Glue for Ray**: Ray is pre-initialised by the Glue runtime.
  The runner detects this and skips ``ray.init()``.
- **Local / standalone**: Calls ``ray.init()`` if Ray is not already
  connected, using sensible defaults.

Usage from an external package::

    from agi_data_curator.pipeline import CurationPipeline, CurationStage
    from agi_data_curator.pipeline.runner import run_pipeline
    from agi_data_curator.filtering.url_filters import UrlsFilter

    pipeline = CurationPipeline(
        stages=[UrlsFilter()],
        input_path="s3://bucket/input/",
        output_path="s3://bucket/output/",
    )
    result = run_pipeline(pipeline)
"""

from __future__ import annotations

import logging
import os
import time
from typing import Any

import ray

from agi_data_curator.pipeline.curation_pipeline import CurationPipeline

logger = logging.getLogger(__name__)


def _is_glue_environment() -> bool:
    """Detect whether we are running inside AWS Glue for Ray."""
    # Glue sets these env vars in its runtime environment
    return bool(
        os.environ.get("GLUE_INSTALLATION")
        or os.environ.get("IS_GLUE_ENV")
        or os.environ.get("GLUE_VERSION")
    )


def _ensure_ray_initialized(ray_init_kwargs: dict[str, Any] | None = None) -> None:
    """Initialise Ray if not already connected.

    On Glue for Ray the runtime pre-initialises Ray, so we just verify
    the connection.  On local we call ``ray.init()`` with the provided
    kwargs (or sensible defaults).
    """
    if ray.is_initialized():
        logger.info("Ray already initialised — reusing existing cluster")
        return

    if _is_glue_environment():
        # Glue for Ray: connect to the pre-existing cluster
        logger.info("AWS Glue environment detected — connecting to Glue Ray cluster")
        ray.init(address="auto")
    else:
        # Local / standalone
        kwargs: dict[str, Any] = {"ignore_reinit_error": True}
        if ray_init_kwargs:
            kwargs.update(ray_init_kwargs)
        logger.info("Initialising local Ray cluster: %s", kwargs)
        ray.init(**kwargs)


def run_pipeline(
    pipeline: CurationPipeline,
    *,
    ray_init_kwargs: dict[str, Any] | None = None,
    shutdown_ray: bool = False,
) -> Any:
    """Run a :class:`CurationPipeline` on local Ray or AWS Glue for Ray.

    This is the main entry point for external packages that install
    ``agi-data-curator`` as a dependency and want to execute a pipeline
    programmatically.

    Args:
        pipeline: A fully configured :class:`CurationPipeline` instance.
        ray_init_kwargs: Optional kwargs forwarded to ``ray.init()`` when
            running locally (ignored on Glue where Ray is pre-initialised).
            Example: ``{"num_cpus": 4}`` to limit local parallelism.
        shutdown_ray: If True, call ``ray.shutdown()`` after the pipeline
            completes. Default False — useful when running multiple
            pipelines in sequence.

    Returns:
        The result from ``pipeline.run()`` (a ``ray.data.Dataset`` on the
        pure Ray path, or NemoCurator pipeline results on the xenna path).

    Example::

        from agi_data_curator.pipeline import CurationPipeline
        from agi_data_curator.pipeline.runner import run_pipeline
        from agi_data_curator.filtering.url_filters import UrlsFilter

        pipeline = CurationPipeline(
            stages=[UrlsFilter(max_url_to_text_ratio=0.3)],
            input_path="s3://my-bucket/raw/",
            output_path="s3://my-bucket/curated/",
        )
        run_pipeline(pipeline)
    """
    _ensure_ray_initialized(ray_init_kwargs)

    env_label = "Glue" if _is_glue_environment() else "local"
    logger.info(
        "Running pipeline on %s: %s → %s (%d stages)",
        env_label, pipeline.input_path, pipeline.output_path, len(pipeline.stages),
    )

    start = time.time()
    try:
        result = pipeline.run()
    finally:
        if shutdown_ray:
            logger.info("Shutting down Ray")
            ray.shutdown()

    elapsed = time.time() - start
    logger.info("Pipeline completed in %.1fs (%.1f min)", elapsed, elapsed / 60)
    return result
