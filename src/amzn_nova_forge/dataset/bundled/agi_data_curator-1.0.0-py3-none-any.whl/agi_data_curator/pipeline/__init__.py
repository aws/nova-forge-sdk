"""Pipeline module for AGIDataCurator.

Provides the dual-executor pipeline framework:

- :class:`CurationStage` — base class for all curation stages (always available)
- :class:`CurationPipeline` — runs stages via Ray Data or NemoCurator + xenna
- :class:`NemoCuratorAdapter` — wraps a CurationStage for xenna execution
  (only available when ``nemo-curator`` is installed)
- :class:`EMRWorkflow` — EMR-based workflow runner
"""

from agi_data_curator.pipeline.curation_pipeline import CurationPipeline
from agi_data_curator.pipeline.curation_stage import CurationStage
from agi_data_curator.pipeline.runner import run_pipeline

# NemoCuratorAdapter requires nemo-curator — only available with [gpu] extra.
try:
    from agi_data_curator.pipeline.nemo_adapter import NemoCuratorAdapter
except ImportError:
    NemoCuratorAdapter = None  # type: ignore[assignment,misc]

# EMRWorkflow may have additional dependencies
try:
    from agi_data_curator.pipeline.emr_workflow import EMRWorkflow
except ImportError:
    EMRWorkflow = None  # type: ignore[assignment,misc]

__all__ = [
    "CurationStage",
    "CurationPipeline",
    "NemoCuratorAdapter",
    "EMRWorkflow",
    "run_pipeline",
]
