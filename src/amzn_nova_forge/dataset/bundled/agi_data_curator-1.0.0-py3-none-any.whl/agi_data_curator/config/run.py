"""
YAML pipeline runner for AGIDataCurator.

Loads a Hydra YAML config, instantiates stages or workflows, and executes
them. Supports two execution modes:

- **Workflow mode** (``workflow:`` key in YAML): Instantiates a workflow
  class (e.g. ``TopicClassificationWorkflow``) which internally uses
  ``CurationPipeline``. Works with pure Ray — no NemoCurator required.

- **Stages mode** (``stages:`` key in YAML): Builds a NemoCurator
  ``Pipeline`` from individual stages. Requires ``nemo-curator`` to be
  installed (``pip install agi-data-curator[gpu]``).

Usage:
    python -m agi_data_curator.config.run \\
        --config-path /path/to/config/templates \\
        --config-name arrow_io_pipeline \\
        file_paths="s3://bucket/arrows/" \\
        output_path="s3://bucket/curated/"
"""

import time
from typing import Any

import hydra
from loguru import logger
from omegaconf import DictConfig, OmegaConf


def _require_nemo_curator(feature: str) -> None:
    """Raise a clear error if nemo-curator is not installed."""
    try:
        import nemo_curator  # noqa: F401
    except ImportError:
        raise ImportError(
            f"{feature} requires nemo-curator. "
            "Install with: pip install agi-data-curator[gpu]"
        ) from None


def create_ray_client_from_yaml(cfg: DictConfig) -> Any:
    if "ray_client" in cfg:
        return hydra.utils.instantiate(cfg.ray_client)
    else:
        _require_nemo_curator("ray_client config")
        from nemo_curator.core.client import RayClient
        msg = "No Ray client defined in the YAML configuration. Using default Ray client."
        logger.warning(msg)
        return RayClient()


def create_pipeline_from_yaml(cfg: DictConfig) -> Any:
    logger.info(f"Hydra config: {OmegaConf.to_yaml(cfg)}")

    if "stages" in cfg and "workflow" in cfg:
        msg = "Both stages and workflow are defined in the configuration. Please define either stages or workflow, not both."
        raise RuntimeError(msg)

    if "stages" in cfg:
        # Legacy stages mode — requires NemoCurator Pipeline
        _require_nemo_curator("stages-based pipeline config")
        from nemo_curator.pipeline import Pipeline

        pipeline = Pipeline(name="yaml_pipeline", description="Create and execute a pipeline from a YAML file")

        # Add stages to the pipeline
        for p in cfg.stages:
            stage = hydra.utils.instantiate(p)
            pipeline.add_stage(stage)

        return pipeline

    elif "workflow" in cfg:
        if len(cfg.workflow) != 1:
            msg = "One workflow should be defined in the YAML configuration. Please define a single workflow."
            raise RuntimeError(msg)

        # Initialize workflow — works with both CurationPipeline-based
        # workflows (pure Ray) and legacy NemoCurator workflows.
        return hydra.utils.instantiate(cfg.workflow[0])

    else:
        msg = "Invalid YAML configuration. Please define stages to add to a pipeline or a workflow to execute."
        raise RuntimeError(msg)


def _run_stats_pipeline(pipeline: Any, cfg: DictConfig) -> None:
    """Run a NemoCurator Pipeline with stats collection."""
    from agi_data_curator.tracking.stats_collector import (
        collect_stats,
        ensure_aggregator,
        print_stats,
        save_stats,
    )

    ensure_aggregator()

    logger.info("Starting pipeline execution...")
    start = time.time()
    _results = pipeline.run()
    elapsed = time.time() - start

    pipeline_name = str(cfg.get("pipeline_name", "pipeline"))
    stats = collect_stats()
    if stats["stages"]:
        print_stats(stats, pipeline_name=pipeline_name)

        # Save report alongside output
        output_path = cfg.get("output_path", None)
        if output_path:
            report_path = f"{str(output_path).rstrip('/')}/_report.json"
            try:
                save_stats(stats, report_path, pipeline_name=pipeline_name, elapsed_s=elapsed)
            except Exception as e:
                logger.warning(f"Could not save report to {report_path}: {e}")

    n_batches = len(_results) if isinstance(_results, list) else 1
    logger.info(f"Pipeline completed in {elapsed:.1f}s. {n_batches} batches processed.")


@hydra.main(version_base=None)
def main(cfg: DictConfig) -> None:
    # Dispatch: orchestrator > workflow > stages.
    if "workflow_orchestrator" in cfg:
        logger.info("Detected workflow_orchestrator config, instantiating...")
        orchestrator = hydra.utils.instantiate(cfg.workflow_orchestrator)
        logger.info(f"Running orchestrator: {type(orchestrator).__name__}")
        start = time.time()
        result = orchestrator.run()
        elapsed = time.time() - start
        logger.info(f"Orchestrator completed: {result.workflow_name}")
        logger.info(f"Total orchestrator time: {elapsed:.1f}s ({elapsed/60:.1f}m)")

        # Collect dedup stats from S3 output metadata
        output_path = cfg.get("output_path", None)
        input_path = cfg.get("input_path", None)
        if not output_path and "workflow_orchestrator" in cfg:
            output_path = cfg.workflow_orchestrator.get("output_path", None)
        if not input_path and "workflow_orchestrator" in cfg:
            input_path = cfg.workflow_orchestrator.get("input_path", None)

        if output_path:
            from agi_data_curator.tracking.dedup_stats import collect_dedup_stats
            from agi_data_curator.tracking.stats_collector import build_unified_report, print_stats, save_stats

            dedup_stats = collect_dedup_stats(str(output_path), str(input_path) if input_path else None)
            pipeline_name = str(cfg.get("pipeline_name", result.workflow_name))
            report = build_unified_report(
                dedup_stats=dedup_stats,
                pipeline_name=pipeline_name,
                elapsed_s=elapsed,
            )
            if report["stages"]:
                print_stats(report, pipeline_name=pipeline_name)
                report_path = f"{str(output_path).rstrip('/')}/_report.json"
                try:
                    save_stats(report, report_path, pipeline_name=pipeline_name, elapsed_s=elapsed)
                except Exception as e:
                    logger.warning(f"Could not save dedup report: {e}")

    elif "workflow" in cfg or "stages" in cfg:
        pipeline = create_pipeline_from_yaml(cfg)

        # Check if this is a workflow object (has .run()) or a NemoCurator Pipeline
        if hasattr(pipeline, "run") and not hasattr(pipeline, "add_stage"):
            # Workflow object — it manages its own execution
            logger.info("Starting workflow execution...")
            start = time.time()
            pipeline.run()
            elapsed = time.time() - start
            logger.info(f"Workflow completed in {elapsed:.1f}s ({elapsed / 60:.1f} min)")
        else:
            # Create stats aggregator before pipeline runs (for StatsCollector stages)
            from agi_data_curator.tracking.stats_collector import build_unified_report, collect_stats, ensure_aggregator, print_stats, save_stats
            ensure_aggregator()

            logger.info("Starting pipeline execution...")
            start = time.time()
            _results = pipeline.run()
            elapsed = time.time() - start

            pipeline_name = str(cfg.get("pipeline_name", "pipeline"))
            filter_stats = collect_stats()

            # Dedup stats are only relevant for stages-mode pipelines that
            # include dedup stages (run_exact/run_fuzzy). Skip the S3
            # metadata scan for pure filtering/bucketing pipelines.
            dedup_stats = None
            output_path = cfg.get("output_path", None)
            if output_path and (cfg.get("run_exact", False) or cfg.get("run_fuzzy", False)):
                try:
                    from agi_data_curator.tracking.dedup_stats import collect_dedup_stats
                    dedup_stats = collect_dedup_stats(str(output_path))
                    if not dedup_stats.get("stages"):
                        dedup_stats = None
                except Exception as e:
                    logger.debug("No dedup stats available: %s", e)

            report = build_unified_report(
                filter_stats=filter_stats,
                dedup_stats=dedup_stats,
                pipeline_name=pipeline_name,
                elapsed_s=elapsed,
            )
            if report["stages"]:
                print_stats(report, pipeline_name=pipeline_name)
                if output_path:
                    report_path = f"{str(output_path).rstrip('/')}/_report.json"
                    try:
                        save_stats(report, report_path, pipeline_name=pipeline_name, elapsed_s=elapsed)
                    except Exception as e:
                        logger.warning(f"Could not save report to {report_path}: {e}")

            n_batches = len(_results) if isinstance(_results, list) else 1
            logger.info(f"Pipeline completed in {elapsed:.1f}s. {n_batches} batches processed.")


    else:
        raise RuntimeError(
            "Config must define 'workflow_orchestrator', 'workflow', or 'stages'. "
            "See config/templates/ for examples."
        )


if __name__ == "__main__":
    main()
