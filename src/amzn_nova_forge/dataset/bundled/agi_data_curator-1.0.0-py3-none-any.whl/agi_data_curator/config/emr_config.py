"""Configuration models for EMR cluster creation and job steps.

EMRClusterConfig defines the EMR cluster parameters (instance types, security groups, etc.).
StepConfig / SparkSubmitStep / CustomStep define individual EMR steps.
EMROperatorConfig bundles cluster + steps for workflow submission.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from agi_data_curator.config.operator_config import OperatorConfig

# Environment defaults for EMR infrastructure.
# Each entry provides account, IAM roles, security groups, subnets, and region.
_ENV_DEFAULTS = {
    "beta": {
        "account": "926989854342",
        "emr_ec2_role": "EMR_EC2_DefaultRole",
        "emr_role": "EMR_DefaultRole",
        "region": "us-west-2",
        "sg_core": "sg-0e3335eb5060c529c",
        "sg_master": "sg-0e3335eb5060c529c",
        "sg_service": "sg-0a5b1dd6df7733c4e",
        "subnets": [
            "subnet-002c33dc7857065e5",
            "subnet-0212a26be2f5e9dec",
            "subnet-0aefa86b761cfb7d2",
            "subnet-0f288dc72f6edccca",
        ],
    }
    # ,
    # "prod": {
    #     "account": "014498623177",
    #     "emr_ec2_role": "PLACEHOLDER",
    #     "emr_role": "PLACEHOLDER",
    #     "region": "us-east-1",
    #     "sg_core": "PLACEHOLDER",
    #     "sg_master": "PLACEHOLDER",
    #     "sg_service": "PLACEHOLDER",
    #     "subnets": ["PLACEHOLDER"],
    # },
}


@dataclass
class EMRClusterConfig:
    """EMR cluster infrastructure configuration.

    Use ``EMRClusterConfig.from_env("beta", num_nodes=10)`` to get pre-configured
    defaults for a known environment, or construct directly for full control.

    Args:
        account: AWS account ID.
        emr_ec2_role: IAM role for EC2 instances (JobFlowRole).
        emr_role: IAM service role for EMR (ServiceRole).
        num_nodes: Number of core nodes in the cluster.
        region: AWS region (e.g. "us-west-2").
        sg_core: Security group ID for core/slave nodes.
        sg_master: Security group ID for the master node.
        sg_service: Service-access security group ID.
        subnets: EC2 subnet IDs for cluster placement.
        sg_core_additional: Additional security groups for core nodes.
        sg_master_additional: Additional security groups for the master node.
        gpu_enabled: Use GPU instance types for core nodes.
        master_instance_types: Instance type candidates for the master fleet.
        core_instance_types: Instance type candidates for the core fleet.
            Auto-set based on gpu_enabled if empty.
        step_concurrency_level: Max concurrent steps on the cluster.
    """

    account: str
    emr_ec2_role: str
    emr_role: str
    num_nodes: int
    region: str
    sg_core: str
    sg_master: str
    sg_service: str
    subnets: List[str] = field(default_factory=list)
    sg_core_additional: List[str] = field(default_factory=list)
    sg_master_additional: List[str] = field(default_factory=list)
    gpu_enabled: bool = False
    master_instance_types: List[str] = field(default_factory=lambda: ["r5.8xlarge", "r6i.8xlarge", "r7i.8xlarge"])
    core_instance_types: List[str] = field(default_factory=list)
    step_concurrency_level: int = 1

    def __post_init__(self) -> None:
        if not self.core_instance_types:
            if self.gpu_enabled:
                self.core_instance_types = ["g4dn.2xlarge", "g4dn.4xlarge", "g4dn.8xlarge", "g5.8xlarge"]
            else:
                self.core_instance_types = ["r5.8xlarge", "r6i.8xlarge", "r7i.8xlarge"]

    @classmethod
    def from_env(cls, env: str, num_nodes: int, **overrides) -> "EMRClusterConfig":
        """Create an EMRClusterConfig with pre-configured defaults for a known environment.

        Args:
            env: Environment name ("beta" or "prod").
            num_nodes: Number of core nodes for the cluster.
            **overrides: Any EMRClusterConfig field to override (e.g. gpu_enabled=True).

        Returns:
            EMRClusterConfig with environment defaults + overrides applied.

        Raises:
            ValueError: If env is not a recognized environment name.
        """
        if env not in _ENV_DEFAULTS:
            raise ValueError(f"Unknown environment {env!r}. Available: {list(_ENV_DEFAULTS.keys())}")
        defaults = dict(_ENV_DEFAULTS[env])
        defaults["num_nodes"] = num_nodes  # type: ignore[assignment]
        # Deep copy the subnets list so mutations don't affect _ENV_DEFAULTS
        defaults["subnets"] = list(defaults["subnets"])
        defaults.update(overrides)
        return cls(**defaults)  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Step configs -- each step type knows how to produce its own Args list
# ---------------------------------------------------------------------------

@dataclass
class StepConfig:
    """Base for EMR step configurations.

    All EMR steps use ``command-runner.jar``. Subclasses implement
    ``to_step_args()`` to produce the ``Args`` list for ``HadoopJarStep``.

    Args:
        name: Step name shown in the EMR console. Auto-generated if empty.
        action_on_failure: What to do if the step fails.
            One of CONTINUE, CANCEL_AND_WAIT, or TERMINATE_CLUSTER.
    """

    name: str = ""
    action_on_failure: str = "CONTINUE"  # CONTINUE | CANCEL_AND_WAIT | TERMINATE_CLUSTER

    def to_step_args(self) -> List[str]:
        """Return the Args list for HadoopJarStep."""
        raise NotImplementedError("Subclasses must implement to_step_args()")


@dataclass
class SparkSubmitStep(StepConfig):
    """Spark-submit step configuration.

    Builds a full ``spark-submit`` args list including confs for memory,
    cores, docker, env vars, py_files, and script arguments.

    Args:
        script_s3_path: S3 path to the Python script to submit.
        py_files: Additional Python files/packages (.whl, .zip, .py) to distribute.
        script_args: Arguments passed to the script after the script path.
        deploy_mode: Spark deploy mode ("client" or "cluster").
        extra_confs: Additional Spark confs as key-value pairs (e.g. spark.dynamicAllocation.enabled=true).
        docker_image: Docker image URI for YARN container runtime. When set, ``python_path``
            defaults to ``"python3"`` instead of ``"/usr/bin/python3.11"``.
        python_path: Python interpreter path for PySpark driver and executors
            (spark.pyspark.python / spark.pyspark.driver.python). Defaults to
            ``"/usr/bin/python3.11"`` (EMR 7.x system Python), or ``"python3"`` when
            docker_image is set.
        spark_env_vars: Environment variables exported at the cluster level via
            spark-env.sh. Propagated by EMROperator into the spark-env export
            configuration so all processes (driver, executors, app master) inherit them.
        spark_driver_memory_gb: Spark driver memory in GB.
        spark_executor_memory_gb: Spark executor memory in GB.
        spark_executor_cores: Number of cores per executor.
        spark_task_cpus: Number of CPUs per task.
        spark_driver_max_result_size_gb: Max size of driver result in GB.
    """

    script_s3_path: str = ""
    py_files: List[str] = field(default_factory=list)
    script_args: List[str] = field(default_factory=list)
    deploy_mode: str = "client"
    extra_confs: Dict[str, str] = field(default_factory=dict)
    docker_image: Optional[str] = None
    python_path: Optional[str] = None
    spark_env_vars: Dict[str, str] = field(default_factory=dict)
    spark_driver_memory_gb: int = 20
    spark_executor_memory_gb: int = 20
    spark_executor_cores: int = 1
    spark_task_cpus: int = 1
    spark_driver_max_result_size_gb: int = 1

    def __post_init__(self) -> None:
        if isinstance(self.py_files, str):
            raise TypeError(
                f"py_files must be a List[str], got str. Use py_files=[{self.py_files!r}]"
            )

    def to_step_args(self) -> List[str]:
        if self.python_path is not None:
            python_path = self.python_path
        elif self.docker_image:
            python_path = "python3"
        else:
            python_path = "/usr/bin/python3.11"
        confs = [
            "--conf", f"spark.driver.memory={self.spark_driver_memory_gb}g",
            "--conf", f"spark.executor.memory={self.spark_executor_memory_gb}g",
            "--conf", f"spark.pyspark.python={python_path}",
            "--conf", f"spark.pyspark.driver.python={python_path}",
            "--conf", f"spark.executor.cores={self.spark_executor_cores}",
            "--conf", f"spark.task.cpus={self.spark_task_cpus}",
            "--conf", f"spark.driver.maxResultSize={self.spark_driver_max_result_size_gb}g",
        ]

        if self.docker_image:
            confs.extend([
                "--conf", f"spark.executorEnv.YARN_CONTAINER_RUNTIME_TYPE=docker",
                "--conf", f"spark.executorEnv.YARN_CONTAINER_RUNTIME_DOCKER_IMAGE={self.docker_image}",
                "--conf", f"spark.yarn.appMasterEnv.YARN_CONTAINER_RUNTIME_TYPE=docker",
                "--conf", f"spark.yarn.appMasterEnv.YARN_CONTAINER_RUNTIME_DOCKER_IMAGE={self.docker_image}",
            ])

        # spark_env_vars are propagated at the cluster level via spark-env
        # export configuration (see EMROperator._get_emr_confs), so we do NOT
        # emit them as step-level --conf flags here.

        for key, value in self.extra_confs.items():
            confs.extend(["--conf", f"{key}={value}"])

        parts = [
            "spark-submit",
            "--deploy-mode", self.deploy_mode,
            *confs,
        ]

        if self.py_files:
            parts.extend(["--py-files", ",".join(self.py_files)])

        parts.append(self.script_s3_path)
        parts.extend(self.script_args)

        return parts


@dataclass
class CustomStep(StepConfig):
    """Generic EMR step that takes a raw command args list.

    Use this for s3-dist-cp, bash scripts, or any command-runner.jar command.

    Args:
        command: Raw command args list passed to command-runner.jar.

    Examples:
        CustomStep(name="copy-data", command=["s3-dist-cp", "--src", "s3://in/", "--dest", "s3://out/"])
        CustomStep(name="run-setup", command=["bash", "-c", "echo hello && ls /tmp"])
    """

    command: List[str] = field(default_factory=list)

    def to_step_args(self) -> List[str]:
        return list(self.command)



@dataclass
class EMROperatorConfig(OperatorConfig):
    """Top-level config for EMR workflow submission.

    Bundles EMR cluster config + steps + workflow-level settings.
    Inherits cluster_name, debug, auto_termination_idle_seconds, and username
    from OperatorConfig.

    Args:
        emr: EMR cluster infrastructure configuration. Required.
        steps: One or more EMR steps to submit. Required (at least one).
        emr_release_label: EMR release version (e.g. "emr-7.12.0").
        bootstrap_actions: Bootstrap scripts to run on cluster nodes. Keys are S3 URIs
            of the scripts, values are argument lists (empty list for no args).
    """

    emr: Optional[EMRClusterConfig] = None
    steps: List[StepConfig] = field(default_factory=list)
    emr_release_label: str = "emr-7.12.0"
    bootstrap_actions: Dict[str, List[str]] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.emr is None:
            raise ValueError("emr (EMRClusterConfig) is required for EMROperatorConfig")
        if not self.steps:
            raise ValueError("At least one step is required (via steps=)")

