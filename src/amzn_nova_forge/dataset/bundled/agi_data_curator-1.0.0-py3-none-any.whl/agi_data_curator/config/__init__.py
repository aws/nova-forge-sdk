"""Configuration models for AGIDataCurator."""

from agi_data_curator.config.operator_config import OperatorConfig

__all__ = ["OperatorConfig"]

# Optional EMR configs.
try:
    from agi_data_curator.config.emr_config import (
        CustomStep,
        EMROperatorConfig,
        EMRClusterConfig,
        SparkSubmitStep,
        StepConfig,
    )

    __all__ += [
        "CustomStep",
        "EMROperatorConfig",
        "EMRClusterConfig",
        "SparkSubmitStep",
        "StepConfig",
    ]
except ImportError:
    pass

# Optional Ray EKS cluster config.
try:
    from agi_data_curator.config.ray_config import RayJobSubmitterConfig

    __all__ += ["RayJobSubmitterConfig"]
except ImportError:
    pass
