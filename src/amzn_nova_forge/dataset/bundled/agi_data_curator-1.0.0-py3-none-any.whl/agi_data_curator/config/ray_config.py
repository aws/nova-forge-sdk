"""Configuration for Ray Job submission to EKS clusters."""

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from agi_data_curator.config.operator_config import OperatorConfig

_DEFAULT_EXCLUDES = [
    ".venv/",
    ".git/",
    "__pycache__/",
    "*.pyc",
    "data/",
]

_DEFAULT_RUNTIME_ENV_VARS = {
    "PYTHONPATH": "./src",
    "HYDRA_FULL_ERROR": "1",
    "CURATOR_IGNORE_RAY_HEAD_NODE": "1",
    "RAY_ADDRESS": "auto",
    "BENCHMARK_NO_GPU_MOCK": "1",
}


@dataclass
class RayJobSubmitterConfig(OperatorConfig):
    """Config for submitting Ray jobs to an EKS cluster.

    Uses Ray Job Submission SDK to upload local code and run jobs
    on a remote Ray cluster without rebuilding Docker images.

    Args:
        eks_cluster_arn: EKS cluster ARN (used for kubeconfig context & port-forward hints).
        namespace: Kubernetes namespace where RayCluster runs.
        ray_cluster_name: RayCluster CR name (for service discovery / port-forward).
        ray_address: Ray dashboard URL (port-forwarded from EKS).
        working_dir: Local directory to upload to the cluster.
        runtime_env_vars: Environment variables for Ray workers.
        excludes: File patterns to skip during upload.
        poll_interval_seconds: Seconds between job status checks.
        timeout_seconds: Max seconds to wait for job completion. None = no timeout.
    """

    eks_cluster_arn: str = "arn:aws:eks:us-east-1:926989854342:cluster/agi-scaling-beta-us-east-1"
    namespace: str = "agi-dev"
    ray_cluster_name: str = "raycluster-text-dedup"
    ray_address: str = "http://localhost:8265"
    working_dir: str = "."
    runtime_env_vars: Dict[str, str] = field(default_factory=lambda: dict(_DEFAULT_RUNTIME_ENV_VARS))
    excludes: List[str] = field(default_factory=lambda: list(_DEFAULT_EXCLUDES))
    poll_interval_seconds: int = 30
    timeout_seconds: Optional[int] = None

    @property
    def port_forward_cmd(self) -> str:
        """Generate the kubectl port-forward command for this cluster."""
        return (
            f"kubectl port-forward svc/{self.ray_cluster_name}-head-svc"
            f" 8265:8265 -n {self.namespace}"
            f" --context {self.eks_cluster_arn}"
        )

    @classmethod
    def beta(cls, **overrides) -> "RayJobSubmitterConfig":
        """Pre-configured for beta EKS cluster."""
        defaults = dict(
            cluster_name="agi-benchmark-runner",
            eks_cluster_arn="arn:aws:eks:us-east-1:926989854342:cluster/agi-scaling-beta-us-east-1",
            namespace="agi-dev",
            ray_cluster_name="raycluster-text-dedup",
        )
        defaults.update(overrides)
        return cls(**defaults)  # type: ignore[arg-type]
