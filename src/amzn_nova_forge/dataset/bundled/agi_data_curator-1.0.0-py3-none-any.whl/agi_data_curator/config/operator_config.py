"""Base configuration shared by all workflow operators."""

from dataclasses import dataclass
from typing import Optional


@dataclass
class OperatorConfig:
    """Base config shared by all operator types.

    Subclass this for engine-specific configs (EMROperatorConfig, RayOperatorConfig, etc.).

    Args:
        cluster_name: Name for the compute cluster.
        debug: Enable debug logging/steps on the cluster.
        auto_termination_idle_seconds: Idle timeout before auto-terminating the cluster.
        username: Developer username for tagging. Defaults to OS user at runtime.
    """

    cluster_name: str
    debug: bool = False
    auto_termination_idle_seconds: int = 3600
    username: Optional[str] = None
