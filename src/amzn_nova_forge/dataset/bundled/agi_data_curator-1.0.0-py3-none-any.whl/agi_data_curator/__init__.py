"""AGI Data Curator - Data curation toolkit for AGI training data."""

__version__ = "1.0.0"