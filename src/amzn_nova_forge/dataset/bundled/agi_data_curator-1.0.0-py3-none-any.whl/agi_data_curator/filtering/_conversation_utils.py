"""Shared conversation-parsing utilities for SFT filters.

Centralises the logic for normalising a raw column value (JSON string,
already-parsed list, or ``{"messages": [...]}`` / ``{"conversations": [...]}``
dict wrapper) into a flat message list, and for extracting text from
individual message content fields.
"""

from __future__ import annotations

import json

_ERR_MALFORMED = "malformed_conversation"

#: Canonical set of role values that identify assistant messages.
#: Filters that need to restrict checks to assistant turns should import this
#: rather than defining their own copy.
ASSISTANT_ROLES: frozenset[str] = frozenset({"assistant", "gpt", "bot"})


def parse_messages(value) -> tuple[list | None, str | None]:
    """Normalise a raw column value to a message list.

    Returns a ``(messages, error)`` tuple.  Exactly one element is
    non-``None``:

    - ``(list, None)`` — messages successfully extracted (may be empty).
    - ``(None, error_code)`` — the payload is malformed in some way.

    Accepted input shapes:

    - A JSON-encoded string of a message list.
    - An already-parsed ``list`` of message dicts.
    - A ``dict`` wrapper with a ``"messages"`` or ``"conversations"``
      key whose value is a ``list``.
    """
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except (json.JSONDecodeError, ValueError):
            return None, _ERR_MALFORMED

    if isinstance(value, list):
        return value, None

    if isinstance(value, dict):
        # ChatML-style {"messages": [...]} or LLaVA-style {"conversations": [...]}
        for key in ("messages", "conversations"):
            inner = value.get(key)
            if isinstance(inner, list):
                return inner, None
        return None, _ERR_MALFORMED

    # None, numbers, etc.
    return None, _ERR_MALFORMED


def extract_texts_from_content(content: object) -> list[str]:
    """Extract text strings from a message content field.

    Handles plain strings, and lists of content blocks
    (``{"type": "text", "text": ...}`` dicts or plain strings).

    Returns a list of non-empty text strings found in the content.
    """
    if isinstance(content, str):
        return [content] if content else []
    if isinstance(content, list):
        texts: list[str] = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                t = block.get("text", "")
                if t:
                    texts.append(t)
            elif isinstance(block, str) and block:
                texts.append(block)
        return texts
    return []


def extract_text_from_content(content: object) -> str:
    """Extract text from a message content field as a single string.

    Like :func:`extract_texts_from_content` but joins all text blocks
    with newlines.
    """
    return "\n".join(extract_texts_from_content(content))
