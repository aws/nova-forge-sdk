"""Data filtering module.

Stages that extend :class:`CurationStage` (pure Ray compatible) are always
available.  Legacy stages that extend NemoCurator's ``ProcessingStage``
directly require ``pip install agi-data-curator[gpu]``.
"""

# ── Always available (CurationStage-based) ───────────────────────────
from agi_data_curator.filtering.language_detection import LanguageDetectionStage
from agi_data_curator.filtering.text_filters import (
    AlphanumericFilter,
    AverageLineLengthFilter,
    CharacterLengthFilter,
    CharRepetitionFilter,
    MojibakeFilter,
    WordRepetitionFilter,
)
from agi_data_curator.filtering.text_skeleton_hasher import (
    TextSkeletonHasher,
    extract_skeleton,
)
from agi_data_curator.filtering.topic_classifier import (
    TopicClassifier,
    fdc_code_to_topic,
    parse_structured_output,
)

# ── Legacy stages (require nemo-curator) ─────────────────────────────
# These extend ProcessingStage directly and are only importable when
# nemo-curator is installed (pip install agi-data-curator[gpu]).
try:
    from agi_data_curator.filtering.column_filters import (
        DuplicateCountFilter,
        TokenCountFilter as ColumnTokenCountFilter,
        TruncationFilter,
    )
    from agi_data_curator.filtering.heuristic_filters import (
        ContainsThinkOpenTagFilter,
        EmptyThinkTagsFilter,
        MalformedBoxedFilter,
        MissingThinkCloseTagFilter,
        MissingThinkOpenTagFilter,
        SystemPromptFilter,
        ThinkingOnFilter,
    )
    from agi_data_curator.filtering.model_filters import (
        ApplyChatTemplate,
        CompletionTokenCountFilter,
        NonEnglishFilter,
        TokenCountFilter,
    )

    _NEMO_AVAILABLE = True
except ImportError:
    _NEMO_AVAILABLE = False

__all__ = [
    # Always available
    "AlphanumericFilter",
    "AverageLineLengthFilter",
    "CharacterLengthFilter",
    "CharRepetitionFilter",
    "LanguageDetectionStage",
    "MojibakeFilter",
    "TextSkeletonHasher",
    "TopicClassifier",
    "WordRepetitionFilter",
    "extract_skeleton",
    "fdc_code_to_topic",
    "parse_structured_output",
]

if _NEMO_AVAILABLE:
    __all__.extend([
        # Column-based filters
        "ColumnTokenCountFilter",
        "TruncationFilter",
        "DuplicateCountFilter",
        # Heuristic filters
        "ThinkingOnFilter",
        "EmptyThinkTagsFilter",
        "MalformedBoxedFilter",
        "MissingThinkCloseTagFilter",
        "ContainsThinkOpenTagFilter",
        "MissingThinkOpenTagFilter",
        "SystemPromptFilter",
        # Model-based filters
        "NonEnglishFilter",
        "TokenCountFilter",
        "CompletionTokenCountFilter",
        "ApplyChatTemplate",
    ])
