"""Filter conversations by special character ratio in text content.

Adapted to
the CurationStage / pandas batch API.  Iterates over every message's text
content blocks and checks the ratio of non-alphanumeric characters.  If any
single block exceeds the threshold the row is flagged.

Two modes:

- **Filter mode** (default, ``annotate_only=False``): drops rows where any text
  block exceeds the threshold.
- **Annotate mode** (``annotate_only=True``): keeps all rows and adds a
  ``special_char_ratio_filter_error`` column with ``None`` for clean rows or one of:

  - ``"high_special_char_ratio"`` -- at least one block exceeds the threshold
  - ``"malformed_conversation"`` -- messages column could not be parsed

Usage via ForgeWorkflows::

    forge.execute("special_char_ratio_filter", messages_field="messages")

Usage standalone::

    stage = SpecialCharRatioFilter(threshold=0.5, annotate_only=True)
    df_out = stage.process_df(df_in)
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from agi_data_curator.filtering._conversation_utils import (
    _ERR_MALFORMED,
    extract_texts_from_content,
    parse_messages,
)
from agi_data_curator.pipeline.curation_stage import CurationStage

if TYPE_CHECKING:
    import pandas as pd

_ANNOTATE_COLUMN = "special_char_ratio_filter_error"
_ERR_HIGH_RATIO = "high_special_char_ratio"


def _compute_special_char_ratio(text: str) -> float:
    total = len(text)
    if total == 0:
        return 0.0
    special_count = sum(1 for ch in text if not ch.isalnum())
    return special_count / total


def _validate(value: object, threshold: float) -> str | None:
    messages, err = parse_messages(value)
    if err is not None:
        return _ERR_MALFORMED

    for msg in messages:  # type: ignore[union-attr]
        if not isinstance(msg, dict):
            continue
        for field in ("content", "value"):
            raw = msg.get(field)
            if raw is None:
                continue
            for text in extract_texts_from_content(raw):
                if _compute_special_char_ratio(text) > threshold:
                    return _ERR_HIGH_RATIO
    return None


class SpecialCharRatioFilter(CurationStage):
    """Filter conversations where text has excessive special characters.

    A special character is any character where ``char.isalnum()`` is False
    (spaces, tabs, newlines, punctuation, emojis, symbols, etc.).

    Each text content block within a message is checked independently.  If
    any single block exceeds the threshold the entire row is flagged.

    Args:
        messages_field: Column holding the conversation. Accepts a JSON
            string, an already-parsed list, or a ``{"messages": [...]}``
            / ``{"conversations": [...]}`` dict wrapper.
        threshold: Maximum allowed ratio of special characters per text
            block (0.0-1.0). Default ``0.7``.
        annotate_only: If ``True``, keep all rows and add the
            ``special_char_ratio_filter_error`` column. If ``False``
            (default), drop rows that fail.
    """

    def __init__(
        self,
        messages_field: str = "messages",
        threshold: float = 0.7,
        annotate_only: bool = False,
    ) -> None:
        self._messages_field = messages_field
        self._threshold = threshold
        self._annotate_only = annotate_only

    def input_columns(self) -> list[str]:
        return [self._messages_field]

    def output_columns(self) -> list[str]:
        return [_ANNOTATE_COLUMN] if self._annotate_only else []

    def process_df(self, df: "pd.DataFrame") -> "pd.DataFrame":
        if len(df) == 0:
            result = df.copy()
            if self._annotate_only:
                result[_ANNOTATE_COLUMN] = []
            return result

        errors = [_validate(val, self._threshold) for val in df[self._messages_field]]

        if self._annotate_only:
            result = df.copy()
            result[_ANNOTATE_COLUMN] = errors
            return result

        keep = [e is None for e in errors]
        return df[keep].reset_index(drop=True)
