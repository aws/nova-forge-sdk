"""Topic classification stage using a vLLM-served model.

Sends text to a vLLM OpenAI-compatible endpoint for topic classification,
adds a ``topic`` column (and optional dimension columns), and optionally
filters to allowed topics.

The default model (``EssentialAI/eai-distill-0.5b``) uses the system prompt
``"taxonomy"`` and returns a structured 10-line response with numeric codes
across multiple dimensions.  Line 1 contains FDC (Fine-grained Dewey
Classification) codes which are mapped to human-readable topic names.

This stage extends :class:`CurationStage` and can run on:

- **Pure Ray** (``use_nemo_curator=False``): via ``CurationPipeline`` / Ray Data
- **NemoCurator + xenna** (``use_nemo_curator=True``): via ``NemoCuratorAdapter``
"""

from __future__ import annotations

import itertools
import logging
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import pandas as pd
import requests

from agi_data_curator.filtering.fdc_labels import fdc_code_to_labels
from agi_data_curator.pipeline.curation_stage import CurationStage

logger = logging.getLogger(__name__)

# ── FDC (Dewey Decimal) top-level category mapping ───────────────────
# Maps the hundreds digit (0-9) to a human-readable topic name.
_FDC_TOP_LEVEL: dict[int, str] = {
    0: "Computer Science & Information",
    1: "Philosophy & Psychology",
    2: "Religion",
    3: "Social Sciences",
    4: "Language",
    5: "Science",
    6: "Technology",
    7: "Arts & Recreation",
    8: "Literature",
    9: "History & Geography",
}

# ── Dimension labels for the 10-line structured output ───────────────
DIMENSION_NAMES: list[str] = [
    "fdc",                    # Line 1: FDC primary,secondary
    "bloom_cognitive",        # Line 2: Bloom's cognitive process (1-6)
    "bloom_knowledge",        # Line 3: Bloom's knowledge domain (1-4)
    "document_type_v1",       # Line 4: Document type v1 (1-17)
    "extraction_artifacts",   # Line 5: Extraction artifacts (0-4)
    "missing_content",        # Line 6: Missing content (0-6)
    "document_type_v2",       # Line 7: Document type v2 (1-25)
    "reasoning_depth",        # Line 8: Reasoning depth (1-6)
    "technical_correctness",  # Line 9: Technical correctness (1-6)
    "educational_level",      # Line 10: Educational level (1-5)
]

# ── Human-readable label maps for each dimension ─────────────────────
# Source: EssentialAI/essential-web-v1.0 schema documentation
# (Content rephrased for compliance with licensing restrictions)

_BLOOM_COGNITIVE_LABELS: dict[int, str] = {
    -1: "Abstain",
    1: "Remember",
    2: "Understand",
    3: "Apply",
    4: "Analyze",
    5: "Evaluate",
    6: "Create",
}

_BLOOM_KNOWLEDGE_LABELS: dict[int, str] = {
    -1: "Abstain",
    1: "Factual",
    2: "Conceptual",
    3: "Procedural",
    4: "Metacognitive",
}

_DOCUMENT_TYPE_V1_LABELS: dict[int, str] = {
    -1: "Abstain",
    1: "News/Editorial",
    2: "Academic/Research",
    3: "Reference/Encyclopedic/Educational",
    4: "Code/Software",
    5: "Social/Forum",
    6: "Promotional/Advertisement",
    7: "Search/Directory/Bibliography",
    8: "Adult/Pornographic",
    9: "Personal/Misc",
    10: "Machine-Generated",
    11: "Legal/Regulatory",
    12: "Government/Political",
    13: "Literary/Creative",
    14: "Reviews/Critiques",
    15: "E-Commerce/Marketplace",
    16: "Images/Videos/Audio",
    17: "Other/Unclassified",
}

_EXTRACTION_ARTIFACTS_LABELS: dict[int, str] = {
    -1: "Abstain",
    0: "No Artifacts",
    1: "Leftover HTML",
    2: "Text Extraction Errors",
    3: "Irrelevant Content",
    4: "Indeterminate",
}

_MISSING_CONTENT_LABELS: dict[int, str] = {
    -1: "Abstain",
    0: "No Missing Content",
    1: "Truncated Snippets",
    2: "Click Here References",
    3: "Incoherent Flow",
    4: "Missing Images or Figures",
    5: "Missing Referenced Data",
    6: "Indeterminate",
}

_DOCUMENT_TYPE_V2_LABELS: dict[int, str] = {
    -1: "Abstain",
    1: "About (Org.)",
    2: "About (Personal)",
    3: "Academic Writing",
    4: "Audio Transcript",
    5: "Comment Section",
    6: "Content Listing",
    7: "Creative Writing",
    8: "Documentation",
    9: "FAQ",
    10: "Knowledge Article",
    11: "Legal Notices",
    12: "Listicle",
    13: "News (Org.)",
    14: "News Article",
    15: "Nonfiction Writing",
    16: "Personal Blog",
    17: "Product Page",
    18: "Q&A Forum",
    19: "Spam / Ads",
    20: "Structured Data",
    21: "Customer Support",
    22: "Truncated",
    23: "Tutorial",
    24: "User Review",
    25: "Other/Unclassified",
}

_REASONING_DEPTH_LABELS: dict[int, str] = {
    -1: "Abstain",
    1: "No Reasoning",
    2: "Basic Reasoning",
    3: "Intermediate Reasoning",
    4: "Advanced Reasoning",
    5: "Exceptional Reasoning",
    6: "Indeterminate",
}

_TECHNICAL_CORRECTNESS_LABELS: dict[int, str] = {
    -1: "Abstain",
    1: "Technically Flawed",
    2: "Partially Correct",
    3: "Mostly Correct",
    4: "Highly Correct",
    5: "Exceptionally Correct",
    6: "Not Applicable/Indeterminate",
}

_EDUCATIONAL_LEVEL_LABELS: dict[int, str] = {
    -1: "Abstain",
    1: "General Audience",
    2: "High School Level",
    3: "Undergraduate Level",
    4: "Graduate/Expert Level",
    5: "Indeterminate",
}

# Map dimension name → label lookup dict (excludes fdc which uses _FDC_TOP_LEVEL)
_DIMENSION_LABEL_MAPS: dict[str, dict[int, str]] = {
    "bloom_cognitive": _BLOOM_COGNITIVE_LABELS,
    "bloom_knowledge": _BLOOM_KNOWLEDGE_LABELS,
    "document_type_v1": _DOCUMENT_TYPE_V1_LABELS,
    "extraction_artifacts": _EXTRACTION_ARTIFACTS_LABELS,
    "missing_content": _MISSING_CONTENT_LABELS,
    "document_type_v2": _DOCUMENT_TYPE_V2_LABELS,
    "reasoning_depth": _REASONING_DEPTH_LABELS,
    "technical_correctness": _TECHNICAL_CORRECTNESS_LABELS,
    "educational_level": _EDUCATIONAL_LEVEL_LABELS,
}

# Pre-compiled regex for extracting numeric values from a line
_NUMERIC_PAIR = re.compile(r"^\s*([\d.]+)\s*(?:,\s*([\d.]+|skip))?\s*$", re.IGNORECASE)

# Default system prompt for the EssentialAI/eai-distill-0.5b model
DEFAULT_SYSTEM_PROMPT = "taxonomy"

# Maximum character length per chunk when splitting long documents
_CHUNK_CHAR_LIMIT = 2000


def fdc_code_to_topic(code_str: str) -> str:
    """Map an FDC code string (e.g. ``'547.0'``) to a top-level topic name.

    Returns ``'Unknown'`` if the code cannot be parsed.
    """
    try:
        code = int(float(code_str))
        hundreds = code // 100
        return _FDC_TOP_LEVEL.get(hundreds, "Unknown")
    except (ValueError, TypeError):
        return "Unknown"


def parse_structured_output(raw: str) -> dict[str, str]:
    """Parse the 10-line structured output from eai-distill-0.5b.

    Returns a dict keyed by dimension name.  The ``fdc`` value is the
    raw primary code (e.g. ``'547.0'``); callers should use
    :func:`fdc_code_to_topic` to get the human-readable name.
    """
    lines = raw.strip().splitlines()
    result: dict[str, str] = {}
    for i, dim_name in enumerate(DIMENSION_NAMES):
        if i < len(lines):
            result[dim_name] = lines[i].strip()
        else:
            result[dim_name] = ""
    return result


def _extract_primary_value(line: str) -> str:
    """Extract the primary (first) numeric value from a ``primary,secondary`` line."""
    m = _NUMERIC_PAIR.match(line)
    if m:
        return m.group(1)
    # Fallback: take everything before the first comma
    parts = line.split(",", 1)
    return parts[0].strip()


def _extract_secondary_value(line: str) -> str:
    """Extract the secondary (second) numeric value from a ``primary,secondary`` line.

    Returns empty string if no secondary value or if it is ``skip``.
    """
    m = _NUMERIC_PAIR.match(line)
    if m and m.group(2) and m.group(2).lower() != "skip":
        return m.group(2)
    # Fallback: take everything after the first comma
    parts = line.split(",", 1)
    if len(parts) > 1:
        val = parts[1].strip()
        return "" if val.lower() == "skip" else val
    return ""


def _code_to_label(dim_name: str, raw_line: str) -> str:
    """Convert a raw dimension line (e.g. ``'3,2'``) to a human-readable label.

    Uses the primary value and looks it up in the dimension's label map.
    Returns the raw value if no mapping exists.
    """
    label_map = _DIMENSION_LABEL_MAPS.get(dim_name)
    if not label_map:
        return raw_line
    primary = _extract_primary_value(raw_line)
    try:
        code = int(float(primary))
        return label_map.get(code, raw_line)
    except (ValueError, TypeError):
        return raw_line


def _code_to_label_secondary(dim_name: str, raw_line: str) -> str:
    """Convert the secondary value of a dimension line to a human-readable label.

    Returns empty string if no secondary value exists or if it is ``skip``.
    """
    label_map = _DIMENSION_LABEL_MAPS.get(dim_name)
    if not label_map:
        return ""
    secondary = _extract_secondary_value(raw_line)
    if not secondary:
        return ""
    try:
        code = int(float(secondary))
        return label_map.get(code, secondary)
    except (ValueError, TypeError):
        return ""


def _chunk_document(text: str, char_limit: int = _CHUNK_CHAR_LIMIT) -> str:
    """Build a beginning/middle/end excerpt for long documents.

    The eai-distill-0.5b model uses a chunking strategy that samples from
    the beginning, middle, and end of long documents.  This function
    replicates that strategy so the model sees representative content.
    """
    if len(text) <= char_limit * 3:
        return text

    beginning = text[:char_limit]
    mid_start = (len(text) - char_limit) // 2
    middle = text[mid_start : mid_start + char_limit]
    end = text[-char_limit:]
    return f"{beginning}\n[...]\n{middle}\n[...]\n{end}"


class TopicClassifier(CurationStage):
    """Classify documents by topic using a vLLM-served model.

    Calls the ``/v1/chat/completions`` endpoint on one or more running
    vLLM servers.  When multiple URLs are provided (comma-separated or
    as a list), requests are distributed round-robin across replicas for
    higher throughput.

    Adds a ``topic`` column (level 1, e.g. "Science"), ``topic_level_2``
    (e.g. "Chemistry"), and ``topic_level_3`` (e.g. "Organic Chemistry")
    mapped from FDC codes.  Optionally adds columns for all 10
    classification dimensions.

    When *allowed_topics* is set, documents whose predicted topic is not
    in the list are dropped.

    Args:
        vllm_base_url: Base URL(s) of the vLLM server(s).  Accepts a
            single URL string, a comma-separated string of URLs, or a
            list of URL strings for multi-replica setups.
        model_name: Model identifier used in the API request.
        text_field: Column containing the text to classify.
        topic_field: Output column name for the predicted topic.
        system_prompt: System prompt for the model.  Defaults to
            ``"taxonomy"`` for the eai-distill-0.5b model.
        allowed_topics: If provided, keep only documents matching these topics.
        max_tokens: Maximum tokens for the model response.
        temperature: Sampling temperature (0 for deterministic).
        batch_size: Number of documents per API call.
        request_timeout: HTTP timeout in seconds per request.
        include_all_dimensions: If True, add columns for all 10 classification
            dimensions (``fdc_raw``, ``bloom_cognitive``, etc.).
        max_concurrent: Maximum number of concurrent HTTP requests to vLLM.
            Higher values improve throughput since vLLM batches internally.
    """

    def __init__(
        self,
        vllm_base_url: str | list[str] = "http://localhost:8000",
        model_name: str = "EssentialAI/eai-distill-0.5b",
        text_field: str = "text",
        topic_field: str = "topic",
        system_prompt: str = DEFAULT_SYSTEM_PROMPT,
        allowed_topics: list[str] | None = None,
        max_tokens: int = 100,
        temperature: float = 0.0,
        batch_size: int = 32,
        request_timeout: int = 120,
        include_all_dimensions: bool = False,
        max_concurrent: int = 32,
    ):
        # Normalise URLs: accept string (single or comma-separated) or list
        if isinstance(vllm_base_url, str):
            urls = [u.strip().rstrip("/") for u in vllm_base_url.split(",") if u.strip()]
        else:
            urls = [u.strip().rstrip("/") for u in vllm_base_url]
        if not urls:
            urls = ["http://localhost:8000"]
        self.vllm_base_urls = urls
        self.vllm_base_url = urls[0]
        self.model_name = model_name
        self.text_field = text_field
        self.topic_field = topic_field
        self.system_prompt = system_prompt
        self.allowed_topics = (
            [t.strip().lower() for t in allowed_topics] if allowed_topics else None
        )
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.batch_size = batch_size
        self.request_timeout = request_timeout
        self.include_all_dimensions = include_all_dimensions
        self.max_concurrent = max_concurrent

    # ── CurationStage interface ──────────────────────────────────────

    def input_columns(self) -> list[str]:
        return [self.text_field]

    def output_columns(self) -> list[str]:
        out_cols = [self.topic_field, "topic_level_2", "topic_level_3"]
        if self.include_all_dimensions:
            out_cols.append("fdc_raw")
            for dim in DIMENSION_NAMES[1:]:
                out_cols.append(dim)
                out_cols.append(f"{dim}_secondary")
            # Secondary FDC topic columns
            out_cols.extend([
                "topic_secondary",
                "topic_level_2_secondary",
                "topic_level_3_secondary",
            ])
        return out_cols

    def setup(self) -> None:
        # Per-thread sessions via threading.local — requests.Session is
        # not officially thread-safe, so each thread gets its own session
        # with its own connection pool.
        self._local = threading.local()
        # Thread-safe round-robin iterator across vLLM replicas
        self._url_cycle = itertools.cycle(self.vllm_base_urls)
        self._url_lock = threading.Lock()
        # Persistent thread pool — avoids create/destroy overhead per batch
        self._pool = ThreadPoolExecutor(max_workers=self.max_concurrent)
        # Debug: log the first N raw responses to help diagnose parsing issues
        self._debug_count = 0
        self._debug_limit = 5

    def teardown(self) -> None:
        if hasattr(self, "_pool"):
            self._pool.shutdown(wait=False)

    def process_df(self, df: pd.DataFrame) -> pd.DataFrame:
        # Copy to avoid mutating Ray Data's internal batch buffer
        df = df.copy()

        if df.empty:
            df[self.topic_field] = pd.Series(dtype=str)
            df["topic_level_2"] = pd.Series(dtype=str)
            df["topic_level_3"] = pd.Series(dtype=str)
            if self.include_all_dimensions:
                df["fdc_raw"] = pd.Series(dtype=str)
                for dim in DIMENSION_NAMES[1:]:
                    df[dim] = pd.Series(dtype=str)
                    df[f"{dim}_secondary"] = pd.Series(dtype=str)
                df["topic_secondary"] = pd.Series(dtype=str)
                df["topic_level_2_secondary"] = pd.Series(dtype=str)
                df["topic_level_3_secondary"] = pd.Series(dtype=str)
            return df

        texts = df[self.text_field].tolist()
        classifications = self._classify_texts(texts)

        df[self.topic_field] = [c["topic"] for c in classifications]
        df["topic_level_2"] = [c["topic_level_2"] for c in classifications]
        df["topic_level_3"] = [c["topic_level_3"] for c in classifications]
        if self.include_all_dimensions:
            df["fdc_raw"] = [c["fdc_raw"] for c in classifications]
            for dim in DIMENSION_NAMES[1:]:
                df[dim] = [c.get(dim, "") for c in classifications]
                df[f"{dim}_secondary"] = [c.get(f"{dim}_secondary", "") for c in classifications]
            df["topic_secondary"] = [c.get("topic_secondary", "") for c in classifications]
            df["topic_level_2_secondary"] = [c.get("topic_level_2_secondary", "") for c in classifications]
            df["topic_level_3_secondary"] = [c.get("topic_level_3_secondary", "") for c in classifications]

        if self.allowed_topics:
            mask = df[self.topic_field].str.strip().str.lower().isin(self.allowed_topics)
            df = df[mask]

        return df

    # ── Internal helpers ─────────────────────────────────────────────

    def _get_session(self) -> requests.Session:
        """Return a per-thread requests.Session (lazy-initialised)."""
        if not hasattr(self._local, "session"):
            self._local.session = requests.Session()
        return self._local.session

    def _next_base_url(self) -> str:
        """Return the next vLLM base URL in round-robin order (thread-safe)."""
        with self._url_lock:
            return next(self._url_cycle)

    def _classify_single(self, text: str) -> dict[str, str]:
        """Classify a single document via vLLM. Thread-safe.

        Retries up to 3 times with exponential backoff on transient errors
        (connection errors, timeouts, 5xx responses) to avoid silently
        dropping documents as 'Unknown' due to momentary blips.
        """
        max_retries = 3
        for attempt in range(max_retries + 1):
            base_url = self._next_base_url()
            url = f"{base_url}/v1/chat/completions"
            chunked = _chunk_document(text)
            payload = {
                "model": self.model_name,
                "messages": [
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": chunked},
                ],
                "max_tokens": self.max_tokens,
                "temperature": self.temperature,
            }
            try:
                session = self._get_session()
                resp = session.post(url, json=payload, timeout=self.request_timeout)
                resp.raise_for_status()
                raw = resp.json()["choices"][0]["message"]["content"].strip()
                parsed = parse_structured_output(raw)

                fdc_line = parsed.get("fdc", "")
                primary_fdc = _extract_primary_value(fdc_line)
                fdc_labels = fdc_code_to_labels(primary_fdc)

                # Secondary FDC labels
                secondary_fdc = _extract_secondary_value(fdc_line)
                fdc_labels_sec = fdc_code_to_labels(secondary_fdc) if secondary_fdc else {
                    "topic": "", "topic_level_2": "", "topic_level_3": "",
                }

                # Log first few raw responses for debugging
                if self._debug_count < self._debug_limit:
                    self._debug_count += 1
                    logger.info(
                        "vLLM raw response [%d/%d]:\n%s\n"
                        "  → fdc_line=%r, primary_fdc=%r, labels=%r",
                        self._debug_count, self._debug_limit,
                        raw, fdc_line, primary_fdc, fdc_labels,
                    )

                row: dict[str, str] = {
                    "topic": fdc_labels["topic"],
                    "topic_level_2": fdc_labels["topic_level_2"],
                    "topic_level_3": fdc_labels["topic_level_3"],
                    "fdc_raw": fdc_line,
                }
                if self.include_all_dimensions:
                    row["topic_secondary"] = fdc_labels_sec["topic"]
                    row["topic_level_2_secondary"] = fdc_labels_sec["topic_level_2"]
                    row["topic_level_3_secondary"] = fdc_labels_sec["topic_level_3"]
                    for dim in DIMENSION_NAMES[1:]:
                        raw_dim = parsed.get(dim, "")
                        row[dim] = _code_to_label(dim, raw_dim)
                        row[f"{dim}_secondary"] = _code_to_label_secondary(dim, raw_dim)
                return row
            except Exception as exc:
                if attempt < max_retries:
                    backoff = 2 ** attempt  # 1s, 2s, 4s
                    logger.debug("Retry %d/%d after %.1fs (url: %s): %s",
                                 attempt + 1, max_retries, backoff, base_url, exc)
                    time.sleep(backoff)
                    continue
                logger.warning("Topic classification failed after %d retries, assigning 'Unknown': %s",
                               max_retries, exc)
                row = {"topic": "Unknown", "topic_level_2": "Unknown", "topic_level_3": "Unknown", "fdc_raw": ""}
                if self.include_all_dimensions:
                    for dim in DIMENSION_NAMES[1:]:
                        row[dim] = ""
                        row[f"{dim}_secondary"] = ""
                    row["topic_secondary"] = ""
                    row["topic_level_2_secondary"] = ""
                    row["topic_level_3_secondary"] = ""
                return row
        # Should not reach here, but satisfy type checker
        return {"topic": "Unknown", "topic_level_2": "Unknown", "topic_level_3": "Unknown", "fdc_raw": ""}

    def _classify_texts(self, texts: list[str]) -> list[dict[str, str]]:
        """Send texts to vLLM concurrently and return parsed classification dicts."""
        results: list[dict[str, str]] = [{}] * len(texts)

        future_to_idx = {
            self._pool.submit(self._classify_single, text): idx
            for idx, text in enumerate(texts)
        }
        for future in as_completed(future_to_idx):
            idx = future_to_idx[future]
            results[idx] = future.result()

        return results
