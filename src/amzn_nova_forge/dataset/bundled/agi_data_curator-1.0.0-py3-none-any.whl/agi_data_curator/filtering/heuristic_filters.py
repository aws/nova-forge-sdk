"""
Heuristic filters for text data curation.

Custom filters for specific use cases like reasoning traces,
malformed content, and tag validation.

Based on AGINemoCurator's llama-nemotron-data-curation filters.
"""

from __future__ import annotations

import re

from nemo_curator.stages.base import ProcessingStage
from nemo_curator.stages.text.filters import DocumentFilter


_BOXED_PATTERN = re.compile(r"\\boxed")

# Common system prompt indicators — case-insensitive matching
_SYSTEM_PROMPT_PATTERNS = re.compile(
    r"|".join([
        r"you are a helpful assistant",
        r"you are an ai assistant",
        r"you are a large language model",
        r"you are chatgpt",
        r"you are gpt-?\d",
        r"you are claude",
        r"as an ai language model",
        r"as a large language model",
        r"i am a helpful assistant",
        r"i am an ai assistant",
        r"i am an ai language model",
        r"\bsystem\s*:\s*you are\b",
        r"\[system\]\s*you are\b",
        r"<\|system\|>",
        r"<\|im_start\|>\s*system",
        r"<<sys>>",
        r"\[inst\].*\[/inst\]",
    ]),
    re.IGNORECASE,
)


class ThinkingOnFilter(DocumentFilter):
    """Filter documents that contain 'thinking on' indicator."""

    def __init__(self):
        super().__init__()

    def score_document(self, text: str) -> bool:
        return "on" in text.lower()

    def keep_document(self, score: bool) -> bool:
        return score


class EmptyThinkTagsFilter(DocumentFilter):
    """Filter out samples with empty think tags."""

    def __init__(self):
        super().__init__()

    def score_document(self, text: str) -> bool:
        return not (
            "<think>\n\n</think>" in text
            or "<think>\n</think>" in text
            or "<think></think>" in text
        )

    def keep_document(self, score: bool) -> bool:
        return score


class MalformedBoxedFilter(ProcessingStage):
    r"""Filter malformed samples where input contains \\boxed but output does not.

    This is a ProcessingStage (not a DocumentFilter) because it needs access
    to two columns simultaneously. ScoreFilter only passes a single text column
    to DocumentFilter.score_document, so multi-column filters must be stages.

    Usage:
        pipeline.add_stage(MalformedBoxedFilter(input_field="input", output_field="output"))
    """

    name = "malformed_boxed_filter"

    def __init__(self, input_field: str = "input", output_field: str = "output"):
        super().__init__()
        self._input_field = input_field
        self._output_field = output_field

    def inputs(self):
        return ["data"]

    def outputs(self):
        return ["data"]

    def process(self, batch):
        df = batch.to_pandas()
        if df.empty:
            return batch

        input_has_boxed = df[self._input_field].str.contains(_BOXED_PATTERN, na=False)
        output_has_boxed = df[self._output_field].str.contains(_BOXED_PATTERN, na=False)
        # Malformed = input has \boxed but output does not → discard
        keep_mask = ~(input_has_boxed & ~output_has_boxed)
        filtered_df = df[keep_mask]

        import pandas as pd
        from nemo_curator.tasks import DocumentBatch

        return DocumentBatch(
            task_id=batch.task_id,
            dataset_name=batch.dataset_name,
            data=pd.DataFrame(filtered_df),
            _metadata=batch._metadata,
        )


class MissingThinkCloseTagFilter(DocumentFilter):
    """Filter documents missing think close tag."""

    def __init__(self):
        super().__init__()

    def score_document(self, text: str) -> bool:
        return not ("<think>" in text and "</think>" not in text)

    def keep_document(self, score: bool) -> bool:
        return score


class ContainsThinkOpenTagFilter(DocumentFilter):
    """Filter documents that shouldn't contain think <think> or </think> tags."""

    def __init__(self):
        super().__init__()

    def score_document(self, text: str) -> bool:
        return not ("<think>" in text or "</think>" in text)

    def keep_document(self, score: bool) -> bool:
        return score


class MissingThinkOpenTagFilter(DocumentFilter):
    """Filter documents missing think <think> or </think> tags when reasoning is on."""

    def __init__(self):
        super().__init__()

    def score_document(self, text: str) -> bool:
        return not ("<think>" not in text or "</think>" not in text)

    def keep_document(self, score: bool) -> bool:
        return score


class SystemPromptFilter(DocumentFilter):
    """Filter documents that contain leaked system prompt patterns.

    Detects common system prompt indicators like "You are a helpful assistant",
    chat template markers (<|system|>, <<SYS>>, [INST]), and similar patterns
    that indicate the text is contaminated with LLM system prompts.

    Returns True (keep) if no system prompt is detected.
    Returns False (discard) if a system prompt pattern is found.

    Usage:
        ScoreFilter(SystemPromptFilter(), text_field="text")

    To add custom patterns:
        ScoreFilter(
            SystemPromptFilter(extra_patterns=[r"my custom pattern", r"another one"]),
            text_field="text",
        )
    """

    def __init__(self, extra_patterns: list[str] | None = None):
        super().__init__()
        if extra_patterns:
            combined = _SYSTEM_PROMPT_PATTERNS.pattern + "|" + "|".join(extra_patterns)
            self._pattern = re.compile(combined, re.IGNORECASE)
        else:
            self._pattern = _SYSTEM_PROMPT_PATTERNS

    def score_document(self, text: str) -> bool:
        return not bool(self._pattern.search(text))

    def keep_document(self, score: bool) -> bool:
        return score

