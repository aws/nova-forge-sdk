"""Language detection using FastText lid model.

Pure Ray implementation — no NeMo Curator, no GPU, no NLTK.
Document-level detection: classifies the entire text field per row.
Uses FastText batch prediction for throughput.

Runs in two modes:

- **Filter mode (default, ``annotate=False``):** drops rows outside the
  configured allowlist / below ``min_score``. The ``lang`` and
  ``lang_score`` columns are computed internally but stripped before
  return, so the caller's schema is unchanged.
- **Annotate mode (``annotate=True``):** surfaces the ``lang`` and
  ``lang_score`` columns in the output for downstream consumers
  (analyze, reporting, custom pipelines). Row filtering still applies
  when ``languages`` / ``min_score`` are set.

Usage via ForgeWorkflows::

    forge = ForgeWorkflows(
        input_path="s3://bucket/raw/",
        output_path="s3://bucket/curated/",
    )
    result = forge.execute(
        "language_detection",
        model_path="s3://bucket/models/lid.176.bin",
        text_field="text",
        languages=["en"],
        min_score=0.8,
    )

Usage standalone (filter mode)::

    from agi_data_curator.filtering.language_detection import LanguageDetectionStage

    stage = LanguageDetectionStage(
        model_path="/tmp/lid.176.bin",
        languages=["en", "fr"],
        min_score=0.8,
    )
    stage.setup()
    df_out = stage.process_df(df_in)  # same schema as df_in, fewer rows

Usage standalone (annotate mode)::

    stage = LanguageDetectionStage(
        model_path="/tmp/lid.176.bin",
        annotate=True,
    )
    stage.setup()
    df_out = stage.process_df(df_in)  # adds lang + lang_score columns
"""

from __future__ import annotations

import contextlib
import logging
import os
import tempfile
from typing import TYPE_CHECKING

from agi_data_curator.pipeline.curation_stage import CurationStage

if TYPE_CHECKING:
    import pandas as pd

logger = logging.getLogger(__name__)

_UNKNOWN_LANG = "unknown"
_LABEL_PREFIX = "__label__"
_LABEL_PREFIX_LEN = len(_LABEL_PREFIX)


@contextlib.contextmanager
def _numpy_fasttext_compat():
    """Temporarily patch ``np.array`` for fasttext numpy 2.x compatibility.

    The fasttext library calls ``np.array(probs, copy=False)`` which raises
    ``ValueError`` in numpy >= 2.0. This context manager patches ``np.array``
    to fall back to ``np.asarray`` when ``copy=False`` is rejected, then
    restores the original on exit. Only active during the ``with`` block.
    """
    import numpy as np

    if np.lib.NumpyVersion(np.__version__) < "2.0.0":
        yield
        return

    _orig = np.array

    def _compat(*args, **kwargs):
        if kwargs.get("copy") is False:
            kwargs.pop("copy")
            return np.asarray(*args, **kwargs)
        return _orig(*args, **kwargs)

    np.array = _compat
    try:
        yield
    finally:
        np.array = _orig


class LanguageDetectionStage(CurationStage):
    """Detect language of each document using FastText lid model.

    By default (``annotate=False``), the stage runs as a pure filter:
    it uses the detected language and confidence internally to decide
    which rows to keep, but strips the ``lang`` / ``lang_score`` columns
    from the output so callers' schemas are unchanged. Set
    ``annotate=True`` to keep the annotation columns in the output —
    use this when the caller wants the detection metadata surfaced
    downstream (e.g. analyze, reporting).

    When ``annotate=True``, two columns are added to the output DataFrame:
      - ``lang``: ISO 639-1 language code (e.g. ``"en"``, ``"fr"``, ``"ja"``)
      - ``lang_score``: confidence score from FastText (0.0 to 1.0)

    Optionally filters documents by:
      - Language allowlist (keep only specified languages)
      - Minimum confidence score threshold

    When ``languages=None`` and ``min_score=0.0``, operates in
    pass-through mode — no row filtering is applied (except empty/null
    texts, which are dropped unless ``keep_undetected=True``).

    Args:
        model_path: Path to FastText lid model file (local or S3).
            Supports ``lid.176.bin`` (~126MB) and ``lid.176.ftz`` (~917KB).
        text_field: Input column containing document text.
        lang_field: Output column name for detected language code
            (only surfaced when ``annotate=True``).
        score_field: Output column name for confidence score
            (only surfaced when ``annotate=True``).
        languages: Language allowlist. ``None`` keeps all languages.
            Use ISO 639-1 codes (e.g. ``["en", "fr", "de"]``).
        min_score: Minimum confidence threshold (0.0-1.0).
            ``0.0`` disables score filtering.
        keep_undetected: If ``True``, keep documents where detection
            fails (empty text, etc.). Default ``False``.
        annotate: If ``True``, keep the ``lang`` and ``lang_score``
            columns in the output. Default ``False`` (filter-only —
            columns are computed internally but dropped before return).
    """

    def __init__(
        self,
        model_path: str,
        text_field: str = "text",
        lang_field: str = "lang",
        score_field: str = "lang_score",
        languages: list[str] | None = None,
        min_score: float = 0.0,
        keep_undetected: bool = False,
        annotate: bool = False,
    ):
        self._model_path = model_path
        self._text_field = text_field
        self._lang_field = lang_field
        self._score_field = score_field
        self._languages = frozenset(lang.lower() for lang in languages) if languages else None
        self._min_score = min_score
        self._keep_undetected = keep_undetected
        self._annotate = annotate
        self._model = None
        self._resolved_model_path: str | None = None

    def input_columns(self) -> list[str]:
        return [self._text_field]

    def output_columns(self) -> list[str]:
        """Columns this stage adds to the output schema.

        Returns an empty list in filter-only mode (``annotate=False``,
        the default) — the ``lang`` / ``lang_score`` columns are computed
        internally for filtering but stripped before ``process_df``
        returns. In annotate mode, returns the configured
        ``lang_field`` / ``score_field`` names.
        """
        if not self._annotate:
            return []
        return [self._lang_field, self._score_field]

    def setup(self) -> None:
        """Load FastText model once per worker. Downloads from S3 if needed."""
        import fasttext

        self._resolved_model_path = self._resolve_model_path(self._model_path)
        # Suppress FastText's stderr warnings about old model format
        fasttext.FastText.eprint = lambda *args, **kwargs: None
        self._model = fasttext.load_model(self._resolved_model_path)
        logger.info(
            "Loaded FastText model from %s (resolved: %s)",
            self._model_path, self._resolved_model_path,
        )

    def teardown(self) -> None:
        """Release model reference. Cached model file in /tmp/ is kept
        for reuse by other workers on the same node."""
        self._model = None

    @staticmethod
    def _resolve_model_path(model_path: str) -> str:
        """Download model from S3 to /tmp/ cache if needed, return local path.

        Uses a stable filename based on the S3 key so multiple workers
        on the same node share a single download. File locking prevents
        race conditions when multiple actors start simultaneously.

        Validates file size against the S3 source to detect corrupted or
        partial downloads. Corrupted cached files are automatically
        removed and re-downloaded.
        """
        if not model_path.startswith("s3://"):
            if not os.path.exists(model_path):
                raise FileNotFoundError(f"FastText model not found: {model_path}")
            return model_path

        import fcntl

        import fsspec

        filename = model_path.rstrip("/").rsplit("/", 1)[-1]
        local_path = os.path.join(tempfile.gettempdir(), f"fasttext_{filename}")
        lock_path = local_path + ".lock"

        fs, fs_path = fsspec.url_to_fs(model_path)
        remote_size = fs.size(fs_path)

        # Fast path: cached file exists and size matches remote
        if os.path.exists(local_path):
            local_size = os.path.getsize(local_path)
            if local_size == remote_size:
                logger.info(
                    "Using cached model: %s (%.1f MB, verified)",
                    local_path, local_size / 1e6,
                )
                return local_path
            # Size mismatch — corrupted or partial download
            logger.warning(
                "Cached model size mismatch: local=%.1f MB, remote=%.1f MB. "
                "Removing corrupted file: %s",
                local_size / 1e6, remote_size / 1e6, local_path,
            )
            try:
                os.remove(local_path)
            except OSError:
                pass  # Another worker may have already removed it

        # Acquire exclusive lock for download
        with open(lock_path, "w") as lock_file:
            fcntl.flock(lock_file, fcntl.LOCK_EX)
            try:
                # Double-check after acquiring lock (another actor may have finished)
                if os.path.exists(local_path):
                    local_size = os.path.getsize(local_path)
                    if local_size == remote_size:
                        logger.info(
                            "Using cached model (downloaded by another worker): %s",
                            local_path,
                        )
                        return local_path
                    # Still corrupted — remove and re-download
                    logger.warning("Removing corrupted cached model: %s", local_path)
                    try:
                        os.remove(local_path)
                    except OSError:
                        pass

                logger.info(
                    "Downloading FastText model: %s → %s (%.1f MB)",
                    model_path, local_path, remote_size / 1e6,
                )
                tmp_download = local_path + f".tmp.{os.getpid()}"
                try:
                    fs.get(fs_path, tmp_download)

                    # Validate downloaded size before making it available
                    downloaded_size = os.path.getsize(tmp_download)
                    if downloaded_size != remote_size:
                        raise RuntimeError(
                            f"Download size mismatch: got {downloaded_size} bytes, "
                            f"expected {remote_size} bytes from {model_path}"
                        )

                    os.rename(tmp_download, local_path)
                    logger.info(
                        "Download complete: %s (%.1f MB, verified)",
                        local_path, downloaded_size / 1e6,
                    )
                except Exception:
                    # Clean up partial download
                    for path in (tmp_download, local_path):
                        try:
                            if os.path.exists(path):
                                os.remove(path)
                        except OSError:
                            pass
                    raise
            finally:
                fcntl.flock(lock_file, fcntl.LOCK_UN)

        return local_path

    def process_df(self, df: pd.DataFrame) -> pd.DataFrame:
        """Detect language for each row using batch prediction.

        Uses FastText's batch predict API (list input) for throughput
        instead of per-row calls. Empty/null texts are handled separately
        to avoid sending empty strings to the model.

        Args:
            df: Input DataFrame with ``text_field`` column.

        Returns:
            In filter mode (``annotate=False``, the default): a DataFrame
            with the same schema as the input. Rows are dropped when
            ``languages``, ``min_score``, or the default
            ``keep_undetected=False`` behaviour would exclude them;
            otherwise every row is retained. The ``lang`` / ``lang_score``
            columns are computed internally for filtering decisions and
            never appear on the returned DataFrame.

            In annotate mode (``annotate=True``): a DataFrame with the
            ``lang_field`` and ``score_field`` columns added alongside
            the input columns. Row-filtering rules above still apply.

            In both modes the returned DataFrame is a fresh object, so
            mutating it does not affect the input.
        """
        import numpy as np

        if self._model is None:
            raise RuntimeError("Model not loaded. Call setup() first.")

        n = len(df)
        if n == 0:
            # Empty input — return unchanged unless annotation is
            # requested (in which case add empty typed columns so the
            # output schema matches the annotate=True contract).
            df = df.copy()
            if self._annotate:
                df[self._lang_field] = []
                df[self._score_field] = []
            return df

        # Vectorized preprocessing: fillna → strip → replace newlines
        texts = (
            df[self._text_field]
            .fillna("")
            .str.strip()
            .str.replace("\n", " ", regex=False)
        )

        # Split into non-empty (predictable) and empty (unknown) groups
        nonempty_mask = texts.str.len() > 0
        nonempty_texts = texts[nonempty_mask].tolist()

        # Pre-allocate result arrays
        langs = np.empty(n, dtype=object)
        scores = np.zeros(n, dtype=np.float32)

        # Mark empty texts as unknown
        langs[~nonempty_mask.values] = _UNKNOWN_LANG

        # Batch predict all non-empty texts at once
        if nonempty_texts:
            with _numpy_fasttext_compat():
                pred_labels, pred_scores = self._model.predict(nonempty_texts, k=1)
            nonempty_indices = nonempty_mask.values.nonzero()[0]

            # Extract lang codes and scores via list comprehension (faster
            # than per-element zip+enumerate for large batches)
            pred_langs = [lbl[0][_LABEL_PREFIX_LEN:] for lbl in pred_labels]
            pred_confs = [sc[0] for sc in pred_scores]

            langs[nonempty_indices] = pred_langs
            scores[nonempty_indices] = np.array(pred_confs, dtype=np.float32)

        # Build the row-keep mask from local arrays. In filter mode this
        # avoids writing and then dropping lang/lang_score on the DataFrame
        # entirely (two full-column allocations + a drop-column copy saved
        # on every batch). Annotate mode still attaches the columns below.
        keep: np.ndarray | None = None
        if self._min_score > 0.0 or self._languages or not self._keep_undetected:
            keep = np.ones(n, dtype=bool)

            if self._min_score > 0.0:
                keep &= scores >= self._min_score

            if self._languages is not None:
                # Small allowlist (the common case: 1-4 languages):
                # chained ``langs == code`` is vectorized in numpy's C
                # layer and avoids the per-element Python call that
                # ``np.frompyfunc(set.__contains__, 1, 1)`` incurs.
                # For larger allowlists, the set-contains approach wins.
                if len(self._languages) <= 4:
                    lang_match = np.zeros(n, dtype=bool)
                    for code in self._languages:
                        lang_match |= langs == code
                    keep &= lang_match
                else:
                    # np.isin doesn't work on object arrays with frozenset;
                    # fall back to a vectorized Python set lookup.
                    _in_set = np.frompyfunc(self._languages.__contains__, 1, 1)
                    keep &= _in_set(langs).astype(bool)

            if not self._keep_undetected:
                keep &= langs != _UNKNOWN_LANG

        # Skip the slice+reset_index copy when the mask kept every row.
        # Common hot path: well-curated input with no empty texts and
        # permissive filters — keep is all-True and the slice is pure waste.
        rows_dropped = keep is not None and not keep.all()

        if not self._annotate:
            # Filter-only mode: never touch the DataFrame's column set.
            # Apply the row mask (if any) to the original df and return.
            # Always materialize a fresh DataFrame so callers can mutate
            # the result without affecting their input.
            if rows_dropped:
                result = df[keep].reset_index(drop=True)
            else:
                result = df.copy()
        else:
            # Annotate mode: surface lang + lang_score as columns.
            result = df.copy()
            result[self._lang_field] = langs
            result[self._score_field] = scores
            if rows_dropped:
                result = result[keep].reset_index(drop=True)

        if logger.isEnabledFor(logging.DEBUG):
            from collections import Counter
            dist = Counter(langs)
            logger.debug(
                "LanguageDetection: %d → %d rows. Top langs: %s",
                n, len(result), dict(dist.most_common(5)),
            )

        return result
