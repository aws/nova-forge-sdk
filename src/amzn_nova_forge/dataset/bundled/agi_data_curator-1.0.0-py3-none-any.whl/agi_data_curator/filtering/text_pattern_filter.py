"""Filter conversations containing problematic regex patterns.

Adapted to the
CurationStage / pandas batch API.  Checks assistant turns (content and
reasoning_content blocks) for a configurable set of regex patterns that
indicate data quality issues: leaked special tokens, HTML entities,
knowledge-cutoff phrases, etc.

Two modes:

- **Filter mode** (default, ``annotate_only=False``): drops rows that match any
  pattern.
- **Annotate mode** (``annotate_only=True``): keeps all rows and adds a
  ``text_pattern_filter_error`` column with ``None`` for clean rows or one of:

  - ``"pattern_match"`` -- one or more patterns matched
  - ``"malformed_conversation"`` -- messages column could not be parsed

Usage via ForgeWorkflows::

    forge.execute("text_pattern_filter", messages_field="messages")

Usage standalone::

    stage = TextPatternFilter(annotate_only=True)
    df_out = stage.process_df(df_in)
"""

from __future__ import annotations

import logging
import re
from typing import TYPE_CHECKING

from agi_data_curator.filtering._conversation_utils import (
    ASSISTANT_ROLES,
    _ERR_MALFORMED,
    extract_text_from_content,
    parse_messages,
)
from agi_data_curator.pipeline.curation_stage import CurationStage

if TYPE_CHECKING:
    import pandas as pd

logger = logging.getLogger(__name__)

_ANNOTATE_COLUMN = "text_pattern_filter_error"
_ERR_PATTERN_MATCH = "pattern_match"

# Default compiled patterns
_DEFAULT_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r": \[DOC\]"),
    re.compile(r"\[EOS\]", re.IGNORECASE),
    re.compile(r"<EOS>", re.IGNORECASE),
    re.compile(r"\[PAD\]", re.IGNORECASE),
    re.compile(r"\[PAD\](?:\s*\[PAD\])+", re.IGNORECASE),
    re.compile(r"(?<![A-Za-z0-9])EOS(?![A-Za-z0-9])", re.IGNORECASE),
    re.compile(r"(?:(?<! )\[DOC\]|\[DOC\](?! ))", re.IGNORECASE),
    re.compile(r"\[DOC\].\[DOC\]", re.DOTALL),
    re.compile(r", \[DOC\]"),
    re.compile(r"however, this is incorrect", re.IGNORECASE),
    re.compile(r"&#\d{2,4};"),
    re.compile(r"\bBot: ?", re.IGNORECASE),
    re.compile(r"\b\w*(\w)\1{19,}\w*\b", re.IGNORECASE),
    re.compile(r"\b\w{101,}\b"),
    re.compile(
        r"\b(?:"
        r"knowledge cutoff|knowledge cut-off|knowledge cut off|"
        r"my training only goes up until|the time of my last update|"
        r"as of my knowledge as of|As of my last knowledge update in|"
        r"as of my latest update in|as of my most recent knowledge update in|"
        r"As per the update in|available information up to|"
        r"my knowledge cutoff date of|my knowledge expires in|"
        r"My knowledge is based on information available up until|"
        r"my last update in|my last update, which was in|"
        r"this information is based on events and developments up to"
        r")\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"<\|(?:begin_internal_thought|end_internal_thought|"
        r"begin_of_solution|end_of_solution|"
        r"nova_user|nova_assistant)\|>",
        re.IGNORECASE,
    ),
    re.compile(r"\btext-based (?:AI|language|llm|assist\w*|model\w*)\b", re.IGNORECASE),
]


def _validate(
    value: object,
    patterns: list[re.Pattern[str]],
) -> str | None:
    messages, err = parse_messages(value)
    if err is not None:
        return _ERR_MALFORMED

    for msg in messages:  # type: ignore[union-attr]
        if not isinstance(msg, dict):
            continue
        role = msg.get("role") or msg.get("from") or ""
        if isinstance(role, str) and role.lower() in ASSISTANT_ROLES:
            for field in ("content", "value", "reasoning_content"):
                raw = msg.get(field)
                if raw is None:
                    continue
                text = extract_text_from_content(raw)
                if not text:
                    continue
                for pattern in patterns:
                    if pattern.search(text):
                        return _ERR_PATTERN_MATCH
    return None


class TextPatternFilter(CurationStage):
    """Filter conversations containing problematic regex patterns.

    Only assistant turns are checked (roles in
    :data:`~agi_data_curator.filtering._conversation_utils.ASSISTANT_ROLES`).
    User messages are left untouched so that noisy prompts do not cause
    false positives.

    Args:
        messages_field: Column holding the conversation. Accepts a JSON
            string, an already-parsed list, or a ``{"messages": [...]}``
            / ``{"conversations": [...]}`` dict wrapper.
        additional_patterns: Extra regex pattern strings appended to the
            default set. Invalid patterns are silently skipped.
        annotate_only: If ``True``, keep all rows and add the
            ``text_pattern_filter_error`` column.  If ``False``
            (default), drop rows that fail.
    """

    def __init__(
        self,
        messages_field: str = "messages",
        additional_patterns: list[str] | None = None,
        annotate_only: bool = False,
    ) -> None:
        self._messages_field = messages_field
        self._annotate_only = annotate_only
        self._patterns = _DEFAULT_PATTERNS.copy()
        if additional_patterns:
            for pat_str in additional_patterns:
                try:
                    self._patterns.append(re.compile(pat_str))
                except re.error:
                    logger.warning("Skipping invalid regex pattern: %r", pat_str)

    def input_columns(self) -> list[str]:
        return [self._messages_field]

    def output_columns(self) -> list[str]:
        return [_ANNOTATE_COLUMN] if self._annotate_only else []

    def process_df(self, df: "pd.DataFrame") -> "pd.DataFrame":
        if len(df) == 0:
            result = df.copy()
            if self._annotate_only:
                result[_ANNOTATE_COLUMN] = []
            return result

        errors = [_validate(val, self._patterns) for val in df[self._messages_field]]

        if self._annotate_only:
            result = df.copy()
            result[_ANNOTATE_COLUMN] = errors
            return result

        keep = [e is None for e in errors]
        return df[keep].reset_index(drop=True)
