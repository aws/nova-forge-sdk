"""Incomplete conversation filter.

Drops rows whose last message is from the user — those are incomplete
conversations (the assistant has not yet responded) and tend to cause the
model to stop early during generation.  Adapted to the ``CurationStage`` / pandas batch API.

Supports both conversation formats; the format is detected automatically
from the payload shape:

- **ChatML** — ``messages`` list with ``role`` + ``content``. User role
  is ``"user"``.
- **LLaVA** — ``conversations`` list with ``from`` + ``value``. User role
  is ``"human"`` or ``"user"``.

The ``messages_field`` column may contain any of:

- a JSON-encoded string of a message list,
- an already-parsed list of message dicts,
- a dict wrapper of the form ``{"messages": [...]}`` or
  ``{"conversations": [...]}``.

Two modes:

- **Filter mode** (default, ``annotate_only=False``): drops rows that are
  incomplete.
- **Annotate mode** (``annotate_only=True``): keeps all rows and adds an
  ``incomplete_conversation_filter_error`` column. The value is ``None``
  for valid rows, or one of:

  - ``"empty_conversation"`` — no messages in the conversation.
  - ``"malformed_conversation"`` — payload could not be parsed as a
    conversation (invalid JSON, unsupported shape).
  - ``"incomplete_conversation_last_turn_user"`` — last message is from
    the user.

Usage via ForgeWorkflows::

    forge.execute("incomplete_conversation_filter",
                  messages_field="messages")

Usage standalone::

    stage = IncompleteConversationFilter(annotate_only=True)
    df_out = stage.process_df(df_in)
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from agi_data_curator.filtering._conversation_utils import (
    _ERR_MALFORMED,
    parse_messages as _parse_messages,
)
from agi_data_curator.pipeline.curation_stage import CurationStage

if TYPE_CHECKING:
    import pandas as pd

_ANNOTATE_COLUMN = "incomplete_conversation_filter_error"

_ERR_EMPTY = "empty_conversation"
_ERR_LAST_USER = "incomplete_conversation_last_turn_user"

# Roles that count as "user" across ChatML and LLaVA.
_USER_ROLES = frozenset({"user", "human"})


def _last_role(messages: list) -> str | None:
    """Return the lowercased role of the last message, or ``None`` if
    the last message has no recognisable role field."""
    last = messages[-1]
    if not isinstance(last, dict):
        return None
    # ChatML uses "role"; LLaVA uses "from".
    raw = last.get("role")
    if raw is None:
        raw = last.get("from")
    if isinstance(raw, str):
        return raw.lower()
    return None


def _validate(value) -> str | None:
    """Return an error code if the conversation is incomplete, or
    ``None`` if it passes."""
    messages, err = _parse_messages(value)
    if err is not None:
        return err
    # Unreachable when err is None, but keep the type narrowing explicit.
    assert messages is not None
    if len(messages) == 0:
        return _ERR_EMPTY
    if _last_role(messages) in _USER_ROLES:
        return _ERR_LAST_USER
    return None


class IncompleteConversationFilter(CurationStage):
    """Drop rows whose last message is from the user.

    Args:
        messages_field: Column holding the conversation. See the module
            docstring for the accepted payload shapes.
        annotate_only: If ``True``, keep all rows and add the
            ``incomplete_conversation_filter_error`` column. If ``False``
            (default), drop rows that fail validation.
    """

    def __init__(
        self,
        messages_field: str = "messages",
        annotate_only: bool = False,
    ) -> None:
        self._messages_field = messages_field
        self._annotate_only = annotate_only

    def input_columns(self) -> list[str]:
        return [self._messages_field]

    def output_columns(self) -> list[str]:
        return [_ANNOTATE_COLUMN] if self._annotate_only else []

    def process_df(self, df: "pd.DataFrame") -> "pd.DataFrame":
        if len(df) == 0:
            result = df.copy()
            if self._annotate_only:
                result[_ANNOTATE_COLUMN] = []
            return result

        errors = [_validate(val) for val in df[self._messages_field]]

        if self._annotate_only:
            result = df.copy()
            result[_ANNOTATE_COLUMN] = errors
            return result

        keep = [e is None for e in errors]
        return df[keep].reset_index(drop=True)
