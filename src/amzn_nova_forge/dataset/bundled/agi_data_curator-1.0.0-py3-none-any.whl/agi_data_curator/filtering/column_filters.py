"""Column-based filters using pre-computed dataset columns.

Generic filters that operate on columns already present in the dataset
(token_count, is_truncated, duplicate_count) — no model inference needed.
Reusable across any dataset that has these columns.
"""

from __future__ import annotations

import logging

from nemo_curator.stages.base import ProcessingStage
from nemo_curator.tasks import DocumentBatch

logger = logging.getLogger(__name__)


class TokenCountFilter(ProcessingStage):
    """Filter documents by pre-computed token_count column.

    Drops documents outside [min_tokens, max_tokens] range.
    Uses the existing ``token_count`` column — no re-tokenization.

    Args:
        min_tokens: Minimum token count (inclusive). Default 128.
        max_tokens: Maximum token count (inclusive). Default 100000.
        token_count_field: Column name. Default ``"token_count"``.
    """

    name = "token_count_filter"

    def __init__(
        self,
        min_tokens: int = 128,
        max_tokens: int = 100000,
        token_count_field: str = "token_count",
    ):
        self.min_tokens = min_tokens
        self.max_tokens = max_tokens
        self.token_count_field = token_count_field

    def inputs(self) -> tuple[list[str], list[str]]:
        return ["data"], [self.token_count_field]

    def outputs(self) -> tuple[list[str], list[str]]:
        return ["data"], []

    def process(self, batch: DocumentBatch) -> DocumentBatch:
        df = batch.to_pandas()
        mask = (
            (df[self.token_count_field] >= self.min_tokens)
            & (df[self.token_count_field] <= self.max_tokens)
        )
        df_filtered = df[mask].reset_index(drop=True)
        logger.debug(
            "TokenCountFilter: kept %d/%d rows (tokens %d-%d)",
            len(df_filtered), len(df), self.min_tokens, self.max_tokens,
        )
        del df
        return DocumentBatch(
            task_id=batch.task_id,
            dataset_name=batch.dataset_name,
            data=df_filtered,
        )


class TruncationFilter(ProcessingStage):
    """Drop truncated documents (incomplete PDFs from CommonCrawl).

    Truncated PDFs often contain garbage or incomplete content.
    Uses the ``is_truncated`` boolean column.

    Args:
        keep_truncated: If True, keeps truncated docs instead. Default False.
    """

    name = "truncation_filter"

    def __init__(self, keep_truncated: bool = False):
        self.keep_truncated = keep_truncated

    def inputs(self) -> tuple[list[str], list[str]]:
        return ["data"], ["is_truncated"]

    def outputs(self) -> tuple[list[str], list[str]]:
        return ["data"], []

    def process(self, batch: DocumentBatch) -> DocumentBatch:
        df = batch.to_pandas()
        is_trunc = df["is_truncated"].fillna(False).astype(bool)
        if self.keep_truncated:
            df_filtered = df[is_trunc].reset_index(drop=True)
        else:
            df_filtered = df[~is_trunc].reset_index(drop=True)
        logger.debug(
            "TruncationFilter: kept %d/%d rows (keep_truncated=%s)",
            len(df_filtered), len(df), self.keep_truncated,
        )
        del df
        return DocumentBatch(
            task_id=batch.task_id,
            dataset_name=batch.dataset_name,
            data=df_filtered,
        )


class DuplicateCountFilter(ProcessingStage):
    """Drop documents with high duplicate counts.

    FinePDFs includes ``duplicate_count`` from MinHash dedup.
    Documents with many duplicates are likely boilerplate/templates.

    Args:
        max_duplicates: Maximum allowed duplicate count. Default 10.
    """

    name = "duplicate_count_filter"

    def __init__(self, max_duplicates: int = 10):
        self.max_duplicates = max_duplicates

    def inputs(self) -> tuple[list[str], list[str]]:
        return ["data"], ["duplicate_count"]

    def outputs(self) -> tuple[list[str], list[str]]:
        return ["data"], []

    def process(self, batch: DocumentBatch) -> DocumentBatch:
        df = batch.to_pandas()
        df_filtered = df[df["duplicate_count"] <= self.max_duplicates].reset_index(drop=True)
        logger.debug(
            "DuplicateCountFilter: kept %d/%d rows (max_duplicates=%d)",
            len(df_filtered), len(df), self.max_duplicates,
        )
        del df
        return DocumentBatch(
            task_id=batch.task_id,
            dataset_name=batch.dataset_name,
            data=df_filtered,
        )
