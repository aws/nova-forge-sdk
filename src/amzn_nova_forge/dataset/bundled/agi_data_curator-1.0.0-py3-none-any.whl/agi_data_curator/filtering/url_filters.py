"""URL-based filter for text data curation.

Pure Ray CurationStage implementation inspired by NemoCurator's
UrlsFilter and PornographicUrlsFilter. No NemoCurator dependency.

Combines both checks into a single pass over the text:
- Discards documents where URLs comprise more than a configurable
  fraction of the total text.
- Optionally discards documents containing pornographic URLs.
"""

from __future__ import annotations

import logging
import re

import pandas as pd

from agi_data_curator.pipeline.curation_stage import CurationStage

logger = logging.getLogger(__name__)

# URL regex from NemoCurator's constants — matches http/https URLs
_REGEX_URL = re.compile(
    r"https?://(?:[a-zA-Z]|[0-9]|[$\-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+"
)


class UrlsFilter(CurationStage):
    """Filter documents based on URL content.

    Two checks in a single pass over each document's URLs:

    1. URL ratio: computes ``url_chars / total_chars``. Documents
       exceeding ``max_url_to_text_ratio`` are dropped. Empty documents
       are always dropped (ratio treated as 1.0).

    2. Pornographic URLs (opt-in via ``filter_porn_urls=True``): scans
       all URLs for the substring ``"porn"``. If any URL matches, the
       document is discarded.

    Based on NemoCurator's ``UrlsFilter`` and ``PornographicUrlsFilter``.

    Args:
        text_field: Column containing the document text.
        max_url_to_text_ratio: Maximum allowed ratio of URL characters
            to total characters. Default 0.2 (20%).
        filter_porn_urls: If True, also discard documents containing
            URLs with ``"porn"`` in them. Default True.
    """

    def __init__(
        self,
        text_field: str = "text",
        max_url_to_text_ratio: float = 0.2,
        filter_porn_urls: bool = True,
    ):
        self.text_field = text_field
        self.max_url_to_text_ratio = max_url_to_text_ratio
        self.filter_porn_urls = filter_porn_urls

    def input_columns(self) -> list[str]:
        return [self.text_field]

    def output_columns(self) -> list[str]:
        return []

    def process_df(self, df: pd.DataFrame) -> pd.DataFrame:
        if df.empty:
            return df

        def _should_keep(text: str) -> bool:
            if not text:
                return False  # empty → ratio 1.0 → drop
            urls = _REGEX_URL.findall(text)
            url_chars = sum(len(u) for u in urls)
            if url_chars / len(text) > self.max_url_to_text_ratio:
                return False
            if self.filter_porn_urls and any("porn" in u for u in urls):
                return False
            return True

        mask = df[self.text_field].fillna("").apply(_should_keep)
        n_dropped = (~mask).sum()
        if n_dropped:
            logger.debug(
                "UrlsFilter: dropped %d/%d rows", n_dropped, len(df),
            )
        return df[mask].reset_index(drop=True)
