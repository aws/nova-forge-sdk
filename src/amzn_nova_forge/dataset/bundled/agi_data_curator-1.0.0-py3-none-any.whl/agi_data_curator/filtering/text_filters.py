"""Text-based heuristic filters for data curation.

Pure Ray CurationStage implementations inspired by NemoCurator and
DataJuicer filters. No NemoCurator dependency.

Filters:
- AlphanumericFilter: discards documents with too few alphanumeric characters.
- WordRepetitionFilter: discards documents with excessive repeated word n-grams.
- CharRepetitionFilter: discards documents with excessive repeated character n-grams.
- MojibakeFilter: discards documents with encoding corruption (mojibake).
- CharacterLengthFilter: discards documents outside a character count range.
- AverageLineLengthFilter: discards documents with abnormal average line lengths.
"""

from __future__ import annotations

import logging
import math
import re
from collections import Counter
from collections.abc import Callable

import pandas as pd

from agi_data_curator.pipeline.curation_stage import CurationStage

logger = logging.getLogger(__name__)

# ── Mojibake detection patterns (compiled once at module level) ───────
# 2-byte UTF-8 misread as Latin-1: e.g. é (C3 A9) → Ã© (C3=Ã, A9=©)
_MOJIBAKE_2BYTE = re.compile(r"[\xc0-\xdf][\x80-\xbf]")
# 3-byte UTF-8 misread as Latin-1: e.g. CJK chars produce 3-byte sequences
_MOJIBAKE_3BYTE = re.compile(r"[\xe0-\xef][\x80-\xbf][\x80-\xbf]")
_REPLACEMENT_CHAR = "\ufffd"


class AlphanumericFilter(CurationStage):
    """Filter documents by alphanumeric character ratio.

    Computes the ratio of alphanumeric characters to total characters,
    following the DataJuicer approach.  Documents whose ratio falls outside
    ``[min_alnum_ratio, max_alnum_ratio]`` are dropped.

    Args:
        text_field: Column containing the document text.
        min_alnum_ratio: Minimum allowed ratio of alphanumeric characters
            to total characters. Default 0.25.
        max_alnum_ratio: Maximum allowed ratio. Default ``float('inf')``
            (no upper bound).
    """

    def __init__(
        self,
        text_field: str = "text",
        min_alnum_ratio: float = 0.25,
        max_alnum_ratio: float = float("inf"),
    ):
        self.text_field = text_field
        self.min_alnum_ratio = min_alnum_ratio
        self.max_alnum_ratio = max_alnum_ratio

    def input_columns(self) -> list[str]:
        return [self.text_field]

    def output_columns(self) -> list[str]:
        return []

    def process_df(self, df: pd.DataFrame) -> pd.DataFrame:
        if df.empty:
            return df

        def _should_keep(text: str) -> bool:
            if not text:
                return self.min_alnum_ratio <= 0.0
            alnum_count = sum(1 for c in text if c.isalnum())
            ratio = alnum_count / len(text)
            return self.min_alnum_ratio <= ratio <= self.max_alnum_ratio

        mask = df[self.text_field].fillna("").apply(_should_keep)
        n_dropped = (~mask).sum()
        if n_dropped:
            logger.debug(
                "AlphanumericFilter: dropped %d/%d rows", n_dropped, len(df),
            )
        return df[mask].reset_index(drop=True)


class WordRepetitionFilter(CurationStage):
    """Filter documents with excessive repeated word n-grams.

    Computes the fraction of n-gram occurrences that are repeated (appear more
    than once). Words are lowercased and leading/trailing punctuation is
    stripped before n-gram construction, following the DataJuicer approach.

    Documents whose repetition ratio falls outside
    ``[min_word_repetition_ratio, max_word_repetition_ratio]`` are dropped.

    Args:
        text_field: Column containing the document text.
        max_word_repetition_ratio: Maximum allowed ratio. Default 0.5.
        min_word_repetition_ratio: Minimum allowed ratio. Default 0.0.
        n: Size of word n-grams. Default 10.
    """

    _STRIP_CHARS_RE = re.compile(r"^[^\w\s]+|[^\w\s]+$")

    def __init__(
        self,
        text_field: str = "text",
        max_word_repetition_ratio: float = 0.5,
        min_word_repetition_ratio: float = 0.0,
        n: int = 10,
    ):
        self.text_field = text_field
        self.max_word_repetition_ratio = max_word_repetition_ratio
        self.min_word_repetition_ratio = min_word_repetition_ratio
        self.n = n

    def input_columns(self) -> list[str]:
        return [self.text_field]

    def output_columns(self) -> list[str]:
        return []

    @staticmethod
    def _refine_words(words: list[str]) -> list[str]:
        """Lowercase and strip leading/trailing punctuation from words."""
        refined = []
        for w in words:
            w = w.lower()
            w = WordRepetitionFilter._STRIP_CHARS_RE.sub("", w)
            if w:
                refined.append(w)
        return refined

    def process_df(self, df: pd.DataFrame) -> pd.DataFrame:
        if df.empty:
            return df

        def _should_keep(text: str) -> bool:
            if not text:
                return self.min_word_repetition_ratio <= 0.0
            words = self._refine_words(text.split())
            if len(words) < self.n:
                return self.min_word_repetition_ratio <= 0.0
            ngrams = [
                " ".join(words[i : i + self.n])
                for i in range(len(words) - self.n + 1)
            ]
            freq = Counter(ngrams)
            total = sum(freq.values())
            if total == 0:
                return self.min_word_repetition_ratio <= 0.0
            repeated = sum(count for count in freq.values() if count > 1)
            ratio = repeated / total
            return self.min_word_repetition_ratio <= ratio <= self.max_word_repetition_ratio

        mask = df[self.text_field].fillna("").apply(_should_keep)
        n_dropped = (~mask).sum()
        if n_dropped:
            logger.debug(
                "WordRepetitionFilter: dropped %d/%d rows", n_dropped, len(df),
            )
        return df[mask].reset_index(drop=True)


class CharRepetitionFilter(CurationStage):
    """Filter documents with excessive repeated character n-grams.

    Computes a character-level n-gram repetition ratio following the DataJuicer
    approach: frequencies are sorted descending and only the top
    ``min(sqrt(unique_ngrams), num_repeated)`` most-frequent n-grams contribute
    to the ratio.  This focuses on dominant repetition patterns rather than
    counting every low-frequency repeat.

    Documents whose ratio falls outside
    ``[min_char_repetition_ratio, max_char_repetition_ratio]`` are dropped.

    Args:
        text_field: Column containing the document text.
        max_char_repetition_ratio: Maximum allowed ratio. Default 0.5.
        min_char_repetition_ratio: Minimum allowed ratio. Default 0.0.
        n: Size of character n-grams. Default 10.
    """

    def __init__(
        self,
        text_field: str = "text",
        max_char_repetition_ratio: float = 0.5,
        min_char_repetition_ratio: float = 0.0,
        n: int = 10,
    ):
        self.text_field = text_field
        self.max_char_repetition_ratio = max_char_repetition_ratio
        self.min_char_repetition_ratio = min_char_repetition_ratio
        self.n = n

    def input_columns(self) -> list[str]:
        return [self.text_field]

    def output_columns(self) -> list[str]:
        return []

    def process_df(self, df: pd.DataFrame) -> pd.DataFrame:
        if df.empty:
            return df

        def _should_keep(text: str) -> bool:
            if not text or len(text) < self.n:
                return self.min_char_repetition_ratio <= 0.0
            ngrams = [text[i : i + self.n] for i in range(len(text) - self.n + 1)]
            freq = Counter(ngrams)
            sorted_freqs = sorted(freq.values(), reverse=True)
            num_unique = len(sorted_freqs)
            num_no_rep = sorted_freqs.count(1)
            num_rep = min(
                int(math.sqrt(num_unique)),
                num_unique - num_no_rep,
            )
            total = sum(sorted_freqs)
            if total == 0:
                return self.min_char_repetition_ratio <= 0.0
            ratio = sum(sorted_freqs[:num_rep]) / total
            return self.min_char_repetition_ratio <= ratio <= self.max_char_repetition_ratio

        mask = df[self.text_field].fillna("").apply(_should_keep)
        n_dropped = (~mask).sum()
        if n_dropped:
            logger.debug(
                "CharRepetitionFilter: dropped %d/%d rows", n_dropped, len(df),
            )
        return df[mask].reset_index(drop=True)


class MojibakeFilter(CurationStage):
    """Filter documents containing mojibake (encoding corruption).

    Two detection paths:

    1. **ftfy** (preferred): uses ``ftfy.badness()`` which returns an integer
       score counting problematic sequences. Normalized to per-character
       ratio: ``badness(text) / len(text)``. Documents exceeding
       ``max_badness`` are dropped.

    2. **Regex fallback** (when ftfy not installed): counts U+FFFD replacement
       characters and common Latin-1-misread-as-UTF-8 byte patterns (2-byte
       and 3-byte). Documents exceeding ``max_mojibake_ratio`` are dropped.

    The ftfy availability check runs once in ``setup()``, not per batch.

    Args:
        text_field: Column containing the document text.
        max_badness: Maximum per-character ftfy badness score (ftfy path).
            Default 1.
        max_mojibake_ratio: Maximum ratio of mojibake chars to total
            (regex fallback path). Default 0.05.
    """

    def __init__(
        self,
        text_field: str = "text",
        max_badness: int = 1,
        max_mojibake_ratio: float = 0.05,
    ):
        self.text_field = text_field
        self.max_badness = max_badness
        self.max_mojibake_ratio = max_mojibake_ratio
        self._use_ftfy = False
        self._badness_fn: Callable[[str], int] | None = None

    def setup(self) -> None:
        """Check ftfy availability once per worker."""
        try:
            from ftfy.badness import badness

            self._badness_fn = badness
            self._use_ftfy = True
            logger.info("MojibakeFilter: using ftfy + regex backend")
        except ImportError:
            self._use_ftfy = False
            logger.info("MojibakeFilter: using regex-only backend")

    def input_columns(self) -> list[str]:
        return [self.text_field]

    def output_columns(self) -> list[str]:
        return []

    def process_df(self, df: pd.DataFrame) -> pd.DataFrame:
        if df.empty:
            return df

        texts = df[self.text_field].fillna("")
        lengths = texts.str.len().clip(lower=1)

        # Regex check always runs — catches U+FFFD and byte-pattern mojibake
        fffd_counts = texts.str.count(_REPLACEMENT_CHAR)
        two_byte = texts.str.count(_MOJIBAKE_2BYTE)
        three_byte = texts.str.count(_MOJIBAKE_3BYTE)
        mojibake_chars = fffd_counts + (two_byte * 2) + (three_byte * 3)
        regex_ratios = mojibake_chars / lengths
        mask = regex_ratios <= self.max_mojibake_ratio

        # ftfy check adds sequence-aware detection on top of regex
        if self._use_ftfy:
            badness_fn = self._badness_fn
            badness_scores = texts.apply(badness_fn) / lengths
            mask = mask & (badness_scores <= self.max_badness)

        n_dropped = (~mask).sum()
        if n_dropped:
            logger.debug("MojibakeFilter: dropped %d/%d rows", n_dropped, len(df))
        return df[mask.values].reset_index(drop=True)


class CharacterLengthFilter(CurationStage):
    """Filter documents by total character count.

    Documents shorter than ``min_length`` or longer than ``max_length``
    are dropped. Set ``max_length=None`` to disable the upper bound.

    Uses vectorized ``str.len()`` for throughput.

    Args:
        text_field: Column containing the document text.
        min_length: Minimum character count. Default 50.
        max_length: Maximum character count, or None for no upper bound.
            Default None.
    """

    def __init__(
        self,
        text_field: str = "text",
        min_length: int = 50,
        max_length: int | None = None,
    ):
        self.text_field = text_field
        self.min_length = min_length
        self.max_length = max_length

    def input_columns(self) -> list[str]:
        return [self.text_field]

    def output_columns(self) -> list[str]:
        return []

    def process_df(self, df: pd.DataFrame) -> pd.DataFrame:
        if df.empty:
            return df

        lengths = df[self.text_field].fillna("").str.len()
        mask = lengths >= self.min_length
        if self.max_length is not None:
            mask = mask & (lengths <= self.max_length)

        n_dropped = (~mask).sum()
        if n_dropped:
            logger.debug(
                "CharacterLengthFilter: dropped %d/%d rows", n_dropped, len(df),
            )
        return df[mask.values].reset_index(drop=True)


class AverageLineLengthFilter(CurationStage):
    """Filter documents with abnormal average line lengths.

    Documents with very short average lines (e.g. word-per-line dumps) or
    very long average lines (e.g. minified code, single-line dumps) are
    likely noise.

    Documents with fewer than ``min_lines`` non-empty lines are always
    kept (too short to judge reliably).

    Args:
        text_field: Column containing the document text.
        min_avg_line_length: Minimum average chars per non-empty line.
            Default 10.
        max_avg_line_length: Maximum average chars per non-empty line,
            or None for no upper bound. Default None.
        min_lines: Minimum number of non-empty lines required to apply
            the filter. Documents below this are always kept. Default 2.
    """

    def __init__(
        self,
        text_field: str = "text",
        min_avg_line_length: int = 10,
        max_avg_line_length: int | None = None,
        min_lines: int = 2,
    ):
        self.text_field = text_field
        self.min_avg_line_length = min_avg_line_length
        self.max_avg_line_length = max_avg_line_length
        self.min_lines = min_lines

    def input_columns(self) -> list[str]:
        return [self.text_field]

    def output_columns(self) -> list[str]:
        return []

    def process_df(self, df: pd.DataFrame) -> pd.DataFrame:
        if df.empty:
            return df

        texts = df[self.text_field].fillna("")

        def _should_keep(text: str) -> bool:
            if not text:
                return False
            lines = [ln for ln in text.split("\n") if ln]
            n_lines = len(lines)
            if n_lines == 0:
                return False
            avg = sum(len(ln) for ln in lines) / n_lines
            # max_avg_line_length always applies (catches single-line dumps)
            if self.max_avg_line_length is not None and avg > self.max_avg_line_length:
                return False
            # min_avg_line_length only applies when doc has enough lines to judge
            if n_lines >= self.min_lines and avg < self.min_avg_line_length:
                return False
            return True

        mask = texts.apply(_should_keep)
        n_dropped = (~mask).sum()
        if n_dropped:
            logger.debug(
                "AverageLineLengthFilter: dropped %d/%d rows", n_dropped, len(df),
            )
        return df[mask.values].reset_index(drop=True)
