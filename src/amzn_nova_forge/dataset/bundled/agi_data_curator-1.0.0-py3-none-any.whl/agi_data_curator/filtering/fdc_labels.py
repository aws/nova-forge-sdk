"""Dewey Decimal Classification (DDC) label maps for FDC codes.

Provides 3 levels of human-readable labels for FDC (Fine-grained Dewey
Classification) codes returned by the EssentialAI/eai-distill-0.5b model:

- Level 1 (hundreds digit): 10 top-level classes (e.g. "Science")
- Level 2 (tens digit): 100 divisions (e.g. "Chemistry")
- Level 3 (full code): 1000 sections (e.g. "Organic chemistry")

Labels are loaded from ``fdc_labels.yaml`` (co-located with this module).
Source: Dewey Decimal Classification summary tables (public domain structure).
Content rephrased for compliance with licensing restrictions.
"""

from __future__ import annotations

import os
from functools import lru_cache
from typing import Any

import yaml


def _load_yaml() -> dict[str, Any]:
    """Load the FDC labels YAML file once and cache the result."""
    yaml_path = os.path.join(os.path.dirname(__file__), "fdc_labels.yaml")
    with open(yaml_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


@lru_cache(maxsize=1)
def _get_levels() -> tuple[dict[int, str], dict[int, str], dict[int, str]]:
    """Return (level_1, level_2, level_3) dicts with int keys, cached."""
    raw = _load_yaml()
    level_1 = {int(k): v for k, v in raw["level_1"].items()}
    level_2 = {int(k): v for k, v in raw["level_2"].items()}
    level_3 = {int(k): v for k, v in raw["level_3"].items()}
    return level_1, level_2, level_3


# Module-level references for backward compatibility and direct access
_FDC_LEVEL_1, _FDC_LEVEL_2, _FDC_LEVEL_3 = _get_levels()


def fdc_code_to_labels(code_str: str) -> dict[str, str]:
    """Convert an FDC code string to 3-level human-readable labels.

    Args:
        code_str: Raw FDC code, e.g. ``'547.0'``, ``'320'``, ``'4'``.

    Returns:
        Dict with keys ``topic`` (level 1), ``topic_level_2`` (level 2),
        and ``topic_level_3`` (level 3).  Values default to ``'Unknown'``
        when the code cannot be parsed.

    Examples:
        >>> fdc_code_to_labels("547.0")
        {'topic': 'Science', 'topic_level_2': 'Chemistry', 'topic_level_3': 'Organic Chemistry'}
        >>> fdc_code_to_labels("320.0")
        {'topic': 'Social Sciences', 'topic_level_2': 'Political Science', 'topic_level_3': 'Political Science'}
    """
    unknown = {"topic": "Unknown", "topic_level_2": "Unknown", "topic_level_3": "Unknown"}
    try:
        code = int(float(code_str))
    except (ValueError, TypeError):
        return unknown

    if code < 0 or code > 999:
        return unknown

    hundreds = code // 100          # 0-9  → level 1
    tens = code // 10               # 0-99 → level 2

    level_1 = _FDC_LEVEL_1.get(hundreds, "Unknown")
    level_2 = _FDC_LEVEL_2.get(tens, "Unknown")
    level_3 = _FDC_LEVEL_3.get(code, level_2)  # fallback to level 2

    return {
        "topic": level_1,
        "topic_level_2": level_2,
        "topic_level_3": level_3,
    }
