"""Skeleton extraction for near-duplicate detection.

Normalizes text by replacing URLs, emails, numbers, dates, proper nouns, etc.
with placeholders, then lowercases and strips punctuation to produce a
"skeleton" string. A SHA-256 hash of the skeleton enables fast grouping of
near-exact duplicates.

Adds columns: ``skeleton``, ``skeleton_hash``.
"""

from __future__ import annotations

import hashlib
import logging
import re
import string

import pandas as pd

from agi_data_curator.pipeline.curation_stage import CurationStage

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────
# Constants
# ─────────────────────────────────────────────────────────────

_OTHER_SPECIAL = (
    "      \ufffc'\u201c\u201d\u2013\u30fc\u4e00\u25ac\u2026\u2726\ufffd\u00ad"
    "\u00a3\u2022\u20ac\u00ab\u00bb\u00b0\u00b7\u2550\u00d7\u00a7\u2033\u2032"
    "\u00b4\u00bf\u2212\u00b1\u2208\ufeff\u00a2\u00f8\u201a\u201e\u00bd\u00bc"
    "\u00be\u00b9\u00b2\u00b3\u2015\u2043\u00a6\u2010\u2800\u2030\u2264\u2265"
)

try:
    import emoji
    _EMOJI_CHARS = set(emoji.EMOJI_DATA.keys())
except Exception:
    _EMOJI_CHARS = set()

SPECIAL_CHARS: set[str] = set(
    string.punctuation + string.digits + string.whitespace + _OTHER_SPECIAL
) | _EMOJI_CHARS

CLOSED_CLASS: set[str] = {
    'i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you',
    'your', 'yours', 'yourself', 'he', 'him', 'his', 'himself', 'she', 'her',
    'hers', 'herself', 'it', 'its', 'itself', 'they', 'them', 'their',
    'theirs', 'themselves', 'who', 'whom', 'whose', 'which', 'what', 'that',
    'is', 'am', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has',
    'had', 'do', 'does', 'did', 'will', 'would', 'shall', 'should', 'may',
    'might', 'must', 'can', 'could', 'need', 'dare', 'ought', 'the', 'a',
    'an', 'this', 'these', 'those', 'some', 'any', 'all', 'both', 'each',
    'every', 'either', 'neither', 'no', 'much', 'many', 'more', 'most',
    'few', 'little', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by',
    'from', 'as', 'into', 'through', 'during', 'before', 'after', 'above',
    'below', 'between', 'among', 'about', 'against', 'along', 'around',
    'behind', 'beside', 'beyond', 'despite', 'except', 'inside', 'near',
    'outside', 'since', 'than', 'toward', 'under', 'until', 'upon', 'within',
    'without', 'and', 'but', 'or', 'nor', 'so', 'yet', 'although', 'because',
    'if', 'unless', 'while', 'whereas', 'though', 'when', 'there', 'here',
    'however', 'therefore', 'thus', 'also', 'just', 'only', 'even', 'still',
    'already', 'always', 'never', 'not', 'now', 'then',
}

SENTENCE_START_COMMON: set[str] = {
    'Today', 'Tomorrow', 'Yesterday', 'Welcome', 'Introduction', 'Summary',
    'Conclusion', 'Chapter', 'Section', 'Best', 'Top', 'Why', 'How', 'What',
    'When', 'Where',
}

# ─────────────────────────────────────────────────────────────
# Compiled patterns
# ─────────────────────────────────────────────────────────────

_NORMALIZE: list[tuple[re.Pattern, str]] = [
    (re.compile(r'[\r\n\t\u00a0\u200b\u200c\u200d\ufeff]+'), ' '),
    (re.compile(r' {2,}'), ' '),
    (re.compile(r'\[?https?://\S+\]?(?:\([^)]+\))?'), '<URL>'),
    (re.compile(r'[\w.+-]+@[\w-]+\.[a-zA-Z]{2,}'), '<EMAIL>'),
    (re.compile(r'\b\d{4}-\d{2}-\d{2}\b'), '<DATE>'),
    (re.compile(r'\b\d{1,2}[/.-]\d{1,2}[/.-]\d{2,4}\b'), '<DATE>'),
    (re.compile(r'\b\d{1,2}:\d{2}(?::\d{2})?\s*(?:am|pm)?\b', re.I), '<TIME>'),
    (re.compile(r'[$\u00a3\u20ac\u00a5]\s*\d[\d,. ]*(?:k|m|bn?)?\b', re.I), '<MONEY>'),
    (re.compile(r'\b\d[\d,.]*\s*(?:usd|eur|gbp|jpy)\b', re.I), '<MONEY>'),
    (re.compile(r'\b\d+(?:\.\d+)?\s*%'), '<PCT>'),
    (re.compile(r'\b\d+(?:\.\d+)?\s*(?:mg|ml|g|kg|lb|oz|cm|mm|km|m|ft|in)\b', re.I), '<MEASURE>'),
    (re.compile(r'\bv?\d+(?:\.\d+){1,3}\b'), '<VERSION>'),
    (re.compile(r'\b\d[\d,]*(?:\.\d+)?\b'), '<NUM>'),
]

_PROPN_RE = re.compile(r'\b(?:[A-Z][a-z]+|[A-Z]{2,})(?:\s+(?:[A-Z][a-z]+|[A-Z]{2,}))*\b')
_PUNCT_CLEANUP = re.compile(r"[^\w\s<>'-]+")
_MULTI_SPACE = re.compile(r'\s+')

# ─────────────────────────────────────────────────────────────
# Core logic (pure functions, no framework dependency)
# ─────────────────────────────────────────────────────────────

_EMPTY_HASH = hashlib.sha256(b'').hexdigest()


def extract_skeleton(text: str) -> tuple[str, str]:
    """Return ``(skeleton, sha256_hash)`` for the given text.

    The skeleton is a normalised form of the input where named entities,
    numbers, URLs, emails, dates, etc. are replaced with typed placeholders,
    punctuation is stripped, and the result is lowercased.  The hash is the
    SHA-256 hex digest of the skeleton string.
    """
    if not text:
        return ('', _EMPTY_HASH)

    t = text
    for pat, repl in _NORMALIZE:
        t = pat.sub(repl, t)
    t = t.strip()

    def _replace_entity(m: re.Match) -> str:
        phrase = m.group(0)
        if phrase.lower() in CLOSED_CLASS:
            return phrase
        if phrase in SENTENCE_START_COMMON:
            return phrase
        return '<ENTITY>'

    t = _PROPN_RE.sub(_replace_entity, t)
    t = _PUNCT_CLEANUP.sub(' ', t)
    t = t.lower()
    t = _MULTI_SPACE.sub(' ', t).strip()
    h = hashlib.sha256(t.encode('utf-8')).hexdigest()
    return (t, h)


# ─────────────────────────────────────────────────────────────
# ProcessingStage
# ─────────────────────────────────────────────────────────────

class TextSkeletonHasher(CurationStage):
    """Extract text skeletons and hashes for near-duplicate detection.

    Normalises text by replacing URLs, emails, numbers, dates, monetary
    amounts, proper nouns, and other named entities with typed placeholders,
    then lowercases and strips punctuation to produce a canonical "skeleton".
    A SHA-256 hash of the skeleton enables fast grouping of near-exact duplicates.

    Adds columns: ``skeleton``, ``skeleton_hash``.

    Args:
        text_field: Source text column. Default ``"text"``.
        skeleton_field: Output column for the skeleton string. Default ``"skeleton"``.
        hash_field: Output column for the SHA-256 hash. Default ``"skeleton_hash"``.
    """

    def __init__(
        self,
        text_field: str = "text",
        skeleton_field: str = "skeleton",
        hash_field: str = "skeleton_hash",
    ):
        self.text_field = text_field
        self.skeleton_field = skeleton_field
        self.hash_field = hash_field

    def input_columns(self) -> list[str]:
        return [self.text_field]

    def output_columns(self) -> list[str]:
        return [self.skeleton_field, self.hash_field]

    def process_df(self, df: pd.DataFrame) -> pd.DataFrame:
        skeletons = []
        hashes = []
        for text in df[self.text_field]:
            if text is None or not isinstance(text, str):
                skeletons.append('')
                hashes.append(_EMPTY_HASH)
            else:
                skel, h = extract_skeleton(text)
                skeletons.append(skel)
                hashes.append(h)

        df = df.copy()
        df[self.skeleton_field] = skeletons
        df[self.hash_field] = hashes
        return df
