"""Turn separator in text filter.

Drops rows where turn separator or end-of-sequence tokens have leaked
into message content.  Training data sometimes contains literal turn
separator tokens (e.g. ``[EOS]``, ``<|endoftext|>``) inside the actual
text content; these can confuse the model during training.  Adapted to the
``CurationStage`` / pandas batch API.

Supports both conversation formats; the format is detected automatically
from the payload shape:

- **ChatML** — ``messages`` list with ``role`` + ``content``.
- **LLaVA** — ``conversations`` list with ``from`` + ``value``.

The ``messages_field`` column may contain any of:

- a JSON-encoded string of a message list,
- an already-parsed list of message dicts,
- a dict wrapper of the form ``{"messages": [...]}`` or
  ``{"conversations": [...]}``.

Two modes:

- **Filter mode** (default, ``annotate_only=False``): drops rows that fail.
- **Annotate mode** (``annotate_only=True``): keeps all rows and adds a
  ``turn_separator_in_text_filter_error`` column with ``None`` for
  valid rows or one of:

  - ``"malformed_conversation"`` — payload could not be parsed as a
    conversation (invalid JSON, unsupported shape).
  - ``"turn_separator_found"`` — a separator token was detected inside
    message text content.

Usage via ForgeWorkflows::

    forge.execute("turn_separator_in_text_filter",
                  messages_field="messages")

Usage standalone::

    stage = TurnSeparatorInTextFilter(annotate_only=True)
    df_out = stage.process_df(df_in)
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Sequence

from agi_data_curator.filtering._conversation_utils import (
    _ERR_MALFORMED,
    parse_messages as _parse_messages,
)
from agi_data_curator.pipeline.curation_stage import CurationStage

if TYPE_CHECKING:
    import pandas as pd

_ANNOTATE_COLUMN = "turn_separator_in_text_filter_error"

_ERR_SEPARATOR = "turn_separator_found"

_DEFAULT_SEPARATORS: list[str] = [
    "[EOS]",
    "<|endoftext|>",
    "<|end_of_text|>",
    "</s>",
]


def _get_text_content(content) -> str:
    """Extract plain text from a message's ``content`` field.

    Handles:
    - plain string content (ChatML simple form),
    - list-of-blocks content (ChatML multimodal form, extracts ``text``
      blocks and plain strings),
    - ``None`` / other types (returns empty string).
    """
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                parts.append(block.get("text", ""))
            elif isinstance(block, str):
                parts.append(block)
        return "\n".join(parts)
    return ""


def _validate(value, separators: Sequence[str]) -> str | None:
    """Return an error code if any separator is found, else ``None``."""
    messages, err = _parse_messages(value)
    if err is not None:
        return err
    assert messages is not None

    for msg in messages:
        if not isinstance(msg, dict):
            continue
        # ChatML uses "content"; LLaVA uses "value".
        # Use explicit None check — `or` would skip falsy values like "".
        raw = msg.get("content")
        if raw is None:
            raw = msg.get("value")
        text = _get_text_content(raw)
        for sep in separators:
            if sep in text:
                return _ERR_SEPARATOR

    return None


class TurnSeparatorInTextFilter(CurationStage):
    """Drop rows where turn separator tokens appear inside message text.

    Args:
        messages_field: Column holding the conversation.  See the module
            docstring for the accepted payload shapes.
        separators: Separator strings to check for.  Defaults to
            ``["[EOS]", "<|endoftext|>", "<|end_of_text|>", "</s>"]``.
        annotate_only: If ``True``, keep all rows and add the
            ``turn_separator_in_text_filter_error`` column.  If
            ``False`` (default), drop rows that fail.
    """

    def __init__(
        self,
        messages_field: str = "messages",
        separators: list[str] | None = None,
        annotate_only: bool = False,
    ) -> None:
        self._messages_field = messages_field
        self._separators = separators if separators is not None else list(_DEFAULT_SEPARATORS)
        self._annotate_only = annotate_only

    def input_columns(self) -> list[str]:
        return [self._messages_field]

    def output_columns(self) -> list[str]:
        return [_ANNOTATE_COLUMN] if self._annotate_only else []

    def process_df(self, df: "pd.DataFrame") -> "pd.DataFrame":
        if len(df) == 0:
            result = df.copy()
            if self._annotate_only:
                result[_ANNOTATE_COLUMN] = []
            return result

        errors = [_validate(val, self._separators) for val in df[self._messages_field]]

        if self._annotate_only:
            result = df.copy()
            result[_ANNOTATE_COLUMN] = errors
            return result

        keep = [e is None for e in errors]
        return df[keep].reset_index(drop=True)
