"""Quality score bucketing and filtering stages."""

from __future__ import annotations

import gc
import logging
from dataclasses import dataclass, field
from typing import Any

import numpy as np

from nemo_curator.stages.base import ProcessingStage
from nemo_curator.tasks import DocumentBatch

logger = logging.getLogger(__name__)

DCLM_QUANTILES_10: list[float] = [1.05, 1.40, 1.81, 1.97, 2.05, 2.31, 2.8, 3.08, 3.7, 1000]
FWEDU_QUANTILES_10: list[float] = [0.052, 0.124, 0.25, 0.445, 0.66, 0.81, 0.92, 1.0, 1.21, 1000]

# Language-specific fw_edu quantiles (calibrated per-language score distributions).
# Source: Prepare-PT-parquet notebooks.
FWEDU_QUANTILES_10_BY_LANG: dict[str, list[float]] = {
    "fra_Latn": [0.15, 0.3, 0.488, 0.66, 0.79, 0.88, 0.95, 1.03, 1.24, 1000],
}


def make_bucket_names(n_buckets: int, score_type: str = "fw_edu") -> list[str]:
    """Generate bucket names from n_buckets and score_type, plus a trailing NONE entry.

    Examples::

        make_bucket_names(10, "fw_edu")  # ["FWEDU-0-10", ..., "FWEDU-90-100", "NONE"]
        make_bucket_names(5, "dclm")     # ["DCLM-0-20", ..., "DCLM-80-100", "NONE"]
    """
    prefix = score_type.upper().replace("_", "")
    step = 100 // n_buckets
    names = [
        f"{prefix}-{i * step}-{(i + 1) * step if i < n_buckets - 1 else 100}"
        for i in range(n_buckets)
    ]
    names.append("NONE")
    return names


def get_default_quantiles(n_buckets: int, score_type: str, language: str | None = None) -> list[float]:
    """Return default quantile thresholds for the given score type and bucket count.

    Pre-computed thresholds are available for ``n_buckets=10``.  For other counts,
    evenly-spaced ``[0, 1]`` thresholds are returned with a warning.

    If ``language`` is provided and a language-specific preset exists in
    ``FWEDU_QUANTILES_10_BY_LANG``, it takes precedence over the global default.
    """
    if n_buckets == 10:
        if score_type == "dclm":
            return list(DCLM_QUANTILES_10)
        # Check language-specific quantiles first
        if language and language in FWEDU_QUANTILES_10_BY_LANG:
            logger.info("Using language-specific fw_edu quantiles for %s", language)
            return list(FWEDU_QUANTILES_10_BY_LANG[language])
        return list(FWEDU_QUANTILES_10)

    step = 1.0 / n_buckets
    thresholds = [round(step * (i + 1), 4) for i in range(n_buckets - 1)]
    thresholds.append(1000.0)
    logger.warning(
        "No pre-computed quantiles for score_type=%r n_buckets=%d. "
        "Using evenly-spaced [0,1] thresholds. Provide explicit quantiles for accuracy.",
        score_type, n_buckets,
    )
    return thresholds


def _extract_scalar_score(val: Any) -> float | None:
    """Extract a single float from None, a scalar, or a list/array."""
    if val is None:
        return None
    if isinstance(val, (list, np.ndarray)):
        return float(np.mean(val)) if len(val) > 0 else None
    return float(val)


class QualityScoreBucketer(ProcessingStage):
    """Assign quality bucket IDs using quantile thresholds.

    Adds ``quality_bucket_id`` (int) and ``quality_bucket_name`` (str) columns.
    Documents without scores receive ``bucket_id=-1``, ``bucket_name="NONE"``.

    Args:
        score_field: Column containing quality scores.
        score_type: ``"dclm"`` or ``"fw_edu"`` — selects default quantile presets
            and auto-generated bucket name prefixes.
        n_buckets: Number of quality buckets. Default 10.
        quantiles: Optional explicit thresholds. Overrides score_type defaults.
        bucket_names: Optional explicit bucket name list (length ``n_buckets+1``,
            last entry is the NONE bucket). Overrides auto-generated names.
    """

    name = "quality_score_bucketer"

    def __init__(
        self,
        score_field: str = "fw_edu_scores",
        score_type: str = "fw_edu",
        n_buckets: int = 10,
        quantiles: list[float] | None = None,
        bucket_names: list[str] | None = None,
    ):
        self.score_field = score_field
        self.score_type = score_type
        self.n_buckets = n_buckets
        self.quantiles = quantiles if quantiles is not None else get_default_quantiles(n_buckets, score_type)
        self.bucket_names = bucket_names if bucket_names is not None else make_bucket_names(n_buckets, score_type)

    def _get_bucket(self, score: float | None) -> int:
        if score is None:
            return -1
        if score <= self.quantiles[0]:
            return 0
        for i in range(len(self.quantiles) - 1):
            if self.quantiles[i] < score <= self.quantiles[i + 1]:
                return i + 1
        return len(self.quantiles) + 1

    def inputs(self) -> tuple[list[str], list[str]]:
        return ["data"], [self.score_field]

    def outputs(self) -> tuple[list[str], list[str]]:
        return ["data"], ["quality_bucket_id", "quality_bucket_name"]

    def process(self, batch: DocumentBatch) -> DocumentBatch:
        df = batch.to_pandas()

        # Vectorized bucketing via np.searchsorted — avoids row-by-row apply()
        raw = df[self.score_field]
        scores = raw.apply(_extract_scalar_score)
        null_mask = scores.isna()

        # searchsorted: returns index where score would be inserted in sorted quantiles
        # quantiles are already sorted ascending, last entry is 1000 (catch-all)
        thresholds = np.array(self.quantiles)
        bucket_ids = np.searchsorted(thresholds, scores.fillna(-1).values, side="left")
        bucket_ids = bucket_ids.astype(int)
        # Null scores → bucket -1
        bucket_ids[null_mask.values] = -1

        names = np.array(self.bucket_names)
        bucket_names_arr = np.where(
            (bucket_ids >= 0) & (bucket_ids < self.n_buckets),
            names[np.clip(bucket_ids, 0, self.n_buckets - 1)],
            names[-1],  # "NONE"
        )

        df["quality_bucket_id"] = bucket_ids
        df["quality_bucket_name"] = bucket_names_arr
        return DocumentBatch(task_id=batch.task_id, dataset_name=batch.dataset_name, data=df)


class BucketSelector(ProcessingStage):
    """Keep only documents in a specific quality bucket.

    Args:
        target_bucket: Bucket ID to keep (``-1`` for NONE bucket).
    """

    name = "bucket_selector"

    def __init__(self, target_bucket: int):
        self.target_bucket = target_bucket

    def inputs(self) -> tuple[list[str], list[str]]:
        return ["data"], ["quality_bucket_id"]

    def outputs(self) -> tuple[list[str], list[str]]:
        return ["data"], []

    def process(self, batch: DocumentBatch) -> DocumentBatch:
        df = batch.to_pandas()
        filtered = df[df["quality_bucket_id"] == self.target_bucket].reset_index(drop=True)
        return DocumentBatch(task_id=batch.task_id, dataset_name=batch.dataset_name, data=filtered)


class BucketFilter(ProcessingStage):
    """Keep documents within a quality bucket ID range (inclusive).

    Args:
        min_bucket: Minimum bucket ID to keep.
        max_bucket: Maximum bucket ID to keep.
    """

    name = "bucket_filter"

    def __init__(self, min_bucket: int = 5, max_bucket: int = 9):
        self.min_bucket = min_bucket
        self.max_bucket = max_bucket

    def inputs(self) -> tuple[list[str], list[str]]:
        return ["data"], ["quality_bucket_id"]

    def outputs(self) -> tuple[list[str], list[str]]:
        return ["data"], []

    def process(self, batch: DocumentBatch) -> DocumentBatch:
        df = batch.to_pandas()
        mask = (df["quality_bucket_id"] >= self.min_bucket) & (df["quality_bucket_id"] <= self.max_bucket)
        n_in = len(df)
        filtered = df.loc[mask].reset_index(drop=True)
        logger.info("BucketFilter: kept %d/%d rows (buckets %d-%d)", len(filtered), n_in, self.min_bucket, self.max_bucket)
        del df
        gc.collect()
        return DocumentBatch(task_id=batch.task_id, dataset_name=batch.dataset_name, data=filtered)


@dataclass
class SchemaSimplifier(ProcessingStage):
    """Project and rename DataFrame columns.

    Args:
        column_map: Mapping of ``target_name → source_column``.
        defaults: Default values for missing or null columns.
    """

    name = "schema_simplifier"

    column_map: dict[str, str] = field(default_factory=lambda: {"text": "text", "url": "url", "docId": "id", "lang": "language"})
    defaults: dict[str, Any] = field(default_factory=lambda: {"url": "empty", "docId": "", "lang": "en"})

    def inputs(self) -> tuple[list[str], list[str]]:
        return ["data"], list(self.column_map.values())

    def outputs(self) -> tuple[list[str], list[str]]:
        return ["data"], list(self.column_map.keys())

    def process(self, batch: DocumentBatch) -> DocumentBatch:
        df = batch.to_pandas()
        source_cols = [s for s in self.column_map.values() if s in df.columns]
        rename_map = {s: t for t, s in self.column_map.items() if s in df.columns}
        out = df[source_cols].rename(columns=rename_map)
        for target, source in self.column_map.items():
            if source not in df.columns:
                out[target] = self.defaults.get(target, "")
        fill_map = {t: d for t, d in self.defaults.items() if t in out.columns and d is not None}
        if fill_map:
            out = out.fillna(fill_map)
        del df
        gc.collect()
        return DocumentBatch(task_id=batch.task_id, dataset_name=batch.dataset_name, data=out)


class FinePDFsSchemaConverter(ProcessingStage):
    """Convert FinePDFs raw schema to (text, url, docId, lang).

    Args:
        text_field: Source text column. Default ``"text"``.
        url_field: Source URL column. Default ``"url"``.
        id_field: Source document ID column. Default ``"id"``.
        lang_field: Source language column. Default ``"language"``.
    """

    name = "finepdfs_schema_converter"

    def __init__(
        self,
        text_field: str = "text",
        url_field: str = "url",
        id_field: str = "id",
        lang_field: str = "language",
    ):
        self.text_field = text_field
        self.url_field = url_field
        self.id_field = id_field
        self.lang_field = lang_field

    def inputs(self) -> tuple[list[str], list[str]]:
        return ["data"], [self.text_field, self.url_field, self.id_field, self.lang_field]

    def outputs(self) -> tuple[list[str], list[str]]:
        return ["data"], ["text", "url", "docId", "lang"]

    def process(self, batch: DocumentBatch) -> DocumentBatch:
        df = batch.to_pandas()
        out = df[[self.text_field, self.url_field, self.id_field, self.lang_field]].copy()
        out.columns = ["text", "url", "docId", "lang"]
        out["url"] = out["url"].fillna("empty")
        out["docId"] = out["docId"].fillna("")
        out["lang"] = out["lang"].fillna("en")
        return DocumentBatch(task_id=batch.task_id, dataset_name=batch.dataset_name, data=out)