"""Per-stage stats collection for curation pipelines.

Provides ``StatsCollector`` — a transparent pass-through stage that counts
rows before and after a wrapped filter stage. Stats are persisted to disk
(local or S3) so they survive xenna's Ray lifecycle.

Usage::

    from agi_data_curator.tracking.stats_collector import StatsCollector

    # Wrap any filter stage
    pipeline.add_stage(StatsCollector(
        stage=TokenCountFilter(min_tokens=128),
        name="token_count_filter",
    ))

    # After pipeline.run(), extract stats:
    from agi_data_curator.tracking.stats_collector import collect_stats
    stats = collect_stats()
"""

from __future__ import annotations

import json
import logging
import os
import tempfile
import time
import uuid
from typing import Any

# StatsCollector wraps NemoCurator ProcessingStage — only available with [gpu].
# The helper functions (collect_stats, ensure_aggregator, etc.) work without it.
try:
    from nemo_curator.stages.base import ProcessingStage
    from nemo_curator.tasks import DocumentBatch
    _NEMO_AVAILABLE = True
except ImportError:
    ProcessingStage = None  # type: ignore[assignment,misc]
    DocumentBatch = None  # type: ignore[assignment,misc]
    _NEMO_AVAILABLE = False

from agi_data_curator.tracking._fs_cache import get_fs

logger = logging.getLogger(__name__)

_STATS_KEY = "_curation_stats"
# Local temp dir for stats files (single-node). For multi-node clusters,
# set CURATOR_STATS_DIR to an S3 path (e.g., s3://bucket/stats/).
_STATS_DIR = os.environ.get(
    "CURATOR_STATS_DIR",
    os.path.join(tempfile.gettempdir(), "agi_curator_stats"),
)


# ---------------------------------------------------------------------------
# File I/O helpers (local + S3)
# ---------------------------------------------------------------------------

def _write_stat_file(stat_line: str, fname: str) -> None:
    """Write a single stats line to local or S3."""
    if _STATS_DIR.startswith("s3://"):
        fs = get_fs(_STATS_DIR)
        key = f"{_STATS_DIR.replace('s3://', '').rstrip('/')}/{fname}"
        with fs.open(key, "w") as f:
            f.write(stat_line)
    else:
        os.makedirs(_STATS_DIR, exist_ok=True)
        with open(os.path.join(_STATS_DIR, fname), "w") as f:
            f.write(stat_line)


def _read_and_remove_stat_files() -> list[dict]:
    """Read all JSONL stat files and remove them. Returns parsed entries."""
    entries: list[dict] = []

    if _STATS_DIR.startswith("s3://"):
        fs = get_fs(_STATS_DIR)
        prefix = _STATS_DIR.replace("s3://", "").rstrip("/")
        try:
            files = [f for f in fs.ls(prefix) if f.endswith(".jsonl")]
        except FileNotFoundError:
            return entries
        for fpath in files:
            try:
                with fs.open(fpath, "r") as f:
                    for line in f:
                        entries.append(json.loads(line.strip()))
                fs.rm(fpath)
            except Exception as e:
                logger.warning("Failed to read stats file %s: %s", fpath, e)
    elif os.path.isdir(_STATS_DIR):
        for fname in os.listdir(_STATS_DIR):
            if not fname.endswith(".jsonl"):
                continue
            fpath = os.path.join(_STATS_DIR, fname)
            try:
                with open(fpath) as f:
                    for line in f:
                        entries.append(json.loads(line.strip()))
                os.remove(fpath)
            except Exception as e:
                logger.warning("Failed to read stats file %s: %s", fpath, e)

    return entries


def _aggregate_entries(entries: list[dict]) -> dict[str, Any]:
    """Aggregate parsed stat entries into per-stage totals."""
    stage_totals: dict[str, dict[str, float]] = {}
    stage_columns: dict[str, set[str]] = {}
    stage_order: list[str] = []

    for entry in entries:
        name = entry["stage"]
        if name not in stage_totals:
            stage_totals[name] = {"rows_in": 0, "rows_out": 0, "rows_dropped": 0, "process_time_s": 0.0, "batch_count": 0}
            stage_columns[name] = set()
            stage_order.append(name)
        stage_totals[name]["rows_in"] += entry["rows_in"]
        stage_totals[name]["rows_out"] += entry["rows_out"]
        stage_totals[name]["rows_dropped"] += entry["rows_dropped"]
        stage_totals[name]["process_time_s"] += entry.get("process_time_s", 0.0)
        stage_totals[name]["batch_count"] += 1
        for col in entry.get("columns_added", []):
            stage_columns[name].add(col)

    stages = []
    for name in stage_order:
        t = stage_totals[name]
        rate = f"{t['rows_dropped'] / t['rows_in'] * 100:.1f}%" if t["rows_in"] > 0 else "0.0%"
        throughput = t["rows_in"] / t["process_time_s"] if t["process_time_s"] > 0 else 0.0
        stage_entry: dict[str, Any] = {
            "name": name,
            "rows_in": int(t["rows_in"]),
            "rows_out": int(t["rows_out"]),
            "rows_dropped": int(t["rows_dropped"]),
            "drop_rate": rate,
            "process_time_s": round(t["process_time_s"], 3),
            "throughput_rows_per_sec": round(throughput, 1),
        }
        if stage_columns[name]:
            stage_entry["columns_added"] = sorted(stage_columns[name])
        stages.append(stage_entry)

    first_in = stages[0]["rows_in"] if stages else 0
    last_out = stages[-1]["rows_out"] if stages else 0

    return {
        "total_batches": len(entries),
        "stages": stages,
        "overall": {
            "rows_in": first_in,
            "rows_out": last_out,
            "rows_dropped": first_in - last_out,
            "retention_rate": f"{last_out / first_in * 100:.1f}%" if first_in > 0 else "0.0%",
        } if first_in > 0 else {},
    }


# ---------------------------------------------------------------------------
# StatsCollector stage
# ---------------------------------------------------------------------------

_StatsCollectorBase = ProcessingStage if _NEMO_AVAILABLE else object


class StatsCollector(_StatsCollectorBase):  # type: ignore[misc,valid-type]
    """Transparent wrapper that counts rows before/after a filter stage.

    Writes per-batch stats to a shared temp directory as JSON lines.
    After pipeline.run(), call ``collect_stats()`` on the driver to
    aggregate all stats files.

    Stats collection is non-blocking — a write failure logs a warning
    but does not kill the pipeline.

    Requires ``nemo-curator`` (``pip install agi-data-curator[gpu]``).

    Args:
        stage: The filter or processing stage to wrap.
        name: Human-readable name for reporting. Defaults to the
            wrapped stage's class name.
    """

    def __init__(self, stage: Any, name: str | None = None):
        if not _NEMO_AVAILABLE:
            raise ImportError(
                "StatsCollector requires nemo-curator. "
                "Install with: pip install agi-data-curator[gpu]"
            )
        self.stage = stage
        self.stage_name = name or type(stage).__name__
        # Set the stage name for StageTimer / xenna reporting
        self.name = f"stats_collector({self.stage_name})"
        # Forward resources from wrapped stage — use _resources to avoid
        # property setter issues in newer NeMo Curator versions
        if hasattr(stage, "resources"):
            try:
                self.resources = stage.resources
            except AttributeError:
                self._resources = stage.resources
        # Check if wrapped stage declares output columns (enrichment/bucketing)
        # to decide whether to track column changes
        self._track_columns = False
        if hasattr(stage, "outputs"):
            try:
                _, out_cols = stage.outputs()
                self._track_columns = bool(out_cols)
            except Exception:
                pass

    def inputs(self) -> tuple[list[str], list[str]]:
        return self.stage.inputs() if hasattr(self.stage, "inputs") else (["data"], [])

    def outputs(self) -> tuple[list[str], list[str]]:
        return self.stage.outputs() if hasattr(self.stage, "outputs") else (["data"], [])

    def setup(self, *args: Any, **kwargs: Any) -> None:
        """Forward setup() to wrapped stage."""
        if hasattr(self.stage, "setup"):
            self.stage.setup(*args, **kwargs)

    def teardown(self, *args: Any, **kwargs: Any) -> None:
        """Forward teardown() to wrapped stage."""
        if hasattr(self.stage, "teardown"):
            self.stage.teardown(*args, **kwargs)

    @staticmethod
    def _row_count(batch: DocumentBatch) -> int:
        data = getattr(batch, "data", None)
        return len(data) if data is not None else 0

    @staticmethod
    def _columns(batch: DocumentBatch) -> set[str]:
        data = getattr(batch, "data", None)
        if data is not None and hasattr(data, "columns"):
            return set(data.columns)
        return set()

    def process(self, batch: DocumentBatch) -> DocumentBatch:
        rows_before = self._row_count(batch)
        cols_before = self._columns(batch) if self._track_columns else None
        t0 = time.perf_counter()
        result = self.stage.process(batch)
        elapsed = time.perf_counter() - t0
        rows_after = self._row_count(result)

        stat_entry: dict[str, Any] = {
            "stage": self.stage_name,
            "rows_in": rows_before,
            "rows_out": rows_after,
            "rows_dropped": rows_before - rows_after,
            "process_time_s": round(elapsed, 6),
        }
        if cols_before is not None:
            added_cols = sorted(self._columns(result) - cols_before)
            if added_cols:
                stat_entry["columns_added"] = added_cols

        try:
            _write_stat_file(json.dumps(stat_entry) + "\n", f"{uuid.uuid4().hex}.jsonl")
        except Exception as e:
            logger.warning("StatsCollector: failed to write stats for %s: %s", self.stage_name, e)

        return result


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def collect_stats() -> dict[str, Any]:
    """Aggregate per-stage stats from temp files written by StatsCollector.

    Reads all JSONL files from the stats directory, aggregates per-stage,
    cleans up files, and returns the summary dict.
    """
    entries = _read_and_remove_stat_files()
    if not entries:
        return {"total_batches": 0, "stages": [], "overall": {}}
    return _aggregate_entries(entries)


def ensure_aggregator() -> None:
    """Create the stats directory and clean up leftovers from previous runs."""
    if _STATS_DIR.startswith("s3://"):
        try:
            fs = get_fs(_STATS_DIR)
            prefix = _STATS_DIR.replace("s3://", "").rstrip("/")
            for f in fs.ls(prefix):
                if f.endswith(".jsonl"):
                    fs.rm(f)
        except FileNotFoundError:
            pass  # Directory doesn't exist yet — that's fine
        except Exception as e:
            logger.warning("Failed to clean S3 stats dir %s: %s", _STATS_DIR, e)
    else:
        os.makedirs(_STATS_DIR, exist_ok=True)
        for fname in os.listdir(_STATS_DIR):
            fpath = os.path.join(_STATS_DIR, fname)
            try:
                os.remove(fpath)
            except OSError as e:
                logger.warning("Failed to remove stale stats file %s: %s", fpath, e)


def save_stats(stats: dict[str, Any], path: str, pipeline_name: str = "pipeline", elapsed_s: float = 0.0) -> None:
    """Save stats as JSON to local or S3 path."""
    report_data = {"pipeline": pipeline_name, "elapsed_s": round(elapsed_s, 2), **stats}
    content = json.dumps(report_data, indent=2)

    if path.startswith("s3://"):
        fs = get_fs(path)
        with fs.open(path.replace("s3://", ""), "w") as f:
            f.write(content)
    else:
        from pathlib import Path as _Path
        _Path(path).parent.mkdir(parents=True, exist_ok=True)
        _Path(path).write_text(content)

    logger.info("Curation report saved to %s", path)


def print_stats(stats: dict[str, Any], pipeline_name: str = "pipeline") -> None:
    """Print a formatted stats summary."""
    print(f"\n{'═' * 90}")
    print(f"  Curation Report: {pipeline_name}")
    print(f"{'═' * 90}")
    print(f"  Batches: {stats['total_batches']}")
    print()

    if stats["stages"]:
        has_timing = any(s.get("process_time_s", 0) > 0 for s in stats["stages"])
        if has_timing:
            print(f"  {'Stage':<28} {'Rows In':>10} {'Rows Out':>10} {'Dropped':>9} {'Rate':>7} {'Time(s)':>8} {'Rows/s':>10}")
            print(f"  {'─' * 28} {'─' * 10} {'─' * 10} {'─' * 9} {'─' * 7} {'─' * 8} {'─' * 10}")
            for s in stats["stages"]:
                print(f"  {s['name']:<28} {s['rows_in']:>10,} {s['rows_out']:>10,} "
                      f"{s['rows_dropped']:>9,} {s['drop_rate']:>7} "
                      f"{s.get('process_time_s', 0):>8.1f} {s.get('throughput_rows_per_sec', 0):>10,.0f}")
        else:
            print(f"  {'Stage':<30} {'Rows In':>12} {'Rows Out':>12} {'Dropped':>10} {'Rate':>8}")
            print(f"  {'─' * 30} {'─' * 12} {'─' * 12} {'─' * 10} {'─' * 8}")
            for s in stats["stages"]:
                print(f"  {s['name']:<30} {s['rows_in']:>12,} {s['rows_out']:>12,} {s['rows_dropped']:>10,} {s['drop_rate']:>8}")
        print()

    o = stats.get("overall", {})
    if o:
        print(f"  Overall: {o.get('rows_in', 0):,} → {o.get('rows_out', 0):,} "
              f"(retention {o.get('retention_rate', 'N/A')})")

    print(f"{'═' * 90}\n")


def build_unified_report(
    filter_stats: dict[str, Any] | None = None,
    dedup_stats: dict[str, Any] | None = None,
    pipeline_name: str = "pipeline",
    elapsed_s: float = 0.0,
) -> dict[str, Any]:
    """Merge filter stats and dedup stats into a single curation report.

    Combines the output of ``collect_stats()`` (filter pipelines) and
    ``collect_dedup_stats()`` (dedup pipelines) into one JSON-serializable
    dict with a unified ``stages`` list and ``overall`` summary.

    Either or both inputs can be None/empty — the report adapts.

    Args:
        filter_stats: Output of ``collect_stats()``. None if no filter stages ran.
        dedup_stats: Output of ``collect_dedup_stats()``. None if no dedup ran.
        pipeline_name: Name for the report header.
        elapsed_s: Total wall-clock time for the entire pipeline run.

    Returns:
        Unified report dict with keys: pipeline, elapsed_s, total_batches,
        stages (combined list), overall (computed from first input to last output).
    """
    all_stages: list[dict] = []
    total_batches = 0

    if filter_stats and filter_stats.get("stages"):
        all_stages.extend(filter_stats["stages"])
        total_batches += filter_stats.get("total_batches", 0)

    if dedup_stats and dedup_stats.get("stages"):
        all_stages.extend(dedup_stats["stages"])

    if not all_stages:
        return {
            "pipeline": pipeline_name,
            "elapsed_s": round(elapsed_s, 2),
            "total_batches": 0,
            "stages": [],
            "overall": {},
        }

    first_in = all_stages[0]["rows_in"]
    last_out = all_stages[-1]["rows_out"]
    total_dropped = first_in - last_out if first_in > 0 else 0

    return {
        "pipeline": pipeline_name,
        "elapsed_s": round(elapsed_s, 2),
        "total_batches": total_batches,
        "stages": all_stages,
        "overall": {
            "rows_in": first_in,
            "rows_out": last_out,
            "rows_dropped": total_dropped,
            "retention_rate": f"{last_out / first_in * 100:.1f}%" if first_in > 0 else "N/A",
        },
    }
