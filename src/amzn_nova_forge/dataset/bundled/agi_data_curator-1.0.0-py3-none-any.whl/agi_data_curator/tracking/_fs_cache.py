"""Cached filesystem instances for the tracking module.

Avoids creating a new S3FileSystem per call — each instance does
credential resolution, HTTP session setup, and region detection.
On dev desktops with Conduit credentials this can be 100ms+ per instance.
"""

from __future__ import annotations

from typing import Any

_cache: dict[str, Any] = {}


def get_fs(path: str) -> Any:
    """Get a cached fsspec filesystem for the given path's scheme.

    Creates one S3FileSystem (or local fs) per scheme and reuses it
    for all subsequent calls. Thread-safe via dict.setdefault().
    """
    scheme = "s3" if path.startswith("s3://") else "local"
    if scheme not in _cache:
        if scheme == "s3":
            import s3fs
            _cache.setdefault(scheme, s3fs.S3FileSystem())
        else:
            import fsspec
            _cache.setdefault(scheme, fsspec.filesystem("file"))
    return _cache[scheme]


def clear_fs_cache() -> None:
    """Clear cached filesystem instances.

    Call if credentials change mid-process (rare). On EC2/EKS with
    IAM roles, credentials auto-refresh so this is typically unnecessary.
    """
    _cache.clear()
