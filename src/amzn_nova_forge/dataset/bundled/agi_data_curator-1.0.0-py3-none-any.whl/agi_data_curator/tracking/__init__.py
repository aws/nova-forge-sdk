"""Pipeline tracking and reporting."""

from agi_data_curator.tracking.dedup_stats import collect_dedup_stats, count_parquet_rows, validate_dedup_counts
from agi_data_curator.tracking.stats_collector import StatsCollector, build_unified_report, collect_stats, ensure_aggregator, print_stats, save_stats

__all__ = [
    "StatsCollector",
    "build_unified_report",
    "collect_stats",
    "collect_dedup_stats",
    "count_parquet_rows",
    "validate_dedup_counts",
    "ensure_aggregator",
    "print_stats",
    "save_stats",
]
