"""Dedup pipeline statistics from S3/local output metadata.

Reads parquet file metadata (row counts) from the dedup output directory
structure without loading any data. Works for exact, fuzzy, or both.

Memory: O(1) per file — reads only the parquet footer.
Throughput: Threaded metadata reads, ~1000 files/sec on EC2.

Usage::

    from agi_data_curator.tracking.dedup_stats import collect_dedup_stats

    stats = collect_dedup_stats(
        output_path="s3://bucket/dedup-output/",
        input_path="s3://bucket/input/",
    )
"""

from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor
from typing import Any

import pyarrow.parquet as pq

from agi_data_curator.tracking._fs_cache import get_fs

logger = logging.getLogger(__name__)

# Directory names — must match text_dedup_workflow.py
_EXACT_IDS = "exact_ids/ExactDuplicateIds"
_FUZZY_IDS = "fuzzy_ids/FuzzyDuplicateIds"
_EXACT_DEDUPED = "exact_deduplicated"
_FUZZY_DEDUPED = "fuzzy_deduplicated"
_SUCCESS = "_AGI_CURATOR_SUCCESS"


def _join(base: str, *parts: str) -> str:
    """Join path parts, preserving protocol prefix."""
    return "/".join([base.rstrip("/")] + list(parts))


def _strip(path: str) -> str:
    """Strip s3:// for fsspec operations that need bare keys."""
    return path.replace("s3://", "") if path.startswith("s3://") else path


def count_rows(path: str, fs: Any | None = None, max_workers: int = 16) -> int:
    """Count total rows in parquet or JSONL files, recursively.

    - Parquet: reads footer metadata only (fast, O(1) memory per file).
    - JSONL/JSONL.GZ: counts non-empty lines (slower for large files).

    Searches subdirectories recursively so nested layouts like
    ``s3://bucket/data/shard-001/file.jsonl`` are handled.

    Args:
        path: Directory containing data files (S3 or local).
        fs: fsspec filesystem instance. Uses cached instance if None.
        max_workers: Thread pool size for parallel reads.
    """
    if fs is None:
        fs = get_fs(path)

    key = _strip(path).rstrip("/")

    # Recursive glob to find files in subdirectories
    try:
        all_files = fs.glob(f"{key}/**")
    except Exception:
        try:
            all_files = fs.ls(key, detail=False)
        except FileNotFoundError:
            return 0

    parquet_files = [f for f in all_files if f.endswith(".parquet")]
    jsonl_files = [f for f in all_files if f.endswith(".jsonl") or f.endswith(".jsonl.gz")]

    if not parquet_files and not jsonl_files:
        return 0

    def _read_parquet(fpath: str) -> int:
        try:
            with fs.open(fpath, "rb") as fobj:
                return pq.read_metadata(fobj).num_rows
        except Exception as e:
            logger.warning("Failed to read parquet metadata: %s: %s", fpath, e)
            return 0

    def _count_jsonl(fpath: str) -> int:
        try:
            if fpath.endswith(".gz"):
                import gzip
                with fs.open(fpath, "rb") as raw:
                    with gzip.open(raw, "rt") as fobj:
                        return sum(1 for line in fobj if line.strip())
            else:
                with fs.open(fpath, "r") as fobj:
                    return sum(1 for line in fobj if line.strip())
        except Exception as e:
            logger.warning("Failed to count JSONL rows: %s: %s", fpath, e)
            return 0

    # Prefer parquet (fast metadata reads) over JSONL (line counting)
    files = parquet_files or jsonl_files
    reader = _read_parquet if parquet_files else _count_jsonl

    if parquet_files:
        logger.info("Counting rows from %d parquet file(s) at %s", len(files), path)
    else:
        logger.info("Counting rows from %d JSONL file(s) at %s (this may be slow for large files)", len(files), path)

    if len(files) == 1:
        return reader(files[0])

    total = 0
    with ThreadPoolExecutor(max_workers=min(max_workers, len(files))) as pool:
        for rows in pool.map(reader, files):
            total += rows
    return total


# Keep old name as alias for backward compatibility
count_parquet_rows = count_rows


def _has_success(fs: Any, base: str, subdir: str) -> bool:
    """Check _AGI_CURATOR_SUCCESS marker for a dedup stage."""
    root = subdir.split("/")[0]
    return fs.exists(f"{base}/{root}/{_SUCCESS}")


def collect_dedup_stats(
    output_path: str,
    input_path: str | None = None,
    fs: Any | None = None,
) -> dict[str, Any]:
    """Collect dedup statistics from output directory structure.

    Auto-detects which stages ran via _AGI_CURATOR_SUCCESS markers.
    Reads parquet metadata only — no row data loaded.

    When input_path is None, reports duplicate counts without drop rates.

    Args:
        output_path: Root dedup output path (S3 or local).
        input_path: Original input path. Provides drop rate calculation.
        fs: Optional fsspec filesystem. Uses cached instance if None.

    Returns:
        Same format as ``stats_collector.collect_stats()`` for unified reporting.
    """
    if fs is None:
        fs = get_fs(output_path)

    base = _strip(output_path).rstrip("/")

    # Input count (optional — stats still work without it)
    input_count = 0
    if input_path:
        logger.info("Counting input rows at %s ...", input_path)
        input_count = count_rows(input_path, fs)
        logger.info("Input: %d rows", input_count)

    exact_ran = _has_success(fs, base, _EXACT_IDS)
    fuzzy_ran = _has_success(fs, base, _FUZZY_IDS)

    if not exact_ran and not fuzzy_ran:
        return {"total_batches": 0, "stages": [], "overall": {}}

    # Count duplicate IDs (reuse same fs)
    exact_dupes = count_rows(_join(output_path, _EXACT_IDS), fs) if exact_ran else 0
    fuzzy_dupes = count_rows(_join(output_path, _FUZZY_IDS), fs) if fuzzy_ran else 0

    # Fallback: if input count is 0 (e.g., JSONL in nested dirs, or counting
    # was too slow/failed), infer from deduplicated output + duplicates removed.
    # The deduplicated output is always parquet, so metadata reads are fast.
    if input_count == 0:
        # Find the last deduplicated output directory
        if fuzzy_ran and fs.exists(f"{base}/{_FUZZY_DEDUPED}/{_SUCCESS}"):
            deduped_dir = _FUZZY_DEDUPED
        elif exact_ran and fs.exists(f"{base}/{_EXACT_DEDUPED}/{_SUCCESS}"):
            deduped_dir = _EXACT_DEDUPED
        else:
            deduped_dir = None

        if deduped_dir:
            output_count = count_rows(_join(output_path, deduped_dir), fs)
            total_dupes = exact_dupes + fuzzy_dupes
            input_count = output_count + total_dupes
            logger.info(
                "Inferred input count from output (%d) + duplicates (%d) = %d",
                output_count, total_dupes, input_count,
            )

    # Build stages — report even without input_path (just no drop rates)
    stages = []
    running = input_count

    if exact_ran:
        if running > 0:
            out = running - exact_dupes
            rate = f"{exact_dupes / running * 100:.1f}%"
        else:
            out = 0
            rate = "N/A"
        stages.append({
            "name": "Exact Dedup",
            "rows_in": running,
            "rows_out": out,
            "rows_dropped": exact_dupes,
            "drop_rate": rate,
        })
        running = out if running > 0 else 0

    if fuzzy_ran:
        if running > 0:
            out = running - fuzzy_dupes
            rate = f"{fuzzy_dupes / running * 100:.1f}%"
        else:
            out = 0
            rate = "N/A"
        stages.append({
            "name": "Fuzzy Dedup",
            "rows_in": running,
            "rows_out": out,
            "rows_dropped": fuzzy_dupes,
            "drop_rate": rate,
        })

    if not stages:
        return {"total_batches": 0, "stages": [], "overall": {}}

    first_in: int = stages[0]["rows_in"]  # type: ignore[assignment]
    last_out: int = stages[-1]["rows_out"]  # type: ignore[assignment]
    total_dropped = first_in - last_out if first_in > 0 else exact_dupes + fuzzy_dupes

    return {
        "total_batches": 0,
        "stages": stages,
        "overall": {
            "rows_in": first_in,
            "rows_out": last_out,
            "rows_dropped": total_dropped,
            "retention_rate": f"{last_out / first_in * 100:.1f}%" if first_in > 0 else "N/A",
        },
    }


def validate_dedup_counts(
    output_path: str,
    input_path: str,
    precomputed_stats: dict[str, Any] | None = None,
    fs: Any | None = None,
) -> dict[str, Any]:
    """Cross-check computed stats against actual deduplicated output rows.

    Args:
        output_path: Root dedup output path.
        input_path: Original input path.
        precomputed_stats: Avoids re-reading metadata if you already have stats.
        fs: Optional fsspec filesystem. Uses cached instance if None.
    """
    if fs is None:
        fs = get_fs(output_path)

    stats = precomputed_stats or collect_dedup_stats(output_path, input_path, fs)
    if not stats["stages"]:
        return {"valid": True, "expected": 0, "actual": 0, "diff": 0}

    expected = stats["overall"]["rows_out"]
    base = _strip(output_path).rstrip("/")

    # Find last deduplicated output
    if _has_success(fs, base, _FUZZY_IDS):
        deduped_dir = _FUZZY_DEDUPED
    elif _has_success(fs, base, _EXACT_IDS):
        deduped_dir = _EXACT_DEDUPED
    else:
        return {"valid": True, "expected": expected, "actual": 0, "diff": 0}

    actual = count_rows(_join(output_path, deduped_dir), fs)
    diff = actual - expected

    if diff == 0:
        logger.info("Validation passed: %d rows", actual)
    else:
        logger.warning("Validation MISMATCH: expected %d, got %d (diff %+d)", expected, actual, diff)

    return {"valid": diff == 0, "expected": expected, "actual": actual, "diff": diff}
