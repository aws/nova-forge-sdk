"""Text normalization modifiers for NeMo Curator pipelines."""

from __future__ import annotations

import re
import unicodedata

try:
    from nemo_curator.stages.text.modifiers.doc_modifier import DocumentModifier
except ImportError:
    # Fallback for environments without nemo-curator (CPU dev, hatch test).
    # Classes still work standalone — they just won't integrate with NemoCurator pipelines.
    class DocumentModifier:  # type: ignore[no-redef]
        """Minimal stub when nemo-curator is not installed."""
        def __init__(self) -> None:
            pass

# Pre-compiled patterns for performance
_MULTI_SPACE = re.compile(r" +")
_HTML_TAGS = re.compile(r"<[^>]+>")

# Common UTF-8 mojibake sequences → correct characters
_ENCODING_FIXES: dict[str, str] = {
    "\u00e2\u0080\u0099": "\u2019",  # '
    "\u00e2\u0080\u009c": "\u201c",  # "
    "\u00e2\u0080\u009d": "\u201d",  # "
    "\u00e2\u0080\u0094": "\u2014",  # —
    "\u00e2\u0080\u0093": "\u2013",  # –
}


class TextCleaner(DocumentModifier):
    """Fix encoding artifacts, normalize whitespace, remove invisible characters.

    Args:
        fix_encoding: Replace common UTF-8 mojibake sequences.
        normalize_whitespace: Collapse multiple spaces; strip trailing whitespace per line.
        remove_invisible: Remove Unicode control characters (except newline and tab).
    """

    def __init__(
        self,
        fix_encoding: bool = True,
        normalize_whitespace: bool = True,
        remove_invisible: bool = True,
    ):
        super().__init__()
        self.fix_encoding = fix_encoding
        self.normalize_whitespace = normalize_whitespace
        self.remove_invisible = remove_invisible

    def modify_document(self, text: str) -> str:
        if not text:
            return text

        if self.fix_encoding:
            for bad, good in _ENCODING_FIXES.items():
                if bad in text:
                    text = text.replace(bad, good)

        if self.normalize_whitespace:
            text = _MULTI_SPACE.sub(" ", text)
            text = "\n".join(line.rstrip() for line in text.split("\n"))

        if self.remove_invisible:
            text = "".join(c for c in text if unicodedata.category(c)[0] != "C" or c in "\n\t")

        return text.strip()


class DatasetNormalizer(DocumentModifier):
    """Normalize text structure: newlines, control characters, trailing whitespace.

    Args:
        target_format: Target format name (informational only). Default ``"standard"``.
        strip_whitespace: Strip leading/trailing whitespace from the full text.
        normalize_newlines: Convert ``\\r\\n`` and ``\\r`` to ``\\n``.
        remove_control_chars: Remove non-printable characters (except newline/tab/space).
        max_consecutive_newlines: Collapse runs of blank lines. Default 2.
    """

    def __init__(
        self,
        target_format: str = "standard",
        strip_whitespace: bool = True,
        normalize_newlines: bool = True,
        remove_control_chars: bool = True,
        max_consecutive_newlines: int = 2,
    ):
        super().__init__()
        self.target_format = target_format
        self.strip_whitespace = strip_whitespace
        self.normalize_newlines = normalize_newlines
        self.remove_control_chars = remove_control_chars
        self.max_consecutive_newlines = max_consecutive_newlines
        # Pre-compile newline collapse pattern
        self._newline_pattern = re.compile(r"\n{%d,}" % (max_consecutive_newlines + 1))
        self._newline_replacement = "\n" * max_consecutive_newlines

    def modify_document(self, text: str) -> str:
        if not text:
            return text

        if self.strip_whitespace:
            text = text.strip()

        if self.normalize_newlines:
            text = text.replace("\r\n", "\n").replace("\r", "\n")

        if self.remove_control_chars:
            text = "".join(c for c in text if c in ("\n", "\t", " ") or not c.isspace())

        if self.max_consecutive_newlines > 0:
            text = self._newline_pattern.sub(self._newline_replacement, text)

        # Strip trailing whitespace from each line
        text = "\n".join(line.rstrip() for line in text.split("\n"))

        return text


class StandardFormatConverter(DocumentModifier):
    """Convert dataset text to a standard format with optional HTML and Unicode cleanup.

    Args:
        source_name: Source dataset name (informational only).
        clean_html: Strip HTML tags from text.
        normalize_unicode: Apply NFKC Unicode normalization.
    """

    def __init__(
        self,
        source_name: str = "unknown",
        clean_html: bool = False,
        normalize_unicode: bool = True,
    ):
        super().__init__()
        self.source_name = source_name
        self.clean_html = clean_html
        self.normalize_unicode = normalize_unicode

    def modify_document(self, text: str) -> str:
        if not text:
            return text

        if self.clean_html:
            text = _HTML_TAGS.sub("", text)

        if self.normalize_unicode:
            text = unicodedata.normalize("NFKC", text)

        return text.strip()