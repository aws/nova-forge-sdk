"""
Shared Arrow IPC utilities for readers and writers.

Provides common functions for file resolution, IPC decoding,
document splitting, and schema enforcement. Used by both the
new ArrowReader/ArrowWriter and the legacy ArrowReaderStage.
"""

from __future__ import annotations

import io
import logging
from typing import Any

import pandas as pd
import pyarrow as pa
import pyarrow.ipc as ipc

logger = logging.getLogger(__name__)

ARROW_EXTENSIONS = [".arrow", ".ipc"]

_S3_RETRY_CONFIG = {"max_attempts": 10, "mode": "standard"}


def resolve_arrow_files(
    paths: str | list[str],
    storage_options: dict[str, Any] | None = None,
    file_extensions: list[str] | None = None,
) -> list[str]:
    """Recursively resolve paths to individual Arrow IPC files.

    Handles S3 (via ``fsspec.find``) and local (via ``os.walk``).
    Caches filesystem objects per protocol to avoid repeated connections.

    Args:
        paths: Single path or list of paths (S3 or local).
        storage_options: fsspec storage options (e.g., for S3 credentials).
        file_extensions: Extensions to match. Default ``[".arrow", ".ipc"]``.

    Returns:
        Sorted list of resolved file paths.
    """
    if isinstance(paths, str):
        paths = [paths]

    extensions = file_extensions or ARROW_EXTENSIONS
    storage_options = storage_options or {}
    resolved: list[str] = []
    _fs_cache: dict[str, Any] = {}

    for path in paths:
        if "://" in path:
            resolved.extend(
                _resolve_remote(path, storage_options, extensions, _fs_cache)
            )
        else:
            resolved.extend(_resolve_local(path, extensions))

    return resolved


def _resolve_remote(
    path: str,
    storage_options: dict[str, Any],
    extensions: list[str],
    fs_cache: dict[str, Any],
) -> list[str]:
    """Resolve a remote path to Arrow files."""
    import fsspec

    protocol = path.split("://")[0]
    if protocol not in fs_cache:
        opts = dict(storage_options)
        if protocol == "s3":
            config_kwargs = opts.setdefault("config_kwargs", {})
            config_kwargs.setdefault("retries", _S3_RETRY_CONFIG)
        fs, _ = fsspec.core.url_to_fs(path, **opts)
        fs_cache[protocol] = fs
    else:
        fs = fs_cache[protocol]

    fs_path = fs._strip_protocol(path)
    try:
        info = fs.info(fs_path)
    except FileNotFoundError:
        logger.warning("Path not found: %s", path)
        return []

    if info.get("type") == "directory" or path.endswith("/"):
        all_files = fs.find(fs_path)
        arrow_files = [
            fs.unstrip_protocol(f)
            for f in all_files
            if any(f.endswith(ext) for ext in extensions)
        ]
        if not arrow_files:
            logger.warning("No Arrow files found in directory: %s", path)
        else:
            logger.info("Found %d Arrow files in %s", len(arrow_files), path)
        return arrow_files

    return [path]


def _resolve_local(path: str, extensions: list[str]) -> list[str]:
    """Resolve a local path to Arrow files."""
    import os

    if os.path.isdir(path):
        result = []
        for root, _, files in os.walk(path):
            for f in files:
                if any(f.endswith(ext) for ext in extensions):
                    result.append(os.path.join(root, f))
        if not result:
            logger.warning("No Arrow files found in directory: %s", path)
        return sorted(result)

    return [path]


def decode_arrow_bytes(data: bytes) -> pa.Table:
    """Decode binary Arrow IPC data into a PyArrow Table.

    Tries IPC Stream format first (no seek needed), falls back
    to IPC File format (requires seek via BytesIO).

    Args:
        data: Raw bytes of an Arrow IPC file.

    Returns:
        Decoded PyArrow Table.

    Raises:
        pa.ArrowInvalid: If data is not valid Arrow IPC in either format.
    """
    buf = io.BytesIO(data)
    try:
        return ipc.open_stream(buf).read_all()
    except (pa.ArrowInvalid, pa.ArrowNotImplementedError):
        buf.seek(0)
        return ipc.open_file(buf).read_all()


def split_documents_vectorized(
    df: pd.DataFrame,
    doc_separator: str,
    text_field: str = "text",
) -> pd.DataFrame:
    """Vectorized [DOC] splitting using pandas str.split + explode.

    Handles None/NaN values, strips whitespace, drops empty segments.
    Defensively casts to ``large_string`` to avoid Arrow 2 GB offset
    overflow on packed text columns.

    Args:
        df: Input DataFrame.
        doc_separator: Separator string (e.g., ``"[DOC]"``).
        text_field: Column name to split.

    Returns:
        DataFrame with split rows. Empty if all segments are empty.
    """
    if text_field not in df.columns:
        return df

    # Defensive large_string cast for packed text
    if hasattr(df[text_field].dtype, "pyarrow_dtype"):
        pa_type = df[text_field].dtype.pyarrow_dtype
        if pa_type == pa.string():
            df[text_field] = df[text_field].astype(
                pd.ArrowDtype(pa.large_string())
            )

    # Handle None/NaN
    df[text_field] = df[text_field].where(df[text_field].notna(), "")

    # Vectorized split + explode
    df[text_field] = (
        df[text_field].astype(str).str.split(doc_separator, regex=False)
    )
    df = df.explode(text_field, ignore_index=True)

    # Strip whitespace and remove empty strings
    df[text_field] = df[text_field].str.strip()
    df = df[df[text_field].astype(bool)].reset_index(drop=True)

    return df


def apply_schema(
    table: pa.Table, schema: pa.Schema | None
) -> pa.Table:
    """Cast a table to the given schema if provided.

    Args:
        table: Input PyArrow Table.
        schema: Target schema, or None to return table unchanged.

    Returns:
        Cast table, or original table if schema is None.
    """
    if schema is None:
        return table
    return table.cast(schema)
