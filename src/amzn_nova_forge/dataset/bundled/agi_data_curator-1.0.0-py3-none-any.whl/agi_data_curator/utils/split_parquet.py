"""
Parquet file splitting utility using Ray for parallelism.

Splits large parquet files by row group into smaller files on S3.
Uses Ray remote tasks for distributed processing — same pattern as
NeMo Curator's split_large_files.py but with S3 I/O, column selection,
and retry logic.

Usage standalone::

    from agi_data_curator.utils.split_parquet import split_parquet_files

    stats = split_parquet_files(
        input_path="s3://bucket/large-parquets/",
        output_path="s3://bucket/split-128mb/",
        target_size_mb=128,
        columns=["text", "id", "url", "language", "dclm_scores"],
    )

Usage in a workflow::

    class MyWorkflow(WorkflowBase):
        def run(self):
            # Phase 1: split
            split_parquet_files(
                input_path=self.input_path,
                output_path=self.split_path,
                target_size_mb=128,
                columns=self.columns,
                max_files=self.max_files,
            )
            # Phase 2: pipeline reads split files
            pipeline = Pipeline(name="my_pipeline")
            pipeline.add_stage(ParquetReader(file_paths=self.split_path))
            ...
"""

from __future__ import annotations

import gc
import logging
import os
import time
from typing import Any

import pyarrow as pa
import pyarrow.parquet as pq
import ray
import s3fs

logger = logging.getLogger(__name__)


def _split_table(table: pa.Table, target_size: int) -> list[pa.Table]:
    """Recursively split a table until all chunks are below target_size bytes.

    Ported from nemo_curator/utils/split_large_files.py.
    """
    if table.nbytes <= target_size:
        return [table]
    mid = table.num_rows // 2
    if mid == 0:
        return [table]
    left = table.slice(0, mid)
    right = table.slice(mid, table.num_rows - mid)
    results = []
    for t in [left, right]:
        if t.nbytes > target_size:
            results.extend(_split_table(t, target_size))
        else:
            results.append(t)
    return results


def _write_table_to_s3(table: pa.Table, s3_path: str, fs: s3fs.S3FileSystem) -> None:
    """Write a PyArrow table directly to S3 with retry.

    Accepts an existing S3FileSystem to avoid creating one per call.
    """
    s3_key = s3_path.replace("s3://", "")
    for attempt in range(3):
        try:
            with fs.open(s3_key, "wb") as f:
                pq.write_table(table, f)
            return
        except Exception:
            if attempt == 2:
                raise
            time.sleep(2 ** attempt)


@ray.remote(memory=2 * 1024**3)  # 2 GB reservation limits tasks per node
def _split_one_file(
    file_path: str,
    output_prefix: str,
    target_size_mb: int,
    columns: list[str] | None,
) -> dict[str, Any]:
    """Ray remote task: split a single parquet file from S3.

    Optimizations over naive row-group-by-row-group:
    1. Batch row group reads — reads multiple row groups per S3 request
       to reduce round-trip latency.
    2. Threaded writes — S3 uploads happen in a background thread while
       the next batch of row groups is being read.
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    fs = s3fs.S3FileSystem()
    target_bytes = target_size_mb * 1024 * 1024
    basename = os.path.basename(file_path).replace(".parquet", "")
    s3_path = file_path.replace("s3://", "")

    start = time.time()

    try:
        s3_file = fs.open(s3_path, "rb")
        pf = pq.ParquetFile(s3_file)
    except Exception as e:
        return {"source": file_path, "error": str(e), "num_splits": 0, "total_rows": 0}

    try:
        num_rg = pf.metadata.num_row_groups
        if num_rg == 0:
            return {"source": file_path, "num_splits": 0, "total_rows": 0, "elapsed_s": 0}

        # Batch read size: read a few row groups per S3 request to reduce
        # round-trip latency. Keep small to limit memory (5 RGs × ~50 MB
        # = ~250 MB per batch, safe with 64 concurrent tasks).
        rg_per_batch = min(5, num_rg)

        write_pool = ThreadPoolExecutor(max_workers=2)
        write_futures = []
        accumulated: list[pa.Table] = []
        accumulated_bytes = 0
        file_idx = 0
        total_rows = 0
        rg_idx = 0

        while rg_idx < num_rg:
            # Batch read: read multiple row groups in one call
            batch_end = min(rg_idx + rg_per_batch, num_rg)
            batch_indices = list(range(rg_idx, batch_end))
            table = pf.read_row_groups(batch_indices, columns=columns)
            table_bytes = table.nbytes
            total_rows += table.num_rows
            rg_idx = batch_end

            if table_bytes > target_bytes:
                # Batch is larger than target — need to split it
                if accumulated:
                    combined = pa.concat_tables(accumulated)
                    out_path = f"{output_prefix.rstrip('/')}/{basename}_split_{file_idx:04d}.parquet"
                    write_futures.append(write_pool.submit(_write_table_to_s3, combined, out_path, fs))
                    del combined
                    file_idx += 1
                    accumulated = []
                    accumulated_bytes = 0

                for chunk in _split_table(table, target_bytes):
                    out_path = f"{output_prefix.rstrip('/')}/{basename}_split_{file_idx:04d}.parquet"
                    write_futures.append(write_pool.submit(_write_table_to_s3, chunk, out_path, fs))
                    file_idx += 1
                    del chunk
            elif accumulated and (accumulated_bytes + table_bytes) > target_bytes:
                # Flush accumulated, start new with this batch
                combined = pa.concat_tables(accumulated)
                out_path = f"{output_prefix.rstrip('/')}/{basename}_split_{file_idx:04d}.parquet"
                write_futures.append(write_pool.submit(_write_table_to_s3, combined, out_path, fs))
                del combined
                file_idx += 1
                accumulated = [table]
                accumulated_bytes = table_bytes
            else:
                accumulated.append(table)
                accumulated_bytes += table_bytes

            del table
            gc.collect()

        # Flush remaining
        if accumulated:
            combined = pa.concat_tables(accumulated)
            out_path = f"{output_prefix.rstrip('/')}/{basename}_split_{file_idx:04d}.parquet"
            write_futures.append(write_pool.submit(_write_table_to_s3, combined, out_path, fs))
            file_idx += 1
            del combined, accumulated
            gc.collect()

        # Wait for all background writes to complete
        for future in as_completed(write_futures):
            future.result()  # raises if any write failed

        write_pool.shutdown(wait=False)

        elapsed = time.time() - start
        return {
            "source": os.path.basename(file_path),
            "num_splits": file_idx,
            "total_rows": total_rows,
            "num_row_groups": num_rg,
            "elapsed_s": round(elapsed, 1),
        }
    finally:
        s3_file.close()


def _list_parquet_files(s3_prefix: str) -> list[str]:
    """List all parquet files under an S3 prefix."""
    fs = s3fs.S3FileSystem()
    prefix = s3_prefix.replace("s3://", "")
    all_files = sorted(fs.ls(prefix))
    return [f"s3://{f}" for f in all_files if f.endswith(".parquet")]


def split_parquet_files(
    input_path: str,
    output_path: str,
    target_size_mb: int = 128,
    columns: list[str] | None = None,
    max_files: int | None = None,
    num_cpus: int | None = None,
) -> dict[str, Any]:
    """Split large parquet files from S3 into smaller ones using Ray.

    Launches one Ray remote task per source file. Ray handles scheduling
    and concurrency based on available cluster resources.

    Args:
        input_path: S3 prefix containing source parquet files.
        output_path: S3 prefix for split output files.
        target_size_mb: Target size per split file in MB. Default 128.
        columns: Optional column selection (reduces memory and I/O).
        max_files: Limit number of source files to process.
        num_cpus: CPUs for Ray init. None = use all available.

    Returns:
        Dict with stats: source_files, split_files, total_rows, elapsed_s.
    """
    files = _list_parquet_files(input_path)
    if max_files:
        files = files[:max_files]

    if not files:
        logger.warning("No parquet files found at %s", input_path)
        return {"source_files": 0, "split_files": 0, "total_rows": 0, "elapsed_s": 0}

    logger.info(
        "Splitting %d parquet files: %s → %s (target %d MB, columns=%s)",
        len(files), input_path, output_path, target_size_mb, columns,
    )

    # Init Ray if not already running
    if not ray.is_initialized():
        ray.init(num_cpus=num_cpus, ignore_reinit_error=True)
        logger.info("Ray initialized: %s", ray.cluster_resources())

    start = time.time()

    # Submit all tasks
    futures = [
        _split_one_file.remote(f, output_path, target_size_mb, columns)
        for f in files
    ]

    # Collect results as they complete (streaming via ray.wait)
    total_splits = 0
    total_rows = 0
    errors = 0
    remaining = list(futures)
    completed = 0

    while remaining:
        done, remaining = ray.wait(remaining, num_returns=1)
        result = ray.get(done[0])
        completed += 1
        total_splits += result.get("num_splits", 0)
        total_rows += result.get("total_rows", 0)
        if "error" in result:
            errors += 1
            logger.error("[%d/%d] %s: %s", completed, len(files), result["source"], result["error"])
        else:
            logger.info(
                "[%d/%d] %s: %d rows → %d splits (%.1fs)",
                completed, len(files), result["source"],
                result["total_rows"], result["num_splits"], result["elapsed_s"],
            )

    elapsed = time.time() - start
    stats = {
        "source_files": len(files),
        "split_files": total_splits,
        "total_rows": total_rows,
        "errors": errors,
        "elapsed_s": round(elapsed, 1),
    }
    logger.info(
        "Split complete: %d files → %d splits, %d rows, %d errors, %.1fs (%.1f min)",
        stats["source_files"], stats["split_files"], stats["total_rows"],
        stats["errors"], stats["elapsed_s"], stats["elapsed_s"] / 60,
    )
    return stats
