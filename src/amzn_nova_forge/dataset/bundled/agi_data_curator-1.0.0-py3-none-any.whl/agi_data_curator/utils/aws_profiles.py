"""AWS profile management for EMR submission.
Manages AWS CLI profiles used for cross-account EMR access.
"""

import configparser
import os

from loguru import logger

_ENG_ACCOUNT = "926989854342"
_PROD_ACCOUNT = "014498623177"

_POWER_USERS_ROLE = "power-users-access"

ENG_POWER_USERS_PROFILE = f"{_ENG_ACCOUNT}-{_POWER_USERS_ROLE}"
PROD_POWER_USERS_PROFILE = f"{_PROD_ACCOUNT}-{_POWER_USERS_ROLE}"

_account_profiles = [
    {"name": ENG_POWER_USERS_PROFILE, "region": "us-west-2", "account": _ENG_ACCOUNT, "role": _POWER_USERS_ROLE},
    {"name": PROD_POWER_USERS_PROFILE, "region": "us-east-1", "account": _PROD_ACCOUNT, "role": _POWER_USERS_ROLE},
]


def get_profile(account):
    """Get AWS profile name for a given account ID."""
    for profile in _account_profiles:
        if profile["account"] == account:
            return profile["name"]
    raise ValueError(f"Account {account} not found in configured profiles")


def _read_config():
    config = configparser.ConfigParser()
    config_path = os.path.expanduser("~/.aws/config")

    if os.path.exists(config_path):
        config.read(config_path)
        return config, config_path
    return None, config_path


def _add_profile(config, profile_name, region, account_id, role, provider="conduit"):
    section_name = "default" if profile_name == "default" else f"profile {profile_name}"

    if section_name not in config.sections():
        config[section_name] = {}
        config[section_name]["region"] = region
        if profile_name != "default":
            config[section_name]["credential_process"] = (
                f"ada credentials print --account {account_id} --role {role} --provider {provider}"
            )
        return True
    return False


def _save_config(config, config_path):
    os.makedirs(os.path.dirname(config_path), exist_ok=True)
    with open(config_path, "w") as f:
        config.write(f)


def init():
    """Initialize AWS profiles in ~/.aws/config if not present."""
    config, config_path = _read_config()
    if config is None:
        config = configparser.ConfigParser()
    if "default" not in config.sections():
        _add_profile(config, "default", "us-east-1", None, None)

    changes_made = False
    for profile in _account_profiles:
        if _add_profile(config, profile["name"], profile["region"], profile["account"], profile["role"]):
            logger.debug(f"Added profile: {profile['name']}")
            changes_made = True

    if changes_made:
        _save_config(config, config_path)
        logger.debug(f"Configuration saved to {config_path}")
