"""
JSONL utilities for data manipulation.

Utilities for splitting, streaming, chunking, and interleaving JSONL files.

"""

from __future__ import annotations

import itertools
import os
from collections.abc import Generator
from typing import TextIO

def split_jsonl_by_size(
    input_file: str, target_size_mb: int, output_dir: str, output_prefix: str
) -> None:
    """
    Split a large JSONL file into smaller files by size.
    
    Args:
        input_file: Path to input JSONL file
        target_size_mb: Target size in MB for each output file
        output_dir: Output directory
        output_prefix: Prefix for output filenames
    """
    os.makedirs(output_dir, exist_ok=True)

    target_size = target_size_mb * 1024 * 1024
    file_count = 0
    bytes_written = target_size + 1
    out: TextIO | None = None

    base_name = os.path.basename(input_file)  # e.g., "chat.jsonl"
    base_name_no_ext = os.path.splitext(base_name)[0]  # "chat"

    with open(input_file, encoding="utf-8") as infile:
        for line in infile:
            line_len = len(line.encode("utf-8"))
            if bytes_written + line_len > target_size:
                if out is not None:
                    out.close()
                out_path = os.path.join(
                    output_dir, f"{output_prefix}_{base_name_no_ext}_{file_count}.jsonl"
                )
                out = open(out_path, "w", encoding="utf-8")  # noqa: SIM115
                file_count += 1
                bytes_written = 0
            if out is not None:
                out.write(line)
            bytes_written += line_len

    if out is not None:
        out.close()

def stream_jsonl_files(jsonl_dir: str) -> Generator[str, None, None]:
    """
    Stream lines from all JSONL files in a directory.
    
    Note: Ray's write_json names files with .json extension but they're JSONL format.
    
    Args:
        jsonl_dir: Directory containing JSONL files
        
    Yields:
        Lines from JSONL files (without trailing newline)
    """
    files = sorted(f for f in os.listdir(jsonl_dir) if f.endswith(".json"))
    for fname in files:
        with open(os.path.join(jsonl_dir, fname)) as f:
            for line in f:
                yield line.rstrip("\n")

def chunked(gen: Generator[str, None, None], size: int = 100) -> Generator[list[str], None, None]:
    """
    Chunk a generator into lists of specified size.
    
    Args:
        gen: Generator of strings
        size: Chunk size
        
    Yields:
        Lists of strings (may be < size on last chunk)
    """
    while True:
        chunk = list(itertools.islice(gen, size))
        if not chunk:  # generator exhausted
            break
        yield chunk  # may be < size on last chunk

def interleave_datasets(
    dir1: str, dir2: str, out_path: str, chunk_size: int = 1
) -> None:
    """
    Interleave two datasets by alternating chunks.
    
    Useful for creating balanced training sets from multiple sources.
    
    Args:
        dir1: First dataset directory
        dir2: Second dataset directory
        out_path: Output file path
        chunk_size: Number of samples per chunk
    """
    gen1 = chunked(stream_jsonl_files(dir1), chunk_size)
    gen2 = chunked(stream_jsonl_files(dir2), chunk_size)

    with open(out_path, "w") as out:
        for chunk1, chunk2 in itertools.zip_longest(gen1, gen2, fillvalue=[]):  # type: ignore[assignment,var-annotated]
            # write chunk1 (may be empty if dir1 is exhausted)
            for line in chunk1:
                out.write(line + "\n")
            # write chunk2 (may be empty if dir2 is exhausted)
            for line in chunk2:
                out.write(line + "\n")

    print(
        f"Interleaved datasets from {dir1} and {dir2} into {out_path} "
        f"with adaptive chunk size up to {chunk_size}"
    )