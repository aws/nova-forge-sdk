"""Abstract base class for job operators.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict

from agi_data_curator.config.operator_config import OperatorConfig


class BaseOperator(ABC):
    """Abstract base for job operators."""

    config: OperatorConfig

    def __init__(self, config: OperatorConfig):
        if not config:
            raise ValueError("OperatorConfig is required")
        self.config = config

    @abstractmethod
    def submit(self) -> Dict[str, Any]:
        """Submit the job and return submission details."""
        ...
