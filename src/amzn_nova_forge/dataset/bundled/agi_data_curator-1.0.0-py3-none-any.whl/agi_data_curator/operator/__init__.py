"""Job operator module for AGIDataCurator.

Operator imports are lazy to avoid pulling in heavy dependencies
(boto3/nemo_curator for EMR, ray for Ray) when only one operator is needed.
Import directly from the submodule instead:

    from agi_data_curator.operator.emr_operator import EMROperator
    from agi_data_curator.operator.ray_operator import RayJobSubmitter
"""

from agi_data_curator.operator.base_operator import BaseOperator

__all__ = ["BaseOperator", "EMROperator", "RayJobSubmitter"]


def __getattr__(name: str):
    if name == "EMROperator":
        from agi_data_curator.operator.emr_operator import EMROperator
        return EMROperator
    if name == "RayJobSubmitter":
        from agi_data_curator.operator.ray_operator import RayJobSubmitter
        return RayJobSubmitter
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
