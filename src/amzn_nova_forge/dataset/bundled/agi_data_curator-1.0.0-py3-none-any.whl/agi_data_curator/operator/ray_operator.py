"""Ray Job submission operator for EKS clusters.

Submits jobs to a remote Ray cluster via the Job Submission SDK,
uploading local source code at submission time (no image rebuild needed).
"""

import time
from typing import Any, Dict, Optional

from loguru import logger
from ray.job_submission import JobSubmissionClient

from agi_data_curator.config.ray_config import RayJobSubmitterConfig
from agi_data_curator.operator.base_operator import BaseOperator


class RayJobSubmitter(BaseOperator):
    """Submit and monitor Ray jobs on an EKS cluster.

    Python equivalent of the shell submit+poll pattern in run_text_dedup.sh.
    Satisfies the WorkflowOrchestrator submitter interface via submit_and_wait().

    Usage:
        config = RayJobSubmitterConfig.beta()
        submitter = RayJobSubmitter(config)
        output = submitter.submit_and_wait("python -m my_module --arg val")
    """

    _TERMINAL_STATUSES = {"SUCCEEDED", "FAILED", "STOPPED"}

    def __init__(self, config: RayJobSubmitterConfig):
        super().__init__(config)
        self.ray_config = config

        try:
            self.client = JobSubmissionClient(config.ray_address)
        except ConnectionError as e:
            raise ConnectionError(
                f"Cannot connect to Ray at {config.ray_address}. "
                f"Run this first:\n  {config.port_forward_cmd}"
            ) from e

    def _build_runtime_env(self) -> Dict[str, Any]:
        """Construct the runtime_env dict for Ray job submission."""
        return {
            "working_dir": self.ray_config.working_dir,
            "excludes": self.ray_config.excludes,
            "env_vars": self.ray_config.runtime_env_vars,
        }

    def submit(self, entrypoint: str = "") -> Dict[str, Any]:
        """Submit a job and return submission details.

        Args:
            entrypoint: Shell command to run on the Ray cluster.

        Returns:
            Dict with job_id key.
        """
        if not entrypoint:
            raise ValueError("entrypoint is required")

        runtime_env = self._build_runtime_env()
        logger.info(f"Submitting Ray job: {entrypoint}")
        logger.debug(f"Runtime env: {runtime_env}")

        job_id = self.client.submit_job(
            entrypoint=entrypoint,
            runtime_env=runtime_env,
        )
        logger.info(f"Submitted job: {job_id}")
        return {"job_id": job_id}

    def submit_and_wait(self, entrypoint: str) -> str:
        """Submit a job and poll until completion.

        Args:
            entrypoint: Shell command to run on the Ray cluster.

        Returns:
            The job ID of the completed job.

        Raises:
            RuntimeError: If the job fails or is stopped.
            TimeoutError: If timeout_seconds is exceeded.
        """
        result = self.submit(entrypoint)
        job_id = result["job_id"]
        return self._poll_until_done(job_id)

    def _poll_until_done(self, job_id: str) -> str:
        """Poll job status until terminal state.

        Args:
            job_id: Ray job ID to monitor.

        Returns:
            The job ID on success.

        Raises:
            RuntimeError: If the job fails or is stopped.
            TimeoutError: If timeout exceeded.
        """
        elapsed = 0
        last_status = None

        while True:
            status_info = self.client.get_job_status(job_id)
            status = str(status_info)

            if status != last_status:
                logger.info(f"Job {job_id}: {status}")
                last_status = status

            if status == "SUCCEEDED":
                logger.info(f"Job {job_id} completed successfully")
                return job_id

            if status in ("FAILED", "STOPPED"):
                raise RuntimeError(
                    f"Job {job_id} {status}. "
                    f"Check logs: ray job logs --address {self.ray_config.ray_address} {job_id}"
                )

            if (
                self.ray_config.timeout_seconds is not None
                and elapsed >= self.ray_config.timeout_seconds
            ):
                raise TimeoutError(
                    f"Job {job_id} did not finish within {self.ray_config.timeout_seconds}s "
                    f"(last status: {status})"
                )

            time.sleep(self.ray_config.poll_interval_seconds)
            elapsed += self.ray_config.poll_interval_seconds

    def get_logs(self, job_id: str) -> str:
        """Fetch logs for a Ray job.

        Args:
            job_id: Ray job ID.

        Returns:
            Job log output as a string.
        """
        return self.client.get_job_logs(job_id)
