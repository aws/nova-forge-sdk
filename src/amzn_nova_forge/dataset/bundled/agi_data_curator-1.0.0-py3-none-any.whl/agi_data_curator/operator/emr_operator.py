"""EMR cluster creation and step submission.

Creates EMR clusters with Instance Fleets, managed autoscaling,
and submits steps (spark-submit, s3-dist-cp, bash, etc.) via add_job_flow_steps().

"""

import getpass
import time
from typing import Any, Dict, List, Optional

import boto3
from loguru import logger

from agi_data_curator.config.emr_config import (
    EMROperatorConfig,
    SparkSubmitStep,
    StepConfig,
)
from agi_data_curator.operator.base_operator import BaseOperator
from agi_data_curator.utils.aws_profiles import get_profile


class EMROperator(BaseOperator):
    """Creates EMR clusters and submits steps.

    Usage:
        config = EMROperatorConfig(
            emr=EMRClusterConfig(...),
            steps=[
                SparkSubmitStep(
                    script_s3_path="s3://bucket/scripts/my_job.py",
                    py_files=["s3://bucket/packages/my_lib.whl"],
                    script_args=["--input", "s3://in/", "--output", "s3://out/"],
                ),
            ],
            cluster_name="my-cluster",
        )
        operator = EMROperator(config)
        result = operator.submit()
        print(result["cluster_id"], result["step_ids"])
    """

    STEP_NAME_MAX_LENGTH = 250

    config: EMROperatorConfig  # narrow type from BaseOperator

    def __init__(self, config: EMROperatorConfig):
        super().__init__(config)
        self.config = config
        assert config.emr is not None  # guaranteed by EMROperatorConfig.__post_init__
        self.emr_cfg = config.emr

        self.username = config.username or getpass.getuser()
        self.cluster_name = config.cluster_name

        # Boto3 session for EMR
        self.session = boto3.Session(
            profile_name=get_profile(self.emr_cfg.account),
            region_name=self.emr_cfg.region,
        )
        self.emr_client = self.session.client("emr")
        self.cluster_id: Optional[str] = None

    def submit(self) -> Dict[str, Any]:
        """Find or create EMR cluster, build steps, submit them.

        Returns:
            dict with cluster_id, cluster_name, step_ids, step_id, console_url
        """
        if not self._find_existing_cluster():
            logger.info(f"No existing cluster '{self.cluster_name}', creating new one.")
            self._create_cluster()
            logger.info(f"EMR cluster created: {self.cluster_id}")
        else:
            logger.info(f"Reusing existing cluster '{self.cluster_name}': {self.cluster_id}")

        emr_steps = []
        for step_cfg in self.config.steps:
            step_name = step_cfg.name or self._auto_step_name(step_cfg)
            args = step_cfg.to_step_args()
            logger.info(f"Step '{step_name}': {args}")
            emr_steps.append({
                "Name": step_name[:self.STEP_NAME_MAX_LENGTH],
                "ActionOnFailure": step_cfg.action_on_failure,
                "HadoopJarStep": {
                    "Jar": "command-runner.jar",
                    "Args": args,
                },
            })

        response = self.emr_client.add_job_flow_steps(
            JobFlowId=self.cluster_id,
            Steps=emr_steps,
        )
        step_ids = response["StepIds"]
        logger.info(f"Submitted {len(step_ids)} step(s): {step_ids}")

        console_url = self._build_console_url()
        logger.info(f"EMR console: {console_url}")

        return {
            "cluster_id": self.cluster_id,
            "cluster_name": self.cluster_name,
            "step_ids": step_ids,
            "step_id": step_ids[0],
            "console_url": console_url,
        }

    @staticmethod
    def _auto_step_name(step_cfg: StepConfig) -> str:
        """Derive a step name from the step config type and content."""
        if isinstance(step_cfg, SparkSubmitStep):
            script_name = step_cfg.script_s3_path.rstrip("/").split("/")[-1]
            return f"spark-submit {script_name}"
        return type(step_cfg).__name__

    def _find_existing_cluster(self) -> bool:
        """Check for an existing EMR cluster with matching name.

        Searches clusters in STARTING, WAITING, RUNNING, BOOTSTRAPPING states.
        Uses pagination to check all clusters.
        """
        paginator = self.emr_client.get_paginator("list_clusters")
        for page in paginator.paginate(
            ClusterStates=["STARTING", "WAITING", "RUNNING", "BOOTSTRAPPING"]
        ):
            for cluster in page["Clusters"]:
                if cluster["Name"] == self.cluster_name:
                    logger.info(f"Found existing EMR cluster: {cluster['Id']}")
                    self.cluster_id = cluster["Id"]
                    return True
        return False

    def _create_cluster(self) -> None:
        """Create a new EMR cluster with Instance Fleets.
            - EMR 7.12.0, Spark application
            - Instance Fleets (Master + Core) with gp3 EBS
            - Managed autoscaling (up to 2x num_nodes)
            - Bootstrap actions from config
            - IMDSv2 security configuration
            - Auto-termination on idle
        """

        def create_instance_type_configs(instance_types, ebs_size_in_gb=100):
            configs = []
            for instance_type in instance_types:
                configs.append(
                    {
                        "InstanceType": instance_type,
                        "WeightedCapacity": 1,
                        "EbsConfiguration": {
                            "EbsBlockDeviceConfigs": [
                                {
                                    "VolumeSpecification": {
                                        "VolumeType": "gp3",
                                        "SizeInGB": ebs_size_in_gb,
                                    },
                                    "VolumesPerInstance": 1,
                                }
                            ],
                            "EbsOptimized": True,
                        },
                    }
                )
            return configs

        scale_up_factor = 2
        cores_per_instance = 32
        min_capacity_units = cores_per_instance * self.emr_cfg.num_nodes
        max_capacity_units = scale_up_factor * min_capacity_units

        # Build bootstrap actions from config
        bootstrap_actions = []
        for script_uri, args in self.config.bootstrap_actions.items():
            script_name = script_uri.rstrip("/").split("/")[-1]
            action = {
                "Name": f"Bootstrap {script_name}",
                "ScriptBootstrapAction": {
                    "Path": script_uri,
                },
            }
            if args:
                action["ScriptBootstrapAction"]["Args"] = args  # type: ignore[index]
            bootstrap_actions.append(action)

        # For docker confs, check if any step uses docker
        docker_image = self._get_docker_image()
        # Collect spark_env_vars from steps for cluster-level spark-env export
        spark_env_vars = self._get_spark_env_vars()

        cluster_config = {
            "Name": self.cluster_name,
            "LogUri": f"s3://aws-logs-{self.emr_cfg.account}-{self.emr_cfg.region}/elasticmapreduce/",
            "ReleaseLabel": self.config.emr_release_label,
            "Applications": [
                {"Name": "Spark"},
            ],
            "Instances": {
                "InstanceFleets": [
                    {
                        "Name": "Master",
                        "InstanceFleetType": "MASTER",
                        "TargetOnDemandCapacity": 1,
                        "InstanceTypeConfigs": create_instance_type_configs(
                            self.emr_cfg.master_instance_types, 512
                        ),
                    },
                    {
                        "Name": "Core",
                        "InstanceFleetType": "CORE",
                        "TargetOnDemandCapacity": self.emr_cfg.num_nodes,
                        "InstanceTypeConfigs": create_instance_type_configs(
                            self.emr_cfg.core_instance_types
                        ),
                    },
                ],
                "KeepJobFlowAliveWhenNoSteps": True,
                "TerminationProtected": False,
                "Ec2SubnetIds": self.emr_cfg.subnets,
                "EmrManagedMasterSecurityGroup": self.emr_cfg.sg_master,
                "EmrManagedSlaveSecurityGroup": self.emr_cfg.sg_core,
                "ServiceAccessSecurityGroup": self.emr_cfg.sg_service,
                "AdditionalMasterSecurityGroups": self.emr_cfg.sg_master_additional,
                "AdditionalSlaveSecurityGroups": self.emr_cfg.sg_core_additional,
            },
            "StepConcurrencyLevel": self.emr_cfg.step_concurrency_level,
            "ManagedScalingPolicy": {
                "ComputeLimits": {
                    "UnitType": "InstanceFleetUnits",
                    "MinimumCapacityUnits": min_capacity_units,
                    "MaximumCapacityUnits": max_capacity_units,
                    "MaximumOnDemandCapacityUnits": max_capacity_units,
                    "MaximumCoreCapacityUnits": max_capacity_units,
                },
            },
            "ServiceRole": self.emr_cfg.emr_role,
            "JobFlowRole": self.emr_cfg.emr_ec2_role,
            "BootstrapActions": bootstrap_actions,
            "Configurations": self._get_emr_confs(docker_image, spark_env_vars),
            "AutoTerminationPolicy": {"IdleTimeout": self.config.auto_termination_idle_seconds},
            "SecurityConfiguration": "IMDSv2_only",
            "Steps": [
                {
                    "Name": "Setup Hadoop Debugging",
                    "ActionOnFailure": "TERMINATE_CLUSTER",
                    "HadoopJarStep": {
                        "Jar": "command-runner.jar",
                        "Args": ["state-pusher-script"],
                    },
                }
            ],
            "Tags": [
                {"Key": "env.python", "Value": "3.9"},
                {"Key": "env.developer", "Value": self.username},
                {"Key": "Name", "Value": self.cluster_name},
            ],
            "VisibleToAllUsers": True,
            "EbsRootVolumeSize": 64,
        }

        logger.info(f"Creating EMR cluster: {self.cluster_name}")
        logger.debug(f"Cluster config: {cluster_config}")

        response = self.emr_client.run_job_flow(**cluster_config)
        self.cluster_id = response["JobFlowId"]

    def _get_docker_image(self) -> Optional[str]:
        """Return the docker image from the first SparkSubmitStep that has one, or None.

        Cluster-level container-executor config is shared, so only one docker
        image can be registered. If multiple steps use different images, only
        the first is used for cluster config (each step still sets its own
        spark.executorEnv.YARN_CONTAINER_RUNTIME_DOCKER_IMAGE via to_step_args).
        """
        for step in self.config.steps:
            if isinstance(step, SparkSubmitStep) and step.docker_image:
                return step.docker_image
        return None

    def _get_spark_env_vars(self) -> Dict[str, str]:
        """Collect spark_env_vars from all SparkSubmitSteps.

        These are merged into the cluster-level spark-env export so the
        Spark driver inherits them as real environment variables via
        spark-env.sh. Later steps' values override earlier ones for the
        same key.
        """
        merged: Dict[str, str] = {}
        for step in self.config.steps:
            if isinstance(step, SparkSubmitStep):
                merged.update(step.spark_env_vars)
        return merged

    def _get_emr_confs(
        self,
        docker_image: Optional[str] = None,
        spark_env_vars: Optional[Dict[str, str]] = None,
    ) -> list:
        """Build EMR Configurations for CPU or GPU workloads.

            - CPU: adaptive SQL with partition coalescing
            - Docker: container-executor with trusted ECR registry
            - spark-env exports: DEVELOPER + spark_env_vars from steps

        When both GPU and Docker are enabled, their container-executor
        sub-classifications are merged into a single block.
        """
        export_properties: Dict[str, str] = {"DEVELOPER": self.username}
        if spark_env_vars:
            export_properties.update(spark_env_vars)

        configurations = [
            {
                "Classification": "spark-env",
                "Properties": {},
                "Configurations": [
                    {
                        "Classification": "export",
                        "Properties": export_properties,
                    }
                ],
            },
        ]

        # Collect container-executor sub-classifications from Docker and/or GPU
        container_sub_confs = []

        if docker_image:
            registry = docker_image.split("/")[0]
            container_sub_confs.append({
                "Classification": "docker",
                "Properties": {
                    "docker.trusted.registries": registry,
                    "docker.privileged-containers.registries": registry,
                },
            })

        if not self.emr_cfg.gpu_enabled:
            configurations.append(
                {
                    "Classification": "spark-defaults",
                    "Properties": {
                        "spark.sql.adaptive.enabled": "true",
                        "spark.sql.adaptive.coalescePartitions.enabled": "true",
                    },
                }
            )
        else:
            # GPU-specific configurations
            container_sub_confs.extend([
                {"Classification": "gpu", "Properties": {"module.enabled": "true"}},
                {
                    "Classification": "cgroups",
                    "Properties": {"root": "/spark-rapids-cgroup", "yarn-hierarchy": "yarn"},
                },
            ])

            configurations.extend(
                [
                    {"Classification": "spark", "Properties": {"enableSparkRapids": "true"}},
                    {
                        "Classification": "yarn-site",
                        "Properties": {
                            "yarn.nodemanager.resource-plugins": "yarn.io/gpu",
                            "yarn.resource-types": "yarn.io/gpu",
                            "yarn.nodemanager.resource-plugins.gpu.allowed-gpu-devices": "auto",
                            "yarn.nodemanager.resource-plugins.gpu.path-to-discovery-executables": "/usr/bin",
                            "yarn.nodemanager.linux-container-executor.cgroups.mount": "true",
                            "yarn.nodemanager.linux-container-executor.cgroups.mount-path": "/spark-rapids-cgroup",
                            "yarn.nodemanager.linux-container-executor.cgroups.hierarchy": "yarn",
                            "yarn.nodemanager.container-executor.class": "org.apache.hadoop.yarn.server.nodemanager.LinuxContainerExecutor",
                        },
                    },
                    {
                        "Classification": "spark-defaults",
                        "Properties": {
                            "spark.plugins": "com.nvidia.spark.SQLPlugin",
                            "spark.executor.resource.gpu.discoveryScript": "/usr/lib/spark/scripts/gpu/getGpusResources.sh",
                            "spark.executor.extraLibraryPath": (
                                "/usr/local/cuda/targets/x86_64-linux/lib:"
                                "/usr/local/cuda/extras/CUPTI/lib64:"
                                "/usr/local/cuda/compat/lib:"
                                "/usr/local/cuda/lib:"
                                "/usr/local/cuda/lib64:"
                                "/usr/lib/hadoop/lib/native:"
                                "/usr/lib/hadoop-lzo/lib/native:"
                                "/docker/usr/lib/hadoop/lib/native:"
                                "/docker/usr/lib/hadoop-lzo/lib/native"
                            ),
                            "spark.submit.pyFiles": "/usr/lib/spark/jars/xgboost4j-spark_3.0-1.4.2-0.3.0.jar",
                            "spark.rapids.sql.concurrentGpuTasks": "1",
                            "spark.executor.resource.gpu.amount": "1",
                            "spark.executor.cores": "2",
                            "spark.task.cpus": "1",
                            "spark.task.resource.gpu.amount": "0.5",
                            "spark.rapids.memory.pinnedPool.size": "0",
                            "spark.executor.memoryOverhead": "2G",
                            "spark.locality.wait": "0s",
                            "spark.sql.shuffle.partitions": "200",
                            "spark.sql.files.maxPartitionBytes": "512m",
                            "spark.sql.adaptive.enabled": "true",
                            "spark.sql.adaptive.coalescePartitions.enabled": "true",
                        },
                    },
                    {
                        "Classification": "capacity-scheduler",
                        "Properties": {
                            "yarn.scheduler.capacity.resource-calculator": "org.apache.hadoop.yarn.util.resource.DominantResourceCalculator"
                        },
                    },
                ]
            )

        # Add container-executor if Docker or GPU (or both) need it
        if container_sub_confs:
            configurations.append({
                "Classification": "container-executor",
                "Properties": {},
                "Configurations": container_sub_confs,
            })

        return configurations

    def _build_console_url(self) -> str:
        """Build the EMR console URL via Conduit deep link."""
        return (
            "https://conduit.security.a2z.com/api/consoleUrl"
            f"?ref=ConduitDeepLinkUrl&redirect=true&awsAccountId={self.emr_cfg.account}"
            f"&awsPartition=aws&sessionDuration=3600"
            f"&iamRole=arn%3Aaws%3Aiam%3A%3A{self.emr_cfg.account}%3Arole%2Fpower-users-access"
            f"&destination=https%3A%2F%2F{self.emr_cfg.region}.console.aws.amazon.com"
            f"%2Femr%2Fhome%3Fregion%3D{self.emr_cfg.region}"
            f"%23%2FclusterDetails%2F{self.cluster_id}"
        )

    # Terminal states for EMR steps
    _TERMINAL_STATES = {"COMPLETED", "FAILED", "CANCELLED", "INTERRUPTED"}
    _ACTIVE_STATES = {"PENDING", "CANCEL_PENDING", "RUNNING"}

    def get_steps_status(self, cluster_id: Optional[str] = None) -> List[Dict[str, str]]:
        """Get the status of all steps on the cluster.

        Args:
            cluster_id: EMR cluster ID. Defaults to self.cluster_id.

        Returns:
            List of dicts with step_id, name, and state for each step.
        """
        cid = cluster_id or self.cluster_id
        if not cid:
            raise ValueError("No cluster_id available. Run submit() first or pass cluster_id.")

        steps = []
        paginator = self.emr_client.get_paginator("list_steps")
        for page in paginator.paginate(ClusterId=cid):
            for step in page["Steps"]:
                steps.append({
                    "step_id": step["Id"],
                    "name": step["Name"],
                    "state": step["Status"]["State"],
                })
        return steps

    def all_steps_finished(self, cluster_id: Optional[str] = None) -> bool:
        """Check if all steps on the cluster have reached a terminal state.

        Args:
            cluster_id: EMR cluster ID. Defaults to self.cluster_id.

        Returns:
            True if every step is in a terminal state (COMPLETED, FAILED, CANCELLED, INTERRUPTED).
        """
        steps = self.get_steps_status(cluster_id)
        if not steps:
            return True
        return all(s["state"] in self._TERMINAL_STATES for s in steps)

    def wait_for_steps(
        self,
        cluster_id: Optional[str] = None,
        poll_interval_seconds: int = 60,
        timeout_seconds: Optional[int] = None,
    ) -> List[Dict[str, str]]:
        """Poll until all steps on the cluster finish.

        Args:
            cluster_id: EMR cluster ID. Defaults to self.cluster_id.
            poll_interval_seconds: Seconds between status checks.
            timeout_seconds: Max seconds to wait. None means wait indefinitely.

        Returns:
            Final list of step statuses.

        Raises:
            TimeoutError: If timeout_seconds is exceeded.
        """
        cid = cluster_id or self.cluster_id
        elapsed = 0

        while True:
            steps = self.get_steps_status(cid)
            active = [s for s in steps if s["state"] in self._ACTIVE_STATES]

            if not active:
                failed = [s for s in steps if s["state"] in ("FAILED", "CANCELLED", "INTERRUPTED")]
                if failed:
                    for s in failed:
                        logger.warning(f"Step {s['step_id']} ({s['name']}): {s['state']}")
                else:
                    logger.info("All steps completed successfully.")
                return steps

            if timeout_seconds is not None and elapsed >= timeout_seconds:
                raise TimeoutError(
                    f"Steps did not finish within {timeout_seconds}s. "
                    f"Active: {[s['step_id'] for s in active]}"
                )

            logger.info(
                f"Waiting for {len(active)} active step(s): "
                + ", ".join(f"{s['name']}={s['state']}" for s in active)
            )

            time.sleep(poll_interval_seconds)
            elapsed += poll_interval_seconds
