"""Shared benchmark configuration: GPU mocks for CPU-only CI."""

import os
import sys
from unittest.mock import MagicMock

# Allow nemo_curator to run on non-Linux (macOS dev machines)
os.environ["NEMO_CURATOR_ALLOW_NON_LINUX"] = "1"

_GPU_MOCKS = [
    "cudf", "cudf.core", "cudf.utils", "dask_cudf", "cuml", "cugraph",
    "rmm", "rmm.mr", "rmm.pylibrmm", "rmm.pylibrmm.mr",
    "resiliparse", "resiliparse.extract", "resiliparse.extract.html2text",
    "resiliparse.parse", "resiliparse.parse.lang",
    "rapidsmpf", "rapidsmpf.buffer", "rapidsmpf.buffer.buffer",
    "rapidsmpf.buffer.resource", "rapidsmpf.integrations",
    "rapidsmpf.integrations.cudf", "rapidsmpf.integrations.cudf.partition",
    "rapidsmpf.integrations.dask", "rapidsmpf.rmm_resource_adaptor",
    "rapidsmpf.shuffler", "rapidsmpf.statistics", "rapidsmpf.utils",
    "rapidsmpf.utils.cudf", "rapidsmpf.utils.ray_utils",
    "pynvml", "cupy", "pylibcudf",
    "cugraph.comms", "cugraph.comms.comms_wrapper",
    "pylibcugraph", "pylibcugraph.comms", "pylibcugraph.comms.comms_wrapper",
]

# When running on a real GPU cluster (EKS), skip mock installation.
# Set BENCHMARK_NO_GPU_MOCK=1 to use real GPU libraries.
if not os.environ.get("BENCHMARK_NO_GPU_MOCK"):
    for mod_name in _GPU_MOCKS:
        if mod_name not in sys.modules:
            sys.modules[mod_name] = MagicMock()
