"""Synthetic dataset factories for performance benchmarks."""

import random
import string

import numpy as np
import pandas as pd

_SYSTEM_PROMPT_PHRASES = [
    "You are a helpful assistant that answers questions.",
    "As an AI language model, I cannot provide that information.",
    "<|system|> You are a chatbot.",
    "<|im_start|>system\nYou help users with tasks.",
    "<<SYS>> Be helpful and harmless <</SYS>>",
    "[INST] Follow these instructions [/INST]",
]

_URL_HEAVY_PHRASES = [
    "Visit https://example.com and http://test.org for more info. "
    "Also see https://foo.bar/page and http://a.b.c/d for details.",
]

_REPEATED_LINE_PHRASES = [
    "This line is repeated.\n" * 20,
]

_BOILERPLATE_PHRASES = [
    "Terms of Use | Privacy Policy | Cookie Policy | Terms of Use | Privacy Policy | "
    "Cookie Policy | All Rights Reserved | Terms and Conditions",
    "Subscribe to our newsletter. Privacy Policy. Terms and Conditions. Cookie Policy. "
    "All Rights Reserved. Copyright notice. Terms of Use.",
]

_NON_ALPHA_PHRASES = [
    "@#$%^&*()!!! ??? @@@ ### $$$ %%% ^^^ &&& *** ((( )))",
    "!!!...???@@@!!!...???@@@!!!...???@@@###$$$%%%^^^&&&",
]

_REPEATED_PARAGRAPH_PHRASES = [
    "Same paragraph repeated.\n\nSame paragraph repeated.\n\nSame paragraph repeated.\n\n"
    "Same paragraph repeated.\n\nSame paragraph repeated.",
]


def _random_sentence(rng: random.Random, min_words: int = 8, max_words: int = 15) -> str:
    n_words = rng.randint(min_words, max_words)
    words = []
    for _ in range(n_words):
        word_len = rng.randint(2, 10)
        words.append("".join(rng.choices(string.ascii_lowercase, k=word_len)))
    sentence = " ".join(words)
    return sentence[0].upper() + sentence[1:] + "."


def _random_text(rng: random.Random, target_words: int = 100, paragraphs: bool = False) -> str:
    sentences = []
    word_count = 0
    while word_count < target_words:
        s = _random_sentence(rng)
        sentences.append(s)
        word_count += len(s.split())
    if paragraphs:
        # Group sentences into paragraphs of 2-3 sentences each
        paras = []
        i = 0
        while i < len(sentences):
            chunk = rng.randint(2, 3)
            paras.append(" ".join(sentences[i:i + chunk]))
            i += chunk
        return "\n\n".join(paras)
    return " ".join(sentences)


def generate_text_dataframe(n_rows: int, seed: int = 42) -> pd.DataFrame:
    """Generate a deterministic DataFrame with synthetic text data.

    ~10% of rows contain filter-triggering patterns so both keep and reject
    paths are exercised.
    """
    rng = random.Random(seed)
    np_rng = np.random.RandomState(seed)

    texts = []
    for i in range(n_rows):
        r = rng.random()
        if r < 0.04:
            texts.append(rng.choice(_SYSTEM_PROMPT_PHRASES) + " " + _random_text(rng, 80))
        elif r < 0.07:
            texts.append(rng.choice(_URL_HEAVY_PHRASES) + " " + _random_text(rng, 60))
        elif r < 0.10:
            texts.append(rng.choice(_REPEATED_LINE_PHRASES) + _random_text(rng, 40))
        elif r < 0.12:
            texts.append(rng.choice(_BOILERPLATE_PHRASES) + " " + _random_text(rng, 40))
        elif r < 0.14:
            texts.append(rng.choice(_NON_ALPHA_PHRASES) + " " + _random_text(rng, 40))
        elif r < 0.16:
            texts.append(rng.choice(_REPEATED_PARAGRAPH_PHRASES) + "\n\n" + _random_text(rng, 40))
        elif r < 0.18:
            texts.append(_random_text(rng, rng.randint(60, 140), paragraphs=True))
        else:
            texts.append(_random_text(rng, rng.randint(60, 140)))

    return pd.DataFrame({
        "text": texts,
        "token_count": np_rng.randint(50, 200_001, size=n_rows),
        "is_truncated": np_rng.random(n_rows) < 0.10,
        "duplicate_count": np_rng.randint(0, 51, size=n_rows),
        "fw_edu_scores": np_rng.uniform(0.0, 5.0, size=n_rows),
        "id": [f"doc-{i:06d}" for i in range(n_rows)],
    })
