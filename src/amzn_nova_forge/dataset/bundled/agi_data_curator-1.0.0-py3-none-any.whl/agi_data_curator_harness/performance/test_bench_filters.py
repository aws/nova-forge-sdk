"""Performance benchmarks for heuristic and column filters."""

import pytest

from agi_data_curator.filtering.heuristic_filters import SystemPromptFilter
from agi_data_curator.filtering.column_filters import TokenCountFilter
from nemo_curator.stages.text.filters.heuristic_filter import (
    BoilerPlateStringFilter,
    MeanWordLengthFilter,
    NonAlphaNumericFilter,
    RepeatedLinesFilter,
    RepeatedParagraphsFilter,
    RepeatingDuplicateNGramsFilter,
    RepeatingTopNGramsFilter,
    UrlsFilter,
    WordCountFilter,
)


# Each entry: (test_id, filter_instance)
_HEURISTIC_FILTERS = [
    ("system_prompt_filter", SystemPromptFilter()),
    ("repeating_top_ngrams_filter", RepeatingTopNGramsFilter(n=2, max_repeating_ngram_ratio=0.2)),
    ("word_count_filter", WordCountFilter(min_words=5, max_words=100_000)),
    ("non_alpha_numeric_filter", NonAlphaNumericFilter(max_non_alpha_numeric_to_text_ratio=0.25)),
    ("urls_filter", UrlsFilter(max_url_to_text_ratio=0.2)),
    ("boiler_plate_string_filter", BoilerPlateStringFilter(max_boilerplate_string_ratio=0.4)),
    ("repeated_lines_filter", RepeatedLinesFilter(max_repeated_line_fraction=0.7)),
    ("repeated_paragraphs_filter", RepeatedParagraphsFilter(max_repeated_paragraphs_ratio=0.7)),
    ("repeating_duplicate_ngrams_filter", RepeatingDuplicateNGramsFilter(n=5, max_repeating_duplicate_ngram_ratio=0.2)),
    ("mean_word_length_filter", MeanWordLengthFilter(min_mean_word_length=3, max_mean_word_length=10)),
]


@pytest.mark.benchmark(group="heuristic-filters")
@pytest.mark.parametrize(
    "filter_id, filt",
    _HEURISTIC_FILTERS,
    ids=[f[0] for f in _HEURISTIC_FILTERS],
)
def test_bench_heuristic_filter(benchmark, small_text_docs, filter_id, filt):
    def run():
        for doc in small_text_docs:
            filt.score_document(doc)

    benchmark(run)
    benchmark.extra_info["throughput_docs_per_sec"] = (
        len(small_text_docs) / benchmark.stats["mean"]
    )


@pytest.mark.benchmark(group="column-filters")
def test_bench_token_count_filter(benchmark, medium_batch):
    filt = TokenCountFilter(min_tokens=128, max_tokens=100_000)

    result = benchmark(filt.process, medium_batch)

    result_df = result.to_pandas()
    benchmark.extra_info["throughput_rows_per_sec"] = (
        len(medium_batch.to_pandas()) / benchmark.stats["mean"]
    )
    benchmark.extra_info["rows_in"] = len(medium_batch.to_pandas())
    benchmark.extra_info["rows_out"] = len(result_df)
