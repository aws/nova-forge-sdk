"""Performance benchmarks for quality score bucketing."""

import pytest

from agi_data_curator.filtering.quality_bucketer import QualityScoreBucketer


@pytest.mark.benchmark(group="quality-bucketing")
def test_bench_quality_score_bucketer(benchmark, medium_batch):
    bucketer = QualityScoreBucketer(score_field="fw_edu_scores")

    result = benchmark(bucketer.process, medium_batch)

    result_df = result.to_pandas()
    benchmark.extra_info["throughput_rows_per_sec"] = (
        len(result_df) / benchmark.stats["mean"]
    )
    benchmark.extra_info["rows_processed"] = len(result_df)
