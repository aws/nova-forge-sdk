"""Performance benchmark fixtures — session-scoped synthetic data."""

import pytest

from agi_data_curator_harness.performance.data_generators import generate_text_dataframe


@pytest.fixture(scope="session")
def small_df():
    """Small DataFrame (1,000 rows) for per-document benchmarks."""
    return generate_text_dataframe(1_000, seed=42)


@pytest.fixture(scope="session")
def medium_df():
    """Medium DataFrame (10,000 rows) for batch benchmarks."""
    return generate_text_dataframe(10_000, seed=42)


@pytest.fixture(scope="session")
def small_text_docs(small_df):
    """List of text strings from the small dataset."""
    return small_df["text"].tolist()


@pytest.fixture(scope="session")
def medium_batch(medium_df):
    """DocumentBatch from the medium dataset."""
    from nemo_curator.tasks import DocumentBatch

    return DocumentBatch(task_id="bench", dataset_name="bench", data=medium_df)
