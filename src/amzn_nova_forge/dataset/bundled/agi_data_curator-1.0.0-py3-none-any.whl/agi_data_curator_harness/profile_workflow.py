#!/usr/bin/env python3
"""Profile a workflow config's filter stages for latency and throughput.

Runs each filter/stage in the workflow independently on synthetic data and
reports per-stage latency and throughput metrics.

Usage:
    # Profile the FinePDFs eng pipeline stages
    python -m agi_data_curator_harness.profile_workflow \
        --config-path src/agi_data_curator/workflows/finepdfs \
        --config-name finepdfs_eng \
        --rows 10000 --rounds 5

    # Profile with custom data
    python -m agi_data_curator_harness.profile_workflow \
        --config-path src/agi_data_curator/workflows/finepdfs \
        --config-name finepdfs_eng \
        --input-parquet /tmp/sample_data.parquet

    # Output JSON for CI integration
    python -m agi_data_curator_harness.profile_workflow \
        --config-path src/agi_data_curator/workflows/finepdfs \
        --config-name finepdfs_eng \
        --json-output profile_results.json
"""

from __future__ import annotations

import argparse
import json
import statistics
import sys
import time
from pathlib import Path

# GPU mocks for CPU-only environments
from agi_data_curator_harness.conftest import _GPU_MOCKS  # noqa: F401 — triggers GPU mock installation

import pandas as pd
from hydra import compose, initialize_config_dir

from agi_data_curator_harness.performance.data_generators import generate_text_dataframe


def _instantiate_stages_from_config(config_path: str, config_name: str) -> list[tuple[str, object]]:
    """Load a Hydra workflow config and build filter stages directly.

    Reads the config values and constructs filter/processing stages without
    importing the workflow class itself (which may have heavy transitive
    dependencies like ftfy, s3fs, etc.).

    Returns list of (stage_name, stage_instance) tuples.
    """
    from agi_data_curator.filtering.column_filters import (
        TokenCountFilter, TruncationFilter, DuplicateCountFilter,
    )
    from agi_data_curator.filtering.quality_bucketer import QualityScoreBucketer
    from nemo_curator.stages.text.filters.heuristic_filter import (
        BoilerPlateStringFilter,
        MeanWordLengthFilter,
        NonAlphaNumericFilter,
        RepeatedLinesFilter,
        RepeatedParagraphsFilter,
        RepeatingDuplicateNGramsFilter,
        RepeatingTopNGramsFilter,
        UrlsFilter,
        WordCountFilter,
    )

    abs_path = str(Path(config_path).resolve())
    with initialize_config_dir(config_dir=abs_path, version_base=None):
        cfg = compose(config_name=config_name)

    stages = []

    # --- Heuristic filters (score_document / keep_document) ---

    min_words = cfg.get("min_words")
    max_words = cfg.get("max_words")
    if min_words is not None and max_words is not None:
        stages.append((
            "WordCountFilter",
            WordCountFilter(min_words=min_words, max_words=max_words),
        ))

    min_mwl = cfg.get("min_mean_word_length")
    max_mwl = cfg.get("max_mean_word_length")
    if min_mwl is not None and max_mwl is not None:
        stages.append((
            "MeanWordLengthFilter",
            MeanWordLengthFilter(min_mean_word_length=min_mwl, max_mean_word_length=max_mwl),
        ))

    max_non_alpha = cfg.get("max_non_alpha_ratio")
    if max_non_alpha is not None:
        stages.append((
            "NonAlphaNumericFilter",
            NonAlphaNumericFilter(max_non_alpha_numeric_to_text_ratio=max_non_alpha),
        ))

    max_url = cfg.get("max_url_ratio")
    if max_url is not None:
        stages.append((
            "UrlsFilter",
            UrlsFilter(max_url_to_text_ratio=max_url),
        ))

    max_boilerplate = cfg.get("max_boilerplate_ratio")
    if max_boilerplate is not None:
        stages.append((
            "BoilerPlateStringFilter",
            BoilerPlateStringFilter(max_boilerplate_string_ratio=max_boilerplate),
        ))

    max_rep_lines = cfg.get("max_repeated_lines")
    if max_rep_lines is not None:
        stages.append((
            "RepeatedLinesFilter",
            RepeatedLinesFilter(max_repeated_line_fraction=max_rep_lines),
        ))

    max_rep_paras = cfg.get("max_repeated_paragraphs")
    if max_rep_paras is not None:
        stages.append((
            "RepeatedParagraphsFilter",
            RepeatedParagraphsFilter(max_repeated_paragraphs_ratio=max_rep_paras),
        ))

    max_rep_ngrams = cfg.get("max_repeating_ngrams")
    if max_rep_ngrams is not None:
        stages.append((
            "RepeatingTopNGramsFilter",
            RepeatingTopNGramsFilter(n=2, max_repeating_ngram_ratio=max_rep_ngrams),
        ))

    max_char_rep = cfg.get("max_char_repetition")
    if max_char_rep is not None:
        stages.append((
            "RepeatingDuplicateNGramsFilter",
            RepeatingDuplicateNGramsFilter(n=5, max_repeating_duplicate_ngram_ratio=max_char_rep),
        ))

    if cfg.get("filter_system_prompts", False):
        from agi_data_curator.filtering.heuristic_filters import SystemPromptFilter
        stages.append((
            "SystemPromptFilter",
            SystemPromptFilter(),
        ))

    # --- Column filters (batch process()) ---

    min_tokens = cfg.get("min_tokens")
    max_tokens = cfg.get("max_tokens")
    if min_tokens is not None and max_tokens is not None:
        stages.append((
            "TokenCountFilter",
            TokenCountFilter(min_tokens=min_tokens, max_tokens=max_tokens),
        ))

    if cfg.get("filter_truncated", False):
        stages.append((
            "TruncationFilter",
            TruncationFilter(keep_truncated=False),
        ))

    max_duplicates = cfg.get("max_duplicates")
    if max_duplicates is not None:
        stages.append((
            "DuplicateCountFilter",
            DuplicateCountFilter(max_duplicates=max_duplicates),
        ))

    n_buckets = cfg.get("n_buckets")
    if n_buckets is not None:
        score_field = cfg.get("score_field", None)
        score_type = cfg.get("score_type", None)
        if score_field is None or score_type is None:
            target = ""
            for item in cfg.get("workflow", []):
                target = item.get("_target_", "")
                break
            if "eng" in target.lower() or "dclm" in target.lower():
                score_field = score_field or "dclm_scores"
                score_type = score_type or "dclm"
            else:
                score_field = score_field or "fw_edu_scores"
                score_type = score_type or "fw_edu"
        stages.append((
            "QualityScoreBucketer",
            QualityScoreBucketer(
                score_field=score_field,
                score_type=score_type,
                n_buckets=n_buckets,
            ),
        ))

    return stages


def _make_batch(df: pd.DataFrame):
    """Create a DocumentBatch from a DataFrame."""
    from nemo_curator.tasks import DocumentBatch
    return DocumentBatch(task_id="profile", dataset_name="profile", data=df)


def profile_stage(name: str, stage, df: pd.DataFrame, rounds: int) -> dict:
    """Profile a single processing stage, returning latency metrics."""
    from nemo_curator.stages.base import ProcessingStage

    timings = []
    for _ in range(rounds):
        batch = _make_batch(df.copy())
        start = time.perf_counter()
        if isinstance(stage, ProcessingStage):
            result = stage.process(batch)
        elif hasattr(stage, "score_document"):
            for text in df["text"]:
                stage.score_document(text)
            result = None
        else:
            result = stage.process(batch)
        elapsed = time.perf_counter() - start
        timings.append(elapsed)

    mean_s = statistics.mean(timings)
    rows = len(df)
    return {
        "stage": name,
        "rounds": rounds,
        "rows": rows,
        "mean_seconds": round(mean_s, 6),
        "stddev_seconds": round(statistics.stdev(timings), 6) if len(timings) > 1 else 0.0,
        "min_seconds": round(min(timings), 6),
        "max_seconds": round(max(timings), 6),
        "throughput_rows_per_sec": round(rows / mean_s, 1) if mean_s > 0 else 0,
    }


def main():
    parser = argparse.ArgumentParser(
        description="Profile workflow filter stages for latency and throughput"
    )
    parser.add_argument("--config-path", required=True, help="Path to Hydra config directory")
    parser.add_argument("--config-name", required=True, help="Hydra config name (without .yaml)")
    parser.add_argument("--rows", type=int, default=10_000, help="Number of synthetic rows (default: 10000)")
    parser.add_argument("--rounds", type=int, default=5, help="Number of profiling rounds (default: 5)")
    parser.add_argument("--seed", type=int, default=42, help="Random seed for data generation")
    parser.add_argument("--input-parquet", help="Use a parquet file instead of synthetic data")
    parser.add_argument("--json-output", help="Write results to JSON file")
    args = parser.parse_args()

    print(f"Profiling workflow: {args.config_name}")
    print(f"  Config path: {args.config_path}")
    print(f"  Rows: {args.rows}, Rounds: {args.rounds}")
    print()

    # Load data
    if args.input_parquet:
        df = pd.read_parquet(args.input_parquet)
        if len(df) > args.rows:
            df = df.head(args.rows)
        print(f"Loaded {len(df)} rows from {args.input_parquet}")
    else:
        df = generate_text_dataframe(args.rows, seed=args.seed)
        print(f"Generated {len(df)} synthetic rows")
    print()

    # Extract stages
    stages = _instantiate_stages_from_config(args.config_path, args.config_name)
    if not stages:
        print("No filter stages found in workflow config.")
        sys.exit(1)

    # Ensure data has the required columns for column-based filters
    import numpy as np

    for _, stage in stages:
        # QualityScoreBucketer — needs score_field
        if hasattr(stage, "score_field") and stage.score_field not in df.columns:
            if "fw_edu_scores" in df.columns:
                df[stage.score_field] = df["fw_edu_scores"]
            else:
                df[stage.score_field] = np.random.uniform(0.0, 5.0, size=len(df))
        # TokenCountFilter — needs token_count_field
        if hasattr(stage, "token_count_field") and stage.token_count_field not in df.columns:
            if "text" in df.columns:
                df[stage.token_count_field] = df["text"].str.split().str.len()
            else:
                df[stage.token_count_field] = np.random.randint(50, 5000, size=len(df))
        # TruncationFilter — needs is_truncated
        if hasattr(stage, "keep_truncated") and "is_truncated" not in df.columns:
            df["is_truncated"] = np.random.choice([True, False], size=len(df), p=[0.05, 0.95])
        # DuplicateCountFilter — needs duplicate_count
        if hasattr(stage, "max_duplicates") and "duplicate_count" not in df.columns:
            df["duplicate_count"] = np.random.randint(0, 20, size=len(df))

    print(f"Found {len(stages)} filter stages to profile:")
    for name, _ in stages:
        print(f"  - {name}")
    print()

    # Profile each stage
    results = []
    print(f"{'Stage':<30} {'Mean (s)':>10} {'Stddev':>10} {'Rows/sec':>12}")
    print("-" * 66)

    for name, stage in stages:
        r = profile_stage(name, stage, df, args.rounds)
        results.append(r)
        print(f"{r['stage']:<30} {r['mean_seconds']:>10.4f} {r['stddev_seconds']:>10.4f} {r['throughput_rows_per_sec']:>12.1f}")

    print()

    # Output JSON if requested
    if args.json_output:
        output = {
            "config_name": args.config_name,
            "rows": args.rows,
            "rounds": args.rounds,
            "stages": results,
        }
        with open(args.json_output, "w") as f:
            json.dump(output, f, indent=2)
        print(f"Results written to {args.json_output}")


if __name__ == "__main__":
    main()
