"""Shared helper functions for accuracy benchmark tests."""

import numpy as np


def compute_accuracy(samples, filter_fn):
    """Run filter on samples, return (accuracy, mismatches)."""
    mismatches = []
    correct = 0
    for i, sample in enumerate(samples):
        actual = filter_fn(sample)
        expected = sample["expected_keep"]
        if actual == expected:
            correct += 1
        else:
            mismatches.append({
                "index": i,
                "text_preview": sample["text"][:80],
                "expected": expected,
                "actual": actual,
                "note": sample.get("note", ""),
            })
    accuracy = correct / len(samples) if samples else 1.0
    return accuracy, mismatches


def compute_score_percentiles(scores):
    """Compute median, P90, and P99 from a list of numeric scores."""
    arr = np.array(scores, dtype=float)
    valid = arr[~np.isnan(arr)]
    if len(valid) == 0:
        return {"median": float("nan"), "p90": float("nan"), "p99": float("nan")}
    return {
        "median": float(np.median(valid)),
        "p90": float(np.percentile(valid, 90)),
        "p99": float(np.percentile(valid, 99)),
    }


def compute_precision_recall(df, keep_col, expected_col):
    """Compute precision and recall from DataFrame columns."""
    tp = ((df[keep_col]) & (df[expected_col])).sum()
    fp = ((df[keep_col]) & (~df[expected_col])).sum()
    fn = ((~df[keep_col]) & (df[expected_col])).sum()
    precision = tp / (tp + fp) if (tp + fp) > 0 else 1.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 1.0
    return precision, recall


def print_score_percentiles(name, scores):
    """Print median, P90, P99 for a named score distribution."""
    percentiles = compute_score_percentiles(scores)
    print(f"\n  {name} score distribution: "
          f"median={percentiles['median']:.4f}, "
          f"P90={percentiles['p90']:.4f}, "
          f"P99={percentiles['p99']:.4f}")


def print_mismatches(mismatches):
    """Print mismatch details for filter accuracy tests."""
    if mismatches:
        for m in mismatches:
            print(f"  MISMATCH [{m['index']}]: expected={m['expected']}, "
                  f"actual={m['actual']} | {m.get('note', '')} | '{m.get('text_preview', '')}'")


def assert_accuracy(name, accuracy, threshold, mismatches, total):
    """Assert accuracy meets threshold with a descriptive message."""
    assert accuracy >= threshold, (
        f"{name} accuracy {accuracy:.2%} below threshold {threshold:.2%}. "
        f"{len(mismatches)} mismatches out of {total} samples."
    )
