"""Utilities for fetching real-world benchmark data from S3.

Samples random rows from the instruct_pt dataset hosted on S3, stratified
across subdirectories to get a diverse sample.

Usage:
    from agi_data_curator_harness.accuracy.real_world_data import load_real_world_data
    df = load_real_world_data()  # Returns None if unavailable
"""

from __future__ import annotations

import logging
import os
import random
from pathlib import Path

import pandas as pd

logger = logging.getLogger(__name__)

# S3 base path for the instruct_pt dataset
_DEFAULT_S3_BASE = os.environ.get(
    "BENCHMARK_REAL_WORLD_S3_PATH",
    "s3://bedrock-mm-data/yanzo/data_analysis/parquets/instruct_pt/",
)

# Local cache directory
_CACHE_DIR = Path(__file__).parent / ".cache"
_CACHE_FILE = _CACHE_DIR / "real_world_sampled.parquet"

# Sampling defaults
_DEFAULT_TOTAL_SAMPLES = 1000
_DEFAULT_SAMPLES_PER_SUBDIR = 50
_DEFAULT_SEED = 42


def _sample_from_s3(
    s3_base: str,
    total_samples: int = _DEFAULT_TOTAL_SAMPLES,
    samples_per_subdir: int = _DEFAULT_SAMPLES_PER_SUBDIR,
    seed: int = _DEFAULT_SEED,
) -> pd.DataFrame | None:
    """Sample random rows from parquet files across S3 subdirectories."""
    try:
        import s3fs
        import pyarrow.parquet as pq
    except ImportError:
        logger.warning("s3fs and pyarrow are required. Install with: pip install s3fs pyarrow")
        return None

    rng = random.Random(seed)

    try:
        fs = s3fs.S3FileSystem()
        s3_key = s3_base.replace("s3://", "")

        # List subdirectories
        subdirs = [
            d for d in fs.ls(s3_key, detail=False)
            if fs.isdir(d)
        ]
        if not subdirs:
            logger.warning("No subdirectories found at %s", s3_base)
            return None

        logger.info("Found %d subdirectories under %s", len(subdirs), s3_base)

        # Shuffle and sample from each subdir
        rng.shuffle(subdirs)
        all_samples = []
        remaining = total_samples

        for subdir in subdirs:
            if remaining <= 0:
                break

            n_to_sample = min(samples_per_subdir, remaining)
            subdir_name = subdir.rstrip("/").split("/")[-1]

            try:
                # Find parquet files in this subdir
                parquet_files = [
                    f for f in fs.ls(subdir, detail=False)
                    if f.endswith(".parquet")
                ]
                if not parquet_files:
                    continue

                # Pick a random parquet file
                chosen_file = rng.choice(parquet_files)
                logger.info("Sampling %d rows from %s", n_to_sample, chosen_file)

                with fs.open(chosen_file) as f:
                    pf = pq.ParquetFile(f)
                    total_rows = pf.metadata.num_rows

                    if total_rows == 0:
                        continue

                    # Read the file and sample
                    df = pf.read().to_pandas()
                    n_actual = min(n_to_sample, len(df))
                    sampled = df.sample(n=n_actual, random_state=seed)
                    sampled = sampled.copy()
                    sampled["source_subdir"] = subdir_name
                    all_samples.append(sampled)
                    remaining -= n_actual

            except Exception as e:
                logger.warning("Error sampling from %s: %s", subdir_name, e)
                continue

        if not all_samples:
            logger.warning("No samples collected from %s", s3_base)
            return None

        result = pd.concat(all_samples, ignore_index=True)
        logger.info("Sampled %d total rows from %d subdirectories", len(result), len(all_samples))
        return result

    except Exception as e:
        logger.warning("Could not sample from %s: %s", s3_base, e)
        return None


def download_from_s3(
    s3_path: str | None = None,
    force: bool = False,
    total_samples: int = _DEFAULT_TOTAL_SAMPLES,
    samples_per_subdir: int = _DEFAULT_SAMPLES_PER_SUBDIR,
    seed: int = _DEFAULT_SEED,
) -> Path | None:
    """Sample real-world data from S3 and cache locally.

    Returns the local cache path on success, None on failure.
    """
    if _CACHE_FILE.exists() and not force:
        logger.info("Using cached real-world data: %s", _CACHE_FILE)
        return _CACHE_FILE

    s3_base = s3_path or _DEFAULT_S3_BASE
    df = _sample_from_s3(s3_base, total_samples, samples_per_subdir, seed)
    if df is None:
        return None

    _CACHE_DIR.mkdir(parents=True, exist_ok=True)
    df.to_parquet(_CACHE_FILE, index=False)
    logger.info("Cached sampled real-world data to %s (%d rows)", _CACHE_FILE, len(df))
    return _CACHE_FILE


def load_real_world_data(
    local_path: str | None = None,
    s3_path: str | None = None,
    total_samples: int = _DEFAULT_TOTAL_SAMPLES,
    samples_per_subdir: int = _DEFAULT_SAMPLES_PER_SUBDIR,
    seed: int = _DEFAULT_SEED,
) -> pd.DataFrame | None:
    """Load real-world benchmark data by sampling from S3.

    Checks in order:
    1. Explicit local_path argument
    2. BENCHMARK_REAL_WORLD_LOCAL_PATH env var
    3. Local cache (previously sampled)
    4. Fresh S3 sampling

    Returns None if data is unavailable.
    """
    # Check explicit local path
    if local_path:
        p = Path(local_path)
        if p.exists():
            return pd.read_parquet(p)
        logger.warning("Local path %s does not exist", local_path)
        return None

    # Check env var
    env_path = os.environ.get("BENCHMARK_REAL_WORLD_LOCAL_PATH")
    if env_path:
        p = Path(env_path)
        if p.exists():
            return pd.read_parquet(p)
        logger.warning("BENCHMARK_REAL_WORLD_LOCAL_PATH=%s does not exist", env_path)

    # Check cache
    if _CACHE_FILE.exists():
        return pd.read_parquet(_CACHE_FILE)

    # Sample from S3
    cached = download_from_s3(s3_path, total_samples=total_samples,
                              samples_per_subdir=samples_per_subdir, seed=seed)
    if cached:
        return pd.read_parquet(cached)

    return None
