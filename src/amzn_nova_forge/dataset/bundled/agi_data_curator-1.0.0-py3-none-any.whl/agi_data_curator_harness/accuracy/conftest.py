"""Accuracy benchmark fixtures."""

import json
from pathlib import Path

import pytest
import yaml

GOLDEN_DATA_DIR = Path(__file__).parent / "golden_data"
THRESHOLDS_FILE = Path(__file__).parent / "accuracy_thresholds.yaml"


@pytest.fixture(scope="session")
def accuracy_thresholds():
    """Load accuracy threshold config."""
    with open(THRESHOLDS_FILE) as f:
        return yaml.safe_load(f)


def _load_golden(name: str) -> list[dict]:
    path = GOLDEN_DATA_DIR / f"{name}.json"
    with open(path) as f:
        return json.load(f)


def _make_golden_fixture(name: str):
    @pytest.fixture(scope="session")
    def fixture_fn():
        return _load_golden(name)
    fixture_fn.__name__ = f"golden_{name}"
    return fixture_fn


# Auto-generate a fixture for every golden data JSON file.
_golden_names = [p.stem for p in sorted(GOLDEN_DATA_DIR.glob("*.json"))]
for _name in _golden_names:
    globals()[f"golden_{_name}"] = _make_golden_fixture(_name)


@pytest.fixture(scope="session")
def real_world_data():
    """Load real-world labeled data. Returns None if unavailable."""
    from agi_data_curator_harness.accuracy.real_world_data import load_real_world_data

    return load_real_world_data()
