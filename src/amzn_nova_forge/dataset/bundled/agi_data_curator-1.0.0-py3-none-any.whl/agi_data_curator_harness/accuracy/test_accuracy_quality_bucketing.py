"""Accuracy tests for quality score bucketing against golden labeled data."""

import pandas as pd
import pytest

from agi_data_curator.filtering.quality_bucketer import QualityScoreBucketer

from agi_data_curator_harness.accuracy.helpers import print_score_percentiles


class TestQualityScoreBucketerAccuracy:

    def test_golden_accuracy(self, golden_quality_score_bucketer, accuracy_thresholds):
        from nemo_curator.tasks import DocumentBatch

        threshold = accuracy_thresholds["golden_data"]["quality_score_bucketer"]["min_accuracy"]

        # Build a batch from all golden samples
        scores = []
        expected_ids = []
        for sample in golden_quality_score_bucketer:
            scores.append(sample["fw_edu_scores"])
            expected_ids.append(sample["expected_bucket_id"])

        df = pd.DataFrame({
            "text": ["placeholder"] * len(scores),
            "fw_edu_scores": scores,
            "id": [f"test-{i}" for i in range(len(scores))],
        })
        batch = DocumentBatch(task_id="test", dataset_name="test", data=df)

        bucketer = QualityScoreBucketer(score_field="fw_edu_scores")
        result = bucketer.process(batch)
        result_df = result.to_pandas()

        mismatches = []
        correct = 0
        for i, (expected, actual) in enumerate(
            zip(expected_ids, result_df["quality_bucket_id"].tolist())
        ):
            if expected == actual:
                correct += 1
            else:
                mismatches.append({
                    "index": i,
                    "score": scores[i],
                    "expected_bucket": expected,
                    "actual_bucket": actual,
                    "note": golden_quality_score_bucketer[i].get("note", ""),
                })

        accuracy = correct / len(golden_quality_score_bucketer)

        print_score_percentiles("QualityScoreBucketer", scores)

        if mismatches:
            for m in mismatches:
                print(f"  MISMATCH [{m['index']}]: score={m['score']}, "
                      f"expected_bucket={m['expected_bucket']}, "
                      f"actual_bucket={m['actual_bucket']} | {m['note']}")

        assert accuracy >= threshold, (
            f"QualityScoreBucketer accuracy {accuracy:.2%} below threshold {threshold:.2%}. "
            f"{len(mismatches)} mismatches out of {len(golden_quality_score_bucketer)} samples."
        )

    def test_null_scores_get_none_bucket(self):
        """Null/NaN scores should always map to bucket -1."""
        from nemo_curator.tasks import DocumentBatch

        df = pd.DataFrame({
            "text": ["a", "b", "c"],
            "fw_edu_scores": [None, float("nan"), 0.5],
            "id": ["1", "2", "3"],
        })
        batch = DocumentBatch(task_id="test", dataset_name="test", data=df)
        bucketer = QualityScoreBucketer(score_field="fw_edu_scores")
        result = bucketer.process(batch)
        ids = result.to_pandas()["quality_bucket_id"].tolist()

        assert ids[0] == -1, "None score should map to bucket -1"
        assert ids[1] == -1, "NaN score should map to bucket -1"
        assert ids[2] >= 0, "Valid score should map to a real bucket"

    def test_bucket_names_assigned(self):
        """Every row should get a bucket name, including NONE for null scores."""
        from nemo_curator.tasks import DocumentBatch

        df = pd.DataFrame({
            "text": ["a", "b"],
            "fw_edu_scores": [None, 1.0],
            "id": ["1", "2"],
        })
        batch = DocumentBatch(task_id="test", dataset_name="test", data=df)
        bucketer = QualityScoreBucketer(score_field="fw_edu_scores")
        result = bucketer.process(batch)
        names = result.to_pandas()["quality_bucket_name"].tolist()

        assert names[0] == "NONE"
        assert names[1].startswith("FWEDU-")
