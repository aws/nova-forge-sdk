"""Accuracy tests for heuristic and column filters against golden labeled data."""

import pandas as pd
import pytest

from agi_data_curator.filtering.heuristic_filters import SystemPromptFilter
from agi_data_curator.filtering.column_filters import TokenCountFilter
from nemo_curator.stages.text.filters.heuristic_filter import (
    BoilerPlateStringFilter,
    MeanWordLengthFilter,
    NonAlphaNumericFilter,
    RepeatedLinesFilter,
    RepeatedParagraphsFilter,
    RepeatingDuplicateNGramsFilter,
    RepeatingTopNGramsFilter,
    UrlsFilter,
    WordCountFilter,
)

from agi_data_curator_harness.accuracy.helpers import (
    compute_accuracy,
    compute_precision_recall,
    print_score_percentiles,
    print_mismatches,
    assert_accuracy,
)


# ---------------------------------------------------------------------------
# Fixed-param heuristic filters — golden data (parametrized)
# ---------------------------------------------------------------------------

# Each entry: (display_name, threshold_key, fixture_name, filter_instance)
_FIXED_PARAM_FILTERS = [
    ("SystemPromptFilter", "system_prompt_filter", "golden_system_prompt_filter", SystemPromptFilter()),
    ("RepeatingTopNGramsFilter", "repeating_top_ngrams_filter", "golden_repeating_top_ngrams_filter", RepeatingTopNGramsFilter(n=2, max_repeating_ngram_ratio=0.2)),
    ("NonAlphaNumericFilter", "non_alpha_numeric_filter", "golden_non_alpha_numeric_filter", NonAlphaNumericFilter(max_non_alpha_numeric_to_text_ratio=0.25)),
    ("UrlsFilter", "urls_filter", "golden_urls_filter", UrlsFilter(max_url_to_text_ratio=0.2)),
    ("BoilerPlateStringFilter", "boiler_plate_string_filter", "golden_boiler_plate_string_filter", BoilerPlateStringFilter(max_boilerplate_string_ratio=0.4)),
    ("RepeatedLinesFilter", "repeated_lines_filter", "golden_repeated_lines_filter", RepeatedLinesFilter(max_repeated_line_fraction=0.7)),
    ("RepeatedParagraphsFilter", "repeated_paragraphs_filter", "golden_repeated_paragraphs_filter", RepeatedParagraphsFilter(max_repeated_paragraphs_ratio=0.7)),
    ("RepeatingDuplicateNGramsFilter", "repeating_duplicate_ngrams_filter", "golden_repeating_duplicate_ngrams_filter", RepeatingDuplicateNGramsFilter(n=5, max_repeating_duplicate_ngram_ratio=0.2)),
]


@pytest.mark.parametrize(
    "display_name, threshold_key, fixture_name, filt",
    _FIXED_PARAM_FILTERS,
    ids=[f[0] for f in _FIXED_PARAM_FILTERS],
)
def test_fixed_param_filter_golden_accuracy(
    display_name, threshold_key, fixture_name, filt, accuracy_thresholds, request
):
    golden_data = request.getfixturevalue(fixture_name)
    threshold = accuracy_thresholds["golden_data"][threshold_key]["min_accuracy"]

    scores = []

    def score_and_keep(sample):
        score = filt.score_document(sample["text"])
        scores.append(score)
        return filt.keep_document(score)

    accuracy, mismatches = compute_accuracy(golden_data, score_and_keep)
    print_score_percentiles(display_name, scores)
    print_mismatches(mismatches)
    assert_accuracy(display_name, accuracy, threshold, mismatches, len(golden_data))


# ---------------------------------------------------------------------------
# Real-world accuracy tests (SystemPromptFilter, RepeatingTopNGramsFilter)
# ---------------------------------------------------------------------------

_REAL_WORLD_FILTERS = [
    ("SystemPromptFilter", "system_prompt_filter", "expected_keep_system_prompt", SystemPromptFilter()),
    ("RepeatingTopNGramsFilter", "repeating_top_ngrams_filter", "expected_keep_repeating_ngrams", RepeatingTopNGramsFilter(n=2, max_repeating_ngram_ratio=0.2)),
]


@pytest.mark.parametrize(
    "display_name, threshold_key, label_col, filt",
    _REAL_WORLD_FILTERS,
    ids=[f[0] for f in _REAL_WORLD_FILTERS],
)
def test_real_world_accuracy(
    display_name, threshold_key, label_col, filt, real_world_data, accuracy_thresholds
):
    if real_world_data is None:
        pytest.skip("Real-world data not available")

    if label_col not in real_world_data.columns:
        pytest.skip(f"Real-world data missing '{label_col}' column")

    thresholds = accuracy_thresholds["real_world"][threshold_key]

    df = real_world_data.copy()
    df["actual_keep"] = df["text"].apply(
        lambda t: filt.keep_document(filt.score_document(t))
    )

    precision, recall = compute_precision_recall(df, "actual_keep", label_col)

    assert precision >= thresholds["min_precision"], (
        f"{display_name} precision {precision:.2%} below {thresholds['min_precision']:.2%}"
    )
    assert recall >= thresholds["min_recall"], (
        f"{display_name} recall {recall:.2%} below {thresholds['min_recall']:.2%}"
    )


# ---------------------------------------------------------------------------
# Per-sample param filters — golden data
# ---------------------------------------------------------------------------


class TestWordCountFilterAccuracy:

    def test_golden_accuracy(self, golden_word_count_filter, accuracy_thresholds):
        threshold = accuracy_thresholds["golden_data"]["word_count_filter"]["min_accuracy"]

        scores = []

        def score_and_keep(sample):
            filt = WordCountFilter(
                min_words=sample["min_words"],
                max_words=sample["max_words"],
            )
            score = filt.score_document(sample["text"])
            scores.append(score)
            return filt.keep_document(score)

        accuracy, mismatches = compute_accuracy(golden_word_count_filter, score_and_keep)
        print_score_percentiles("WordCountFilter", scores)
        print_mismatches(mismatches)
        assert_accuracy("WordCountFilter", accuracy, threshold, mismatches, len(golden_word_count_filter))


class TestMeanWordLengthFilterAccuracy:

    def test_golden_accuracy(self, golden_mean_word_length_filter, accuracy_thresholds):
        threshold = accuracy_thresholds["golden_data"]["mean_word_length_filter"]["min_accuracy"]

        scores = []

        def score_and_keep(sample):
            filt = MeanWordLengthFilter(
                min_mean_word_length=sample["min_mean_word_length"],
                max_mean_word_length=sample["max_mean_word_length"],
            )
            score = filt.score_document(sample["text"])
            scores.append(score)
            return filt.keep_document(score)

        accuracy, mismatches = compute_accuracy(golden_mean_word_length_filter, score_and_keep)
        print_score_percentiles("MeanWordLengthFilter", scores)
        print_mismatches(mismatches)
        assert_accuracy("MeanWordLengthFilter", accuracy, threshold, mismatches, len(golden_mean_word_length_filter))


# ---------------------------------------------------------------------------
# TokenCountFilter — Golden Data (different API: batch-based process())
# ---------------------------------------------------------------------------


class TestTokenCountFilterAccuracy:

    def test_golden_accuracy(self, golden_token_count_filter, accuracy_thresholds):
        from nemo_curator.tasks import DocumentBatch

        threshold = accuracy_thresholds["golden_data"]["token_count_filter"]["min_accuracy"]
        mismatches = []
        correct = 0
        scores = []

        for i, sample in enumerate(golden_token_count_filter):
            filt = TokenCountFilter(
                min_tokens=sample["min_tokens"],
                max_tokens=sample["max_tokens"],
            )
            df = pd.DataFrame({
                "text": ["placeholder"],
                "token_count": [sample["token_count"]],
                "id": [f"test-{i}"],
            })
            batch = DocumentBatch(task_id="test", dataset_name="test", data=df)
            result = filt.process(batch)
            actual_keep = len(result.to_pandas()) > 0
            expected = sample["expected_keep"]
            scores.append(sample["token_count"])

            if actual_keep == expected:
                correct += 1
            else:
                mismatches.append({
                    "index": i,
                    "token_count": sample["token_count"],
                    "expected": expected,
                    "actual": actual_keep,
                    "note": sample.get("note", ""),
                })

        accuracy = correct / len(golden_token_count_filter)
        print_score_percentiles("TokenCountFilter", scores)

        if mismatches:
            for m in mismatches:
                print(f"  MISMATCH [{m['index']}]: token_count={m['token_count']}, "
                      f"expected={m['expected']}, actual={m['actual']} | {m['note']}")

        assert_accuracy("TokenCountFilter", accuracy, threshold, mismatches, len(golden_token_count_filter))
