# Benchmark Runbook

Quick-reference for running accuracy, performance, and profiling benchmarks.

> All commands assume you are in the `AGIDataCurator/` project root.

---

## Prerequisites

```bash
brazil-build          # creates hatch environments with all dependencies
```

Key dependencies: `pytest`, `pytest-benchmark`, `s3fs`, `pyarrow`, `pyyaml`.

### Running on macOS

NeMo Curator officially supports Linux only. Its `__init__.py` raises a
`ValueError` on non-Linux platforms. To run benchmarks on macOS, set the
bypass environment variable before every command:

```bash
export NEMO_CURATOR_ALLOW_NON_LINUX=1
```

The `agi_data_curator_harness/conftest.py` also sets this automatically when pytest loads,
so `pytest` commands work without the export. For standalone scripts
(`compare_baselines.py`, `profile_workflow.py`) you must export the variable
yourself or prefix each command:

```bash
NEMO_CURATOR_ALLOW_NON_LINUX=1 python src/agi_data_curator_harness/performance/compare_baselines.py bench_results.json
NEMO_CURATOR_ALLOW_NON_LINUX=1 python -m agi_data_curator_harness.profile_workflow --config-path src/agi_data_curator_harness --config-name profile_pipeline
```

**Performance baselines:** Baselines are stored per-platform (`baselines_darwin.json`
and `baselines_linux.json`). The comparison script auto-detects the current
platform, so macOS runs compare against macOS baselines automatically.

---

## 1. Accuracy Benchmarks

Accuracy tests verify filter correctness against labeled data. Two tiers exist:

### Golden Data (offline, no S3 needed)

Hand-labeled JSON samples in `agi_data_curator_harness/accuracy/golden_data/`. Thresholds are in
`agi_data_curator_harness/accuracy/accuracy_thresholds.yaml`.

```bash
# Run all golden-data accuracy tests
python -m pytest src/agi_data_curator_harness/accuracy/ -v -k "golden"

# Run a single filter
python -m pytest src/agi_data_curator_harness/accuracy/test_accuracy_filters.py::TestSystemPromptFilterAccuracy::test_golden_accuracy -v
python -m pytest src/agi_data_curator_harness/accuracy/test_accuracy_filters.py::TestWordCountFilterAccuracy -v
python -m pytest src/agi_data_curator_harness/accuracy/test_accuracy_quality_bucketing.py -v
```

### Real-World Data (S3 sampling)

Samples ~1000 rows stratified across subdirectories from S3 and caches locally.

**Default S3 source:** `s3://bedrock-mm-data/yanzo/data_analysis/parquets/instruct_pt/`

```bash
# Run all accuracy tests (real-world tests skip if label columns are missing)
python -m pytest src/agi_data_curator_harness/accuracy/ -v

# Force re-sample from S3 (delete the local cache first)
rm -f src/agi_data_curator_harness/accuracy/.cache/real_world_sampled.parquet
python -m pytest src/agi_data_curator_harness/accuracy/ -v
```

**Override data source via environment variables:**

| Variable | Purpose |
|---|---|
| `BENCHMARK_REAL_WORLD_S3_PATH` | S3 base path to sample from |
| `BENCHMARK_REAL_WORLD_LOCAL_PATH` | Skip S3, use a local parquet file directly |

```bash
BENCHMARK_REAL_WORLD_LOCAL_PATH="/tmp/my_labeled.parquet" python -m pytest src/agi_data_curator_harness/accuracy/ -v
```

**Note:** Real-world `test_real_world_accuracy` tests expect label columns
(`expected_keep_system_prompt`, `expected_keep_repeating_ngrams`, etc.) in the data.
Tests skip gracefully if these columns are absent.

### Accuracy Thresholds

Edit `agi_data_curator_harness/accuracy/accuracy_thresholds.yaml` to adjust pass/fail thresholds:

```yaml
golden_data:
  system_prompt_filter:
    min_accuracy: 0.95       # fraction correct
  word_count_filter:
    min_accuracy: 1.0

real_world:
  system_prompt_filter:
    min_precision: 0.85
    min_recall: 0.85
```

---

## 2. Performance Benchmarks

Measures filter throughput (docs/sec, rows/sec) on synthetic data using `pytest-benchmark`.

```bash
# Run all performance benchmarks
python -m pytest src/agi_data_curator_harness/performance/ -v --benchmark-only

# Save results to JSON
python -m pytest src/agi_data_curator_harness/performance/ -v --benchmark-only --benchmark-json=bench_results.json
```

### Baseline Comparison

Compare current results against committed baselines to detect regressions.
Baselines are stored **per-platform** — the script auto-detects `darwin`
(macOS dev) or `linux` (Ray/CI) and loads the matching file.

```bash
# Compare against the current platform's baselines (auto-detected)
python src/agi_data_curator_harness/performance/compare_baselines.py bench_results.json

# Explicitly compare against Linux baselines (e.g. from a macOS machine)
python src/agi_data_curator_harness/performance/compare_baselines.py bench_results.json --platform linux

# Update baselines for the current platform after a known-good run
python src/agi_data_curator_harness/performance/compare_baselines.py bench_results.json --update

# Update baselines for a specific platform
python src/agi_data_curator_harness/performance/compare_baselines.py bench_results.json --update --platform linux
```

Regression tolerance is configured in `agi_data_curator_harness/performance/baseline_config.yaml`:

```yaml
default_tolerance_percent: 15
per_benchmark_tolerance:
  test_bench_quality_score_bucketer: 10
```

Baselines are stored per-platform in `agi_data_curator_harness/performance/baselines/`:

| File | Platform | When to update |
|---|---|---|
| `baselines_linux.json` | Linux (Ray/CI) | After verified runs on CI or Ray cluster |
| `baselines_darwin.json` | macOS (dev) | After verified runs on local macOS machine |

---

## 3. Workflow Profiling

Profile individual filter stages from a Hydra workflow config. Reports per-stage
latency, stddev, and throughput.

### Benchmark profile pipeline (all filters)

`agi_data_curator_harness/profile_pipeline.yaml` includes every heuristic and column filter
covered by the benchmark suite (12 stages total). Use this for comprehensive
profiling.

```bash
# Profile all benchmark filters (default 10k rows, 5 rounds)
python -m agi_data_curator_harness.profile_workflow \
    --config-path src/agi_data_curator_harness \
    --config-name profile_pipeline \
    --rows 10000 --rounds 5

# Export JSON for CI
python -m agi_data_curator_harness.profile_workflow \
    --config-path src/agi_data_curator_harness \
    --config-name profile_pipeline \
    --json-output profile_results.json
```

### Production pipeline configs

You can also profile any production pipeline config directly:

```bash
# Profile FinePDFs eng pipeline (column filters + quality bucketing)
python -m agi_data_curator_harness.profile_workflow \
    --config-path src/agi_data_curator/workflows/finepdfs \
    --config-name finepdfs_eng \
    --rows 10000 --rounds 5

# Profile HF text curation pipeline (heuristic + column filters)
python -m agi_data_curator_harness.profile_workflow \
    --config-path src/agi_data_curator/workflows/hf_text \
    --config-name hf_text_curation \
    --rows 10000 --rounds 5

# Profile with real-world sampled data
python -m agi_data_curator_harness.profile_workflow \
    --config-path src/agi_data_curator_harness \
    --config-name profile_pipeline \
    --input-parquet src/agi_data_curator_harness/accuracy/.cache/real_world_sampled.parquet
```

---

## 4. Full Report (CI-friendly)

Run everything and capture reports:

```bash
# Accuracy
python -m pytest src/agi_data_curator_harness/accuracy/ -v --tb=short 2>&1 | tee accuracy_report.txt

# Performance + JSON
python -m pytest src/agi_data_curator_harness/performance/ -v --benchmark-only \
    --benchmark-json=bench_results.json 2>&1 | tee perf_report.txt

# Baseline comparison
python src/agi_data_curator_harness/performance/compare_baselines.py bench_results.json 2>&1 | tee baseline_comparison.txt

# Workflow profiling (all filters)
python -m agi_data_curator_harness.profile_workflow \
    --config-path src/agi_data_curator_harness \
    --config-name profile_pipeline \
    --rows 10000 --rounds 5 \
    --json-output profile_results.json 2>&1 | tee profile_report.txt
```

---

## 5. Running on EKS

Submit benchmarks to a remote Ray cluster on EKS. This uploads your local
source code at submission time via the Ray Job Submission SDK — no Docker
image rebuild needed when iterating on filter algorithms.

**Assumptions:** EKS cluster is running, `kubectl` is configured, Ray cluster
pods are in `Running` state.

### Prerequisites

Port-forward the Ray dashboard from EKS to your local machine:

```bash
kubectl port-forward svc/raycluster-text-dedup-head-svc 8265:8265 \
    -n agi-dev \
    --context arn:aws:eks:us-east-1:926989854342:cluster/agi-scaling-beta-us-east-1
```

Verify the connection:

```bash
ray job list --address http://localhost:8265
```

### Submit benchmarks

```bash
# Accuracy suite
python scripts/submit_eks_job.py benchmark --suite accuracy

# Performance suite with JSON output
python scripts/submit_eks_job.py benchmark --suite performance \
    --benchmark-json results.json

# Workflow profiling
python scripts/submit_eks_job.py benchmark --suite profile

# All suites
python scripts/submit_eks_job.py benchmark --suite all

# Filter to specific tests
python scripts/submit_eks_job.py benchmark --suite accuracy \
    --filter "test_golden_accuracy"
```

### Submit Hydra workflows

```bash
python scripts/submit_eks_job.py workflow \
    --config-path src/agi_data_curator/workflows/finepdfs \
    --config-name finepdfs_eng \
    --override input_path=s3://bucket/in \
    --override output_path=s3://bucket/out
```

### Submit arbitrary commands

```bash
python scripts/submit_eks_job.py run \
    --cmd "python -m agi_data_curator_harness.profile_workflow --config-path src/agi_data_curator_harness --config-name profile_pipeline"
```

### Dry run

Add `--dry-run` to any subcommand to print the entrypoint without submitting:

```bash
python scripts/submit_eks_job.py benchmark --suite accuracy --dry-run
```

### Common flags

| Flag | Default | Description |
|------|---------|-------------|
| `--ray-address` | `http://localhost:8265` | Ray dashboard URL |
| `--working-dir` | `.` | Local directory to upload |
| `--timeout` | None | Job timeout in seconds |
| `--dry-run` | `false` | Print commands without submitting |
| `--env-var KEY=VALUE` | (repeatable) | Extra environment variables |
| `--exclude PATTERN` | (repeatable) | Extra file patterns to skip during upload |
| `--eks-cluster-arn` | beta cluster | Override EKS cluster ARN |
| `--namespace` | `agi-dev` | Override Kubernetes namespace |
| `--ray-cluster-name` | `raycluster-text-dedup` | Override RayCluster name |

### GPU mocks on EKS

When running on a real GPU cluster, the GPU library mocks in
`agi_data_curator_harness/conftest.py` are automatically skipped. The submit script sets
`BENCHMARK_NO_GPU_MOCK=1` in the runtime environment by default.

To run locally with mocks (the default), no changes are needed — this only
applies to EKS submissions.

### Programmatic usage

Use `RayJobSubmitter` directly from Python — it satisfies the
`WorkflowOrchestrator.submitter` interface:

```python
from agi_data_curator.config.ray_config import RayJobSubmitterConfig
from agi_data_curator.operator.ray_operator import RayJobSubmitter

config = RayJobSubmitterConfig.beta()
submitter = RayJobSubmitter(config)
job_id = submitter.submit_and_wait("pytest src/agi_data_curator_harness/accuracy/ -v")
print(submitter.get_logs(job_id))
```

---

## Quick Reference

| Suite | Command | Data Source | Output |
|---|---|---|---|
| Accuracy (golden) | `pytest src/agi_data_curator_harness/accuracy/ -k golden` | `golden_data/*.json` | Pass/fail vs thresholds |
| Accuracy (real-world) | `pytest src/agi_data_curator_harness/accuracy/ -k real_world` | S3 sample (cached) | Precision/recall or skip |
| Performance | `pytest src/agi_data_curator_harness/performance/ --benchmark-only` | Synthetic | Timing table |
| Performance JSON | above + `--benchmark-json=out.json` | Synthetic | JSON for CI |
| Baseline compare | `python src/agi_data_curator_harness/performance/compare_baselines.py out.json` | JSON from above | Regression report |
| Workflow profile (all) | `python -m agi_data_curator_harness.profile_workflow --config-path src/agi_data_curator_harness --config-name profile_pipeline` | Synthetic or parquet | Per-stage latency |
| Workflow profile (prod) | `python -m agi_data_curator_harness.profile_workflow --config-path <workflow_dir> --config-name <name>` | Synthetic or parquet | Per-stage latency |
| EKS benchmark | `scripts/submit_eks_job.py benchmark --suite accuracy` | Same as local | Remote Ray job |
| EKS workflow | `scripts/submit_eks_job.py workflow --config-path ... --config-name ...` | S3 | Remote Ray job |
| EKS arbitrary | `scripts/submit_eks_job.py run --cmd "..."` | Any | Remote Ray job |

---

## Directory Layout

```
agi_data_curator_harness/
  RUNBOOK.md                          # this file
  conftest.py                         # GPU mocks + macOS platform bypass
  profile_workflow.py                 # per-stage workflow profiler
  profile_pipeline.yaml               # Hydra config with all benchmark filters
  accuracy/
    accuracy_thresholds.yaml          # pass/fail thresholds
    conftest.py                       # fixtures (golden data, real-world data)
    helpers.py                        # shared metric/reporting helpers
    real_world_data.py                # S3 sampling + caching logic
    test_accuracy_filters.py          # filter accuracy tests
    test_accuracy_quality_bucketing.py
    golden_data/                      # hand-labeled JSON samples
      system_prompt_filter.json
      repeating_top_ngrams_filter.json
      word_count_filter.json
      token_count_filter.json
      quality_score_bucketer.json
      non_alpha_numeric_filter.json
      urls_filter.json
      boiler_plate_string_filter.json
      repeated_lines_filter.json
      repeated_paragraphs_filter.json
      repeating_duplicate_ngrams_filter.json
      mean_word_length_filter.json
    .cache/                           # local cache (git-ignored)
  performance/
    baseline_config.yaml              # regression tolerance settings
    conftest.py                       # synthetic data fixtures
    data_generators.py                # synthetic DataFrame factories
    test_bench_filters.py             # filter throughput benchmarks
    test_bench_quality_bucketing.py   # bucketer throughput benchmark
    compare_baselines.py              # baseline comparison script (platform-aware)
    baselines/
      baselines_linux.json            # Linux (Ray/CI) baseline timings
      baselines_darwin.json           # macOS (dev) baseline timings

scripts/
  submit_eks_job.py                   # CLI for submitting jobs to EKS Ray cluster

src/agi_data_curator/
  config/ray_config.py                # RayJobSubmitterConfig dataclass
  operator/ray_operator.py            # RayJobSubmitter (submit + poll via Ray SDK)

tests/operator/
  test_ray_operator.py                # Unit tests for RayJobSubmitter
```
